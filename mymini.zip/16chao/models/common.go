package models

import (
	"database/sql"
	"fmt"
	"path/filepath"
	"runtime"

	"github.com/astaxie/beego/logs"
)

var (
	debug = false
)

// GetFileLineName get parent's file line name
func GetFileLineName(depthOffset uint) (file string, line int, name string) {
	if depthOffset < 0 {
		return "", 0, ""
	}

	realDepth := 1 + depthOffset
	pc, file, line, _ := runtime.Caller(int(realDepth))
	name = runtime.FuncForPC(pc).Name()
	return file, line, name
}

// GetFuncName get  file:line name
// if depthOffset set to 0, get current position
// if depthOffset set to 1, get parent's position
func GetFuncName(depthOffset uint) (name string) {
	depth := 1 + depthOffset
	file, line, name := GetFileLineName(depth)
	return fmt.Sprintf("%s:%d %s", filepath.Base(file), line, name)
}

// mySQLQuery is a wrapper of db.Query
func mySQLQuery(query string, args ...interface{}) (rows *sql.Rows, err error) {

	db, _ := GetDB()
	if db == nil {
		err = fmt.Errorf("%s failed for: %v", GetFuncName(0), err)
		return nil, err
	}

	if debug {
		logs.Debug("%s SQL :%s\n", GetFuncName(1), query)
		logs.Debug("%v\n", args)
	}

	return db.Query(query, args...)
}

// mySQLQueryRow is a wrapper of db.QueryRow
func mySQLQueryRow(query string, args ...interface{}) (row *sql.Row, err error) {

	db, _ := GetDB()
	if db == nil {
		err = fmt.Errorf("%s failed for: %v", GetFuncName(0), err)
		return nil, err
	}

	if debug {
		logs.Debug("%s SQL :%s\n", GetFuncName(1), query)
		logs.Debug("%v\n", args)
	}

	row = db.QueryRow(query, args...)
	return row, nil
}
