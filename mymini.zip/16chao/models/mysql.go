package models

import (
	"fmt"

	"github.com/jinzhu/gorm"

	"github.com/astaxie/beego"
	"github.com/astaxie/beego/logs"
	_ "github.com/go-sql-driver/mysql" // 初始化mysql驱动
)

//OrmMap ...
var OrmMap map[string]*gorm.DB

type gormlog struct {
	t int
}

func (g gormlog) Print(v ...interface{}) {
	logs.Debug("", v...)
}

//InitialMySQL initial mysql
func InitialMySQL() {

	OrmMap = make(map[string]*gorm.DB, 2)

	user := beego.AppConfig.String("mysqluser")
	password := beego.AppConfig.String("mysqlpassword")
	host := beego.AppConfig.String("mysqlhost")
	db := beego.AppConfig.String("mysqldb")
	maxIdel := beego.AppConfig.DefaultInt("mysqlMaxIdel", 20)
	maxConns := beego.AppConfig.DefaultInt("mysqlMaxConns", 1000)

	// set default database
	mysqlURL := fmt.Sprintf("%s:%s@tcp(%s)/%s?charset=utf8&parseTime=True&loc=Asia%%2FShanghai", user, password, host, db)
	logs.Info("mysqlURL: %s", mysqlURL)
	var err error
	OrmMap["default"], err = gorm.Open("mysql", mysqlURL)
	if err != nil {
		panic(err)
	}
	OrmMap["default"].SingularTable(true)
	OrmMap["default"].DB().SetMaxIdleConns(maxIdel)
	OrmMap["default"].DB().SetMaxOpenConns(maxConns)
	OrmMap["default"].LogMode(true)
	OrmMap["default"].SetLogger(gormlog{t: 1})

	logs.Info("init mysql success host:%s db:%s user:%s", host, db, user)
}
