package models

import (
	"errors"
	"fmt"
	"sync"
)

// UserModel  用户信息表
type UserModel struct {
	ID              int     `gorm:"column:user_id;AUTO_INCREMENT"`
	Name            string  `gorm:"column:user_name"`
	Avatar          string  `gorm:"column:user_avatar"`
	Gender          int     `gorm:"column:user_gender"`
	Region          string  `gorm:"column:user_region"`
	Score           float64 `gorm:"column:score"`
	ActivitiesCount int     `gorm:"column:activities_count"`
	MarkCount       int     `gorm:"column:mark_count"`
	OpenID          string  `gorm:"column:open_id"`
	//	CreatedAt time.Time `gorm:"column:ctime"`
	//	UpdatedAt time.Time `gorm:"column:utime"`
}

var defaultUserModel *UserModel
var userModelOnce sync.Once

// TableName 定义表名
func (m *UserModel) TableName() string {
	return fmt.Sprintf("user")
}

// GetUserModel get UserModel object
func GetUserModel() *UserModel {
	userModelOnce.Do(func() {
		defaultUserModel = &UserModel{}
	})

	return defaultUserModel
}

// InsertOne 插入一条记录
func (m *UserModel) InsertOne(record *UserModel) error {
	if GetOrm() == nil {
		return errors.New("GetOrm is nil")
	}

	if record == nil {
		return errors.New("record is nil")
	}

	return GetOrm().Create(record).Error
}

// GetUserInfo 根据user_id查询一条记录
func (m *UserModel) GetUserInfo(userID int) (ret *UserModel, err error) {
	if GetOrm() == nil {
		return nil, errors.New("GetOrm is nil")
	}

	userInfo := new(UserModel)
	orm := GetOrm().Where("user_id = ?", userID).First(userInfo)
	if orm.Error != nil {
		if orm.RecordNotFound() {
			return nil, nil
		}
	}
	return userInfo, orm.Error
}

// GetUserNameByID 根据user_id查询user_name
func (m *UserModel) GetUserNameByID(uid int) (string, error) {
	if GetOrm() == nil {
		return "", errors.New("GetOrm is nil")
	}

	userInfo := new(UserModel)
	orm := GetOrm().Where("user_id = ?", uid).First(userInfo)
	if orm.Error != nil {
		if orm.RecordNotFound() {
			return "", orm.Error
		}
	}
	return userInfo.Name, orm.Error
}

// DeleteUser 根据user_id删除一条记录
func (m *UserModel) DeleteUser(userID int) error {
	if GetOrm() == nil {
		return errors.New("GetOrm is nil")
	}

	return GetOrm().Delete(&UserModel{}, &UserModel{ID: userID}).Error
}

//CountUser ...
func (m *UserModel) CountUser() int {
	if GetOrm() == nil {
		return 0
	}
	var count int
	err := GetOrm().Table(m.TableName()).Count(&count)
	_ = err
	return count
}

// UpdateByUserID 利用map更新活动
func (m *UserModel) UpdateByUserID(uid int, updateCols map[string]interface{}) error {

	// 无更新
	if len(updateCols) <= 0 {
		return errors.New("updateCols is nil")
	}

	if GetOrm() == nil {
		return errors.New("GetOrm is nil")
	}

	return GetOrm().Table(m.TableName()).Where("user_id = ?", uid).Updates(updateCols).Error
}

// Update 更具record中的user ID查找用户，更新用户信息其他字段
func (m *UserModel) Update(record *UserModel) error {
	if GetOrm() == nil {
		return errors.New("GetOrm is nil")
	}
	if record == nil {
		return errors.New("record is nil")
	}
	// 性别是0未知时，是否按照结构体update会失败？
	return GetOrm().Table(m.TableName()).Where("user_id = ? ", record.ID).Update(record).Error
}

// CheckOpenID 查看当前OpenID是否已经存在 如果存在返回用户user_id,nil  如果不存在返回-1,error
func (m *UserModel) CheckOpenID(OpenID string) (int, error) {
	if GetOrm() == nil {
		return -1, errors.New("GetOrm is nil")
	}
	backUser := new(UserModel)
	orm := GetOrm().Table(m.TableName()).Where("open_id = ? ", OpenID).First(backUser)
	if orm.Error != nil {
		if orm.RecordNotFound() {
			return -1, nil
		}
	}
	return backUser.ID, nil
}
