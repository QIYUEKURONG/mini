package models

import (
	"16chao/def"
	"database/sql"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/astaxie/beego/logs"
	"github.com/jinzhu/gorm"
)

// ActivityModel  活动信息表
type ActivityModel struct {
	ID                int       `gorm:"column:activity_id;PRIMARY_KEY;AUTO_INCREMENT"` //活动ID
	Name              string    `gorm:"column:activity_name"`                          //活动名称
	Description       string    `gorm:"column:description"`                            //活动描述
	Image             string    `gorm:"column:image"`                                  //活动图片
	Status            int       `gorm:"column:activity_status"`                        //活动状态
	LocationLongitude float64   `gorm:"column:location_longitude"`                     //活动地点经度
	LocationLatitude  float64   `gorm:"column:location_latitude"`                      //活动地点纬度
	LocationName      string    `gorm:"column:location_name"`                          //活动中心点的名称
	MinMember         int       `gorm:"column:min_member"`                             //活动最少人数
	MaxMember         int       `gorm:"column:max_member"`                             //活动最大人数
	CurrentMember     int       `gorm:"column:current_member"`                         //活动当前人数
	StartTime         time.Time `gorm:"column:start_time"`                             //活动开始时间
	EndTime           time.Time `gorm:"column:end_time"`                               //活动结束时间
	LabelID           int       `gorm:"column:label_id"`                               //活动类型
	Ctime             time.Time `gorm:"column:c_time"`
	Utime             time.Time `gorm:"column:u_time"`
}

var defaultActivityModel *ActivityModel
var activityModelOnce sync.Once

// TableName 定义表名
func (m *ActivityModel) TableName() string {
	return fmt.Sprintf("activity")
}

// GetActivityModel get ActivityModel object
func GetActivityModel() *ActivityModel {
	activityModelOnce.Do(func() {
		defaultActivityModel = &ActivityModel{}
	})

	return defaultActivityModel
}

// InsertOne 插入一条记录
func (m *ActivityModel) InsertOne(record *ActivityModel) error {
	if GetOrm() == nil {
		return errors.New("GetOrm is nil")
	}
	if record == nil {
		return errors.New("record is nil")
	}
	record.Ctime = time.Now()
	record.Utime = time.Now()
	return GetOrm().Create(record).Error
}

//DeleteActivity 删除一条活动记录
func (m *ActivityModel) DeleteActivity(aid int) error {
	if GetOrm() == nil {
		return errors.New("GetOrm is nil")
	}
	return GetOrm().Delete(&ActivityModel{}, &ActivityModel{ID: aid}).Error
}

//UpdateStateByActivityID 根据 aid 更新 status
func (m *ActivityModel) UpdateStateByActivityID(aid int, status int) (err error) {
	if aid == 0 {
		return nil
	}

	updateCols := make(map[string]interface{}, 1)
	updateCols["activity_status"] = status

	return m.UpdateColsByActivityID(aid, updateCols)
}

//UpdateCurrentMemberByActivityID 根据 aid 更新 current_member
func (m *ActivityModel) UpdateCurrentMemberByActivityID(aid, currentMember int) (err error) {
	if aid == 0 {
		return errors.New("ActivityID is 0")
	}

	updateCols := make(map[string]interface{}, 1)
	updateCols["current_member"] = currentMember

	return m.UpdateColsByActivityID(aid, updateCols)
}

//UpdateColsByActivityID 利用map更新活动
func (m *ActivityModel) UpdateColsByActivityID(aid int, updateCols map[string]interface{}) error {

	// 无更新
	if len(updateCols) <= 0 {
		return nil
	}

	if GetOrm() == nil {
		return errors.New("GetOrm is nil")
	}

	return GetOrm().Table(m.TableName()).Where("activity_id = ?", aid).Updates(updateCols).Error
}

//GetActivityByID 通过活动ID获取activityModel,如果不存在返回空Model
func (m *ActivityModel) GetActivityByID(aid int) (ac *ActivityModel, err error) {
	if GetOrm() == nil {
		return nil, errors.New("GetOrm is nil")
	}

	backActivity := new(ActivityModel)

	tableName := m.TableName()
	orm := GetOrm().Table(tableName).Where("activity_id = ?", aid).First(backActivity)
	if orm.Error != nil {
		if orm.RecordNotFound() {
			return nil, orm.Error
		}
	}

	return backActivity, orm.Error
}

//GetActivitysByCondition 通过userId获取当前没有参加过的活动列表
func (m *ActivityModel) GetActivitysByCondition(list []*ActivityMemberListModel, condition string) ([]*ActivityModel, error) {
	var s string
	var rows *sql.Rows
	orm := GetOrm()
	// for _, arr := range list {
	// 	s = append(s, arr.ActivityID)
	// }
	for index, arr := range list {
		if index == len(list)-1 {
			s += strconv.Itoa(arr.ActivityID)
		} else {
			s += strconv.Itoa(arr.ActivityID) + ","
		}
	}
	//fmt.Println(s)
	// prepare and execute sql
	//condition 0：运动类型 1：start_time 2：end_time
	var sqlstr string
	cSpl := strings.Split(condition, "limit")
	if len(cSpl) == 1 {
		if s == "" {
			if condition != "" {
				sqlstr = fmt.Sprintf("select * from activity where activity_status = 0 and " + condition)
			} else {
				sqlstr = fmt.Sprintf("select * from activity where activity_status = 0")
			}
		} else {
			if condition != "" {
				sqlstr = fmt.Sprintf("select * from activity where activity_status = 0 and activity_id  not in (" + s + ") and " + condition)
			} else {
				sqlstr = fmt.Sprintf("select * from activity where activity_status = 0 and activity_id  not in (" + s + ") ")
			}
		}
	} else {
		if s == "" {
			sqlstr = fmt.Sprintf("select * from activity where activity_status = 0 " + condition)
		} else {
			sqlstr = fmt.Sprintf("select * from activity where activity_status = 0 and activity_id  not in (" + s + ") " + condition)
		}
	}

	if orm.RecordNotFound() {
		return nil, nil
	}

	logs.Info("sqlstr::: %s", sqlstr)
	rows, err := mySQLQuery(sqlstr)
	if err != nil {
		logs.Warn("mySQLQuery failed for %v", err)
		return nil, err
	}
	defer rows.Close()
	dataArray := make([]*ActivityModel, 0)
	for rows.Next() {
		var row ActivityModel
		err = rows.Scan(&row.ID,
			&row.Name,
			&row.Description,
			&row.Image, &row.Status,
			&row.LocationLongitude,
			&row.LocationLatitude,
			&row.LocationName,
			&row.MinMember,
			&row.MaxMember,
			&row.CurrentMember,
			&row.StartTime,
			&row.EndTime,
			&row.LabelID,
			&row.Ctime,
			&row.Utime)

		if err != nil {
			if err == sql.ErrNoRows || err == gorm.ErrRecordNotFound {
				return nil, nil
			}
			logs.Warn("mySQLQueryRow failed for %v", err)
			return nil, err
		}

		dataArray = append(dataArray, &row)
	}
	// for _, data := range dataArray {
	// 	fmt.Println("ac ID: ", data.ID)
	// }
	return dataArray, nil
}

//GetActivityByLabelIDs 通过label IDs获取activityModel,并且可以排除掉已参加的活动（excludeList）
func (m *ActivityModel) GetActivityByLabelIDs(LabelIDs []int, size int, excludeList []*ActivityMemberListModel) (ac []ActivityModel, err error) {
	if GetOrm() == nil {
		return nil, errors.New("GetOrm is nil")
	}
	excludeAcIDs := make([]int, 0)
	if excludeList != nil {
		for _, v := range excludeList {
			excludeAcIDs = append(excludeAcIDs, v.ActivityID)
		}
	}

	backActivity := make([]ActivityModel, 0)
	var orm *gorm.DB
	if len(excludeAcIDs) > 0 {
		orm = GetOrm().Table(m.TableName()).Where("  activity_status = 0 and label_id in (?)", LabelIDs).Not("activity_id", excludeAcIDs).Limit(size).Find(&backActivity)
	} else {
		orm = GetOrm().Table(m.TableName()).Where(" activity_status = 0 and label_id in (?)", LabelIDs).Limit(size).Find(&backActivity)
	}

	if orm.Error != nil {
		if orm.RecordNotFound() {
			return nil, nil
		}
	}

	return backActivity, orm.Error
}

//UpdateStatus ...updateType 0 活动转为进行中更新状态   1 活动转为结束进行更新状态
func (m *ActivityModel) UpdateStatus(aid int, updateType int) error {
	if GetOrm() == nil {
		return errors.New("GetOrm is nil")
	}
	tableName := m.TableName()
	// 状态3（StatActivityFinished ） 状态4（StatDismissed ）  不用更新 其他更新为Statbein
	if updateType == 0 {
		orm1 := GetOrm().Table(tableName).Where("activity_id=? AND activity_status!=3 AND activity_status!=4 ", aid).Update("activity_status", def.Statbein)
		logs.Info("update 1: %d", orm1.RowsAffected)
		if orm1.Error != nil {
			return orm1.Error
		}
	} else {
		// 状态3（StatActivityFinished ） 状态4（StatDismissed ）  不用更新 其他更新为StatActivityFinished
		orm2 := GetOrm().Table(tableName).Where("activity_id=? AND activity_status!=3 AND activity_status!=4 ", aid).Update("activity_status", def.StatActivityFinished)
		logs.Info("update 2: %d", orm2.RowsAffected)
		if orm2.Error != nil {
			return orm2.Error
		}
	}
	return nil
}

/*
//UpdateStatusInDataBase ...
func (m *ActivityModel) UpdateStatusInDataBase() error {
	if GetOrm() == nil {
		return errors.New("GetOrm is nil")
	}
	tableName := m.TableName()
	orm1 := GetOrm().Table(tableName).Where("activity_status!=3 AND activity_status!=4 AND start_time <= ? AND end_time > ?", time.Now(), time.Now()).Update("activity_status", 2)
	if orm1.Error != nil {
		return orm1.Error
	}
	orm2 := GetOrm().Table(tableName).Where("activity_status!=3 AND activity_status!=4 AND end_time < ?", time.Now()).Update("activity_status", 3)
	if orm2.Error != nil {
		return orm2.Error
	}
	return nil
}
*/

//TransferData ...
func (m *ActivityModel) TransferData() error {
	if GetOrm() == nil {
		return errors.New("GetOrm is nil")
	}
	var Activities []ActivityModel
	tableName := m.TableName()
	orm := GetOrm().Table(tableName).Find(&Activities)
	if orm.Error != nil {
		return orm.Error
	}
	for i := 0; i < len(Activities); i++ {
		var temp def.ActivityTime
		temp.ActivityID = Activities[i].ID
		temp.StartTime = Activities[i].StartTime
		temp.EndTime = Activities[i].EndTime
		temp.Status = Activities[i].Status
		def.ActivityTimeList = append(def.ActivityTimeList, temp)
	}
	return nil
}
