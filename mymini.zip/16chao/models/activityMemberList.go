package models

import (
	"errors"
	"sync"

	"github.com/astaxie/beego/orm"
)

//ActivityMemberListModel 活动与成员关系表
type ActivityMemberListModel struct {
	ActivityMemberListID int `orm:"column(activity_member_list_id);pk" description:"活动ID"`
	ActivityID           int `orm:"column(activity_id)" description:"活动ID"`
	UserID               int `orm:"column(user_id)" description:"用户ID"`
	IsCaptain            int `orm:"column(is_captain);null" description:"用来判断该活动成员是否为队长  1 是 0 不是"`
}

var defaultActivityMemberListModel *ActivityMemberListModel
var activityMemberListModelOnce sync.Once

//TableName 定义表名
func (t *ActivityMemberListModel) TableName() string {
	return "activity_member_list"
}

// func init() {
// 	orm.RegisterModel(new(ActivityMemberListModel))
// }

// GetActivityMemberListModel get ActivityMemberListModel object
func GetActivityMemberListModel() *ActivityMemberListModel {
	activityMemberListModelOnce.Do(func() {
		defaultActivityMemberListModel = &ActivityMemberListModel{}
	})

	return defaultActivityMemberListModel
}

//GetActivityMemberListByActivityID 根据ActivityID查询活动成员信息
func (t *ActivityMemberListModel) GetActivityMemberListByActivityID(uid int) (ac []ActivityMemberListModel, err error) {
	if GetOrm() == nil {
		return nil, errors.New("GetOrm is nil")
	}

	var backActivity []ActivityMemberListModel

	tableName := t.TableName()
	orm := GetOrm().Table(tableName).Where("activity_id = ?", uid).Find(&backActivity)

	// var result []int
	// orm := GetOrm().Table(tableName).Where("activity_id = ?", uid).Find(result)

	if orm.Error != nil {
		if orm.RecordNotFound() {
			return nil, nil
		}
	}
	return backActivity, err
}

//InsertOne 表里添加数据
func (t *ActivityMemberListModel) InsertOne(record *ActivityMemberListModel) error {
	if GetOrm() == nil {
		return errors.New("GetOrm is nil")
	}

	if record == nil {
		return errors.New("record is nil")
	}
	return GetOrm().Create(record).Error
}

//GetActivtityByUserID 根据user_id查找activityMemberList里所有的活动！！！不管状态
func (t *ActivityMemberListModel) GetActivtityByUserID(userID int) ([]int, error) {
	if GetOrm() == nil {
		return nil, errors.New("GetOrm is nil")
	}
	tableName := t.TableName()
	//将查询返回的ActivityMemberListModel存放到backActivity中
	backActivity := make([]ActivityMemberListModel, 0)
	orm := GetOrm().Table(tableName).Where("user_id = ?", userID).Find(&backActivity)
	if orm.Error != nil {
		if orm.RecordNotFound() {
			return nil, nil
		}
	}
	//遍历backActivity 返回活动id
	aid := make([]int, 0)
	for i := 0; i < len(backActivity); i++ {
		aid = append(aid, backActivity[i].ActivityID)
	}
	return aid, orm.Error
}

func init() {
	orm.RegisterModel(new(ActivityMemberListModel))
}

//Delete 根据ActivityMemberListID删除一条记录
func (t *ActivityMemberListModel) Delete(activitymemberListID int) error {
	//return "activity_member_list"
	if GetOrm() == nil {
		return errors.New("GetOrm is nil")
	}
	return GetOrm().Delete(&ActivityMemberListModel{}, &ActivityMemberListModel{ActivityMemberListID: activitymemberListID}).Error
}

// GetActivityMemberInfo 根据user_id，activity_id查询一条记录
func (t *ActivityMemberListModel) GetActivityMemberInfo(userID, activityID int) (ret *ActivityMemberListModel, err error) {
	if GetOrm() == nil {
		return nil, errors.New("GetOrm is nil")
	}

	activitymemberInfo := new(ActivityMemberListModel)
	orm := GetOrm().Where(&ActivityMemberListModel{ActivityID: activityID, UserID: userID}).First(activitymemberInfo)
	return activitymemberInfo, orm.Error
}

// GetActivityMemberInfotwo  根据user_id，activity_id查询一条记录(two)
func (t *ActivityMemberListModel) GetActivityMemberInfotwo(userID, activityID int) (ret *ActivityMemberListModel, err error) {
	if GetOrm() == nil {
		return nil, errors.New("GetOrm is nil")
	}

	activitymemberInfo := new(ActivityMemberListModel)
	orm := GetOrm().Where(&ActivityMemberListModel{ActivityID: activityID, UserID: userID}).First(activitymemberInfo)
	if orm.Error != nil {
		if orm.RecordNotFound() {
			return nil, nil
		}
	}
	return activitymemberInfo, orm.Error
}

//DeleteActivityMemberList 利用activity_member_list_id删除一条活动记录
func (t *ActivityMemberListModel) DeleteActivityMemberList(aid int) error {
	if GetOrm() == nil {
		return errors.New("GetOrm is nil")
	}
	return GetOrm().Delete(&ActivityMemberListModel{}, &ActivityMemberListModel{ActivityMemberListID: aid}).Error
}

//GetActivityMemberListByUserID 根据用户ID获取活动ID切片
func (t *ActivityMemberListModel) GetActivityMemberListByUserID(uid int) ([]*ActivityMemberListModel, error) {

	if GetOrm() == nil {
		return nil, errors.New("GetOrm is nil")
	}

	aml := make([]*ActivityMemberListModel, 0)

	orm := GetOrm().Where("user_id = ?", uid).Find(&aml)
	err := orm.Error
	if err != nil {
		if orm.RecordNotFound() {
			return nil, nil
		}
	}

	return aml, err
}

//GetCaptainIDByActivityID 根据活动ID查找队长ID
func (t *ActivityMemberListModel) GetCaptainIDByActivityID(aid int) (int, error) {

	if GetOrm() == nil {
		return -1, errors.New("GetOrm is nil")
	}
	aml := new(ActivityMemberListModel)
	orm := GetOrm().Where("activity_id = ? AND is_captain = 1", aid).Find(aml)
	err := orm.Error
	if err != nil {
		if orm.RecordNotFound() {
			return -1, orm.Error
		}
	}
	return aml.UserID, err
}
