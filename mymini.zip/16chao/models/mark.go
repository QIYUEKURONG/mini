package models

import (
	"16chao/def"
	"errors"
	"fmt"
	"strings"
	"sync"

	"github.com/astaxie/beego/logs"
)

// MarkModel  打分信息表
type MarkModel struct {
	MarkID       int     `gorm:"column:mark_id;PRIMARY_KEY;AUTO_INCREMENT"` //
	UserID       int     `gorm:"column:user_id"`                            // 用户ID
	TargetUserID int     `gorm:"column:target_user_id"`                     //被打分用户ID
	Score        float64 `gorm:"column:score"`                              //分数
	ActivityID   int     `gorm:"column:activity_id"`                        //在哪个活动中进行该次评价
	DefaultFlag  int     `gorm:"column:default_flag"`                       //是否默认好评
	//	CreatedAt time.Time `gorm:"column:ctime"`
	//	UpdatedAt time.Time `gorm:"column:utime"`
}

var defaultMarkModel *MarkModel
var markModelOnce sync.Once

// TableName 定义表名
func (m *MarkModel) TableName() string {
	return fmt.Sprintf("mark")
}

// GetMarkModel get MarkModel object
func GetMarkModel() *MarkModel {
	markModelOnce.Do(func() {
		defaultMarkModel = &MarkModel{}
	})

	return defaultMarkModel
}

// InsertOne 插入一条记录
func (m *MarkModel) InsertOne(record *MarkModel) error {
	if GetOrm() == nil {
		return errors.New("GetOrm is nil")
	}
	if record == nil {
		return errors.New("record is nil")
	}

	return GetOrm().Create(record).Error
}

// UpdateMarkScore 更新单对单的打分
func (m *MarkModel) UpdateMarkScore(record *MarkModel) error {
	if GetOrm() == nil {
		return errors.New("GetOrm is nil")
	}
	if record == nil {
		return errors.New("record is nil")
	}

	return GetOrm().Table(m.TableName()).Where("user_id = ? AND target_user_id = ? AND activity_id = ?", record.UserID, record.TargetUserID, record.ActivityID).Update(map[string]interface{}{"score": record.Score, "default_flag": record.DefaultFlag}).Error
}

// IsParamValid 检查打分参数
func (m *MarkModel) IsParamValid(UserID, TargetUserID, ActivityID int) (int, error) {

	if GetOrm() == nil {
		return 0, errors.New("GetOrm is nil")
	}
	ret := &MarkModel{}
	orm := GetOrm().Table(m.TableName()).Where("user_id = ? AND target_user_id = ? AND activity_id = ? ", UserID, TargetUserID, ActivityID).First(ret)
	if orm.Error != nil {
		if orm.RecordNotFound() {
			return 0, errors.New("参数有误")
		}
		return 0, orm.Error
	}
	return 1, nil
}

// CalculateUserScore 统计用户所有参加过的活动中的评分，计算出总分数
func (m *MarkModel) CalculateUserScore(UserID int) (float64, int, error) {

	if GetOrm() == nil {
		return 0, 0, errors.New("GetOrm is nil")
	}
	markedInfo := make([]MarkModel, 0)
	orm := GetOrm().Table(m.TableName()).Select("score").Where("target_user_id = ? ", UserID).Find(&markedInfo)
	if orm.Error != nil {
		return 0, 0, orm.Error
	}
	if len(markedInfo) == 0 {
		return 0, 0, fmt.Errorf("no record found (user id: %d)", UserID)
	}
	var scoreCount float64
	for _, v := range markedInfo {
		scoreCount += v.Score
	}
	markNum := len(markedInfo)
	finalScore := scoreCount / (float64(markNum) * def.MarkFullScore)

	return finalScore, markNum, nil
}

// GetDefaultMarkInfoByActivityID 查询一个活动中未被用户主动打分的所有记录
func (m *MarkModel) GetDefaultMarkInfoByActivityID(ActivityID int) ([]MarkModel, error) {

	if GetOrm() == nil {
		return nil, errors.New("GetOrm is nil")
	}
	markedInfo := make([]MarkModel, 0)
	orm := GetOrm().Table(m.TableName()).Where("activity_id = ? AND default_flag = ? ", ActivityID, def.DefaultMark).Find(&markedInfo)
	if orm.Error != nil {
		return nil, orm.Error
	}
	if len(markedInfo) == 0 {
		logs.Info("no default mark record found (activity_id id: %d)", ActivityID)
		return nil, nil
	}
	return markedInfo, nil
}

// CreateMarkRelationship 创建打分记录条目  （在活动结束之后）
func (m *MarkModel) CreateMarkRelationship(ActivityID int) error {
	//  返回nil代表参数检查合格
	if GetOrm() == nil {
		return errors.New("GetOrm is nil")
	}
	ret := &MarkModel{}
	orm := GetOrm().Table(m.TableName()).Where("activity_id = ? ", ActivityID).First(ret)
	exist := 1
	if orm.Error != nil {
		if orm.RecordNotFound() {
			exist = 0
		} else {
			return orm.Error
		}
	}
	if exist == 1 {
		return errors.New("该活动的打分关系条目已经建立，请勿重复创建")
	}

	// 查询活动人数
	actMemberList := make([]ActivityMemberListModel, 0)
	orm = GetOrm().Where("activity_id = ? ", ActivityID).Find(&actMemberList)
	if orm.Error != nil {
		if orm.RecordNotFound() {
			logs.Info("活动ID有误：%d  此次不做操作", ActivityID)
			return nil
		}
		return orm.Error

	}

	userNum := len(actMemberList)

	//查询活动表
	// actInfo := &models.ActivityModel{}
	// orm = GetOrm().Table(actInfo.TableName()).Where("activity_id = ? ", ActivityID).First(actInfo)
	// if orm.Error != nil {
	// 	if orm.RecordNotFound() {
	// 		return errors.New("activity_id 不存在")
	// 	} else {
	// 		return orm.Error
	// 	}
	// }
	//userNum :=actInfo.CurrentMember

	//创建 n × (n-1)条mark记录
	unsavedRows := make([]MarkModel, userNum*(userNum-1))
	addCnt := 0
	for i := 0; i < userNum; i++ {
		// actMemberList[i].UserID
		for j := 0; j < userNum; j++ {
			if j != i { // 自己不能给自己打分
				tmp := MarkModel{

					UserID:       actMemberList[i].UserID,
					TargetUserID: actMemberList[j].UserID,
					Score:        def.MarkFullScore,
					ActivityID:   ActivityID,
					DefaultFlag:  def.DefaultMark,
				}
				unsavedRows[addCnt] = tmp
				addCnt++
			}
		}
	}
	valueStrings := make([]string, 0, len(unsavedRows))
	valueArgs := make([]interface{}, 0, len(unsavedRows)*5) // 注意这里的数字要和下面那个range中的条目数量一致
	for _, post := range unsavedRows {
		valueStrings = append(valueStrings, "(?, ?, ?, ?, ?)")
		valueArgs = append(valueArgs, post.UserID)
		valueArgs = append(valueArgs, post.TargetUserID)
		valueArgs = append(valueArgs, post.ActivityID)
		valueArgs = append(valueArgs, post.Score)
		valueArgs = append(valueArgs, post.DefaultFlag)
	}

	stmt := fmt.Sprintf("INSERT INTO %s (user_id, target_user_id, activity_id,score, default_flag ) VALUES %s", m.TableName(), strings.Join(valueStrings, ","))
	_, err := mySQLQuery(stmt, valueArgs...)
	if err != nil {
		logs.Warn("mySQLQuery failed for %v", err)
		return err
	}
	// _, err := db.Exec(stmt, valueArgs...)
	// return err

	return nil
}
