package models

import (
	"database/sql"
	"errors"
	"fmt"

	//"go-common/pos/zctorder"
	"time"

	"github.com/astaxie/beego/logs"
	"github.com/jinzhu/gorm"
	"github.com/shopspring/decimal"
)

// GetDB 取得数据库引用
func GetDB() (*sql.DB, error) {
	db := OrmMap["default"].DB()
	if db == nil {
		return nil, errors.New("db is nil")
	}

	return db, nil
}

// GetSecureDB 取得ztkpossecure数据的连接，兑换密码存储在这个数据库
func GetSecureDB() (*sql.DB, error) {

	db := OrmMap["PosSecureDB"].DB()
	if db == nil {
		return nil, errors.New("db is nil")
	}

	return db, nil
}

// GetSecureOrm 取得ztkpossecure数据库的gorm实例，保存兑换密码
func GetSecureOrm() *gorm.DB {
	return OrmMap["PosSecureDB"]
}

// GetOrm 获取gorm的实例
func GetOrm() *gorm.DB {
	orm := OrmMap["default"]
	if orm == nil {
		return nil
	}

	return orm
}

// GetSlaveOrm 获取slave的gorm实例
func GetSlaveOrm() *gorm.DB {
	orm := OrmMap["slave"]
	if orm == nil {
		return nil
	}

	return orm
}

// GetTableName 取得对应的表名称
func GetTableName(prefix string, t time.Time) string {
	return prefix + t.Format("200601")
}

// IsTableExist 判断表是否存在
func IsTableExist(tblName string) (bool, error) {
	db, err := GetDB()
	if err != nil {
		return false, err
	}

	rows, err := db.Query("SELECT COUNT(1) AS COUNT FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME=?", tblName)
	if err != nil {
		logs.Error("ERROR_DB,%v", err)
		return false, err
	}
	defer rows.Close()

	var count int
	for rows.Next() {
		rows.Scan(&count)
	}

	if 0 == count {
		return false, nil
	}

	return true, nil
}

// AddAuthCode 新增一个付款码
func AddAuthCode(userid, authCode string, expired int) error {
	db, err := GetDB()
	if err != nil {
		return err
	}

	sql := fmt.Sprintf("INSERT INTO `tbl_pos_user_paycode` (`user_id`,`auth_code`,`time_expired`,`state`) VALUES (\"%s\",\"%s\", DATE_ADD(NOW(), INTERVAL %d SECOND), %d);",
		userid, authCode, expired, 1)
	logs.Debug("sql: %s", sql)
	res, err := db.Exec(sql)
	if err != nil {
		logs.Error("ERROR_DB, AddAuthCode failed, %v", err)
		return err
	}

	if aff, _ := res.RowsAffected(); aff != 1 {
		err = fmt.Errorf("add AddAuthCode fail,aff=%d", aff)
		logs.Warn("WARN_AuthCode_Dup, %v", err)
		return err
	}

	return nil
}

//TransferRecord ....
type TransferRecord struct {
	ID          int64
	OrderID     string
	TransferID  string
	To          string
	ToTxID      int64
	From        string
	FromTxID    int64
	Amount      decimal.Decimal
	Type        int
	Tag         string
	ToBalance   decimal.Decimal
	FromBalance decimal.Decimal
	Ctime       string
	Utime       string
}

//UpdateUserPasswd update user passwd
func UpdateUserPasswd(userID, salt, passwd string) error {
	// 密码写入到 ztkpossecure数据库中
	secureDB, err := GetSecureDB()
	if err != nil {
		return err
	}
	_, err = secureDB.Exec("INSERT INTO `tbl_pos_password` (`user_id`,`passwd`,`salt`) VALUES (?,?,?) ON DUPLICATE KEY UPDATE `passwd` = ?,`salt`=?;", userID, passwd, salt, passwd, salt)
	if err != nil {
		logs.Error("ERROR_DB, update user passwd failed %v", err)
		return err
	}

	return nil
}

//GetPaymemtResult ...
func GetPaymemtResult(orderid string) {

}
