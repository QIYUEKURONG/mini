//Package models 该文件由ZHB编写
package models

import (
	"errors"
	"fmt"
	"sync"
)

//LabelCategoryModel 活动大类表
type LabelCategoryModel struct {
	LabelCategoryID      int    `orm:"column(label_category_id);null" description:"活动大类ID"`
	LabelCategoryName    string `orm:"column(label_category_name);size(255);null" description:"活动大类名"`
	LabelCategoryPicture string `orm:"column(label_category_picture);size(255);null" description:"活动大类图片"`
}

var defaultLabelCategoryModel *LabelCategoryModel
var labelCategoryModelOnce sync.Once

//TableName 定义表名
func (t *LabelCategoryModel) TableName() string {
	return fmt.Sprintf("label_category")
}

//GetLabelCategoryModel 获取一个实例
func GetLabelCategoryModel() *LabelCategoryModel {
	labelCategoryModelOnce.Do(func() {
		defaultLabelCategoryModel = &LabelCategoryModel{}
	})

	return defaultLabelCategoryModel
}

// InsertOne 插入一条记录
func (t *LabelCategoryModel) InsertOne(record *LabelCategoryModel) error {
	if GetOrm() == nil {
		return errors.New("GetOrm is nil")
	}

	if record == nil {
		return errors.New("record is nil")
	}

	return GetOrm().Create(record).Error
}

//GetLabelCategoryByID 通过LabelCategoryID获取LabelCategoryModel
func (t *LabelCategoryModel) GetLabelCategoryByID(uid int) (ac *LabelCategoryModel, err error) {
	if GetOrm() == nil {
		return nil, errors.New("GetOrm is nil")
	}
	backLabelCategory := new(LabelCategoryModel)
	orm := GetOrm().Table(t.TableName()).Where("label_category_id = ?", uid).First(backLabelCategory)
	if orm.Error != nil {
		if orm.RecordNotFound() {
			return nil, nil
		}
	}
	return backLabelCategory, orm.Error
}

//GetAllLabelCategory 获取整个活动大类表
func (t *LabelCategoryModel) GetAllLabelCategory() ([]LabelCategoryModel, error) {
	if GetOrm() == nil {
		return nil, errors.New("GetOrm is nil")
	}

	var allLabelCategory []LabelCategoryModel
	orm := GetOrm().Table(t.TableName()).Find(&allLabelCategory)

	if orm.Error != nil {
		//如果查询为空，说明没有建立活动类型表
		if orm.RecordNotFound() {
			return nil, nil
		}
	}

	return allLabelCategory, orm.Error
}
