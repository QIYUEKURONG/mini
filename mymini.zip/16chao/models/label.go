package models

import (
	"errors"
	"fmt"
	"sync"
)

//LabelModel 活动类型表
type LabelModel struct {
	LabelID         int    `orm:"column(label_id);pk" description:"活动类型ID"`
	LabelName       string `orm:"column(label_name);size(255);null" description:"活动类型"`
	LabelPicture    string `orm:"column(label_picture);size(255);null" description:"活动默认图片"`
	LabelCategoryID int    `orm:"column(label_category_id);null" description:"活动所属大类ID"`
}

var defaultLabelModel *LabelModel
var labelModelOnce sync.Once

//TableName 定义表名
func (t *LabelModel) TableName() string {
	return fmt.Sprintf("label")
}

// GetLabelModel get LabelModel object
func GetLabelModel() *LabelModel {
	labelModelOnce.Do(func() {
		defaultLabelModel = &LabelModel{}
	})

	return defaultLabelModel
}

// func init() {
// 	orm.RegisterModel(new(LabelModel))
// }

// InsertOne 插入一条记录
func (t *LabelModel) InsertOne(record *LabelModel) error {
	if GetOrm() == nil {
		return errors.New("GetOrm is nil")
	}

	if record == nil {
		return errors.New("record is nil")
	}

	return GetOrm().Create(record).Error
}

//GetLabelByID 通过labelID获取activityModel
func (t *LabelModel) GetLabelByID(uid int) (ac *LabelModel, err error) {
	if GetOrm() == nil {
		return nil, errors.New("GetOrm is nil")
	}
	backLabel := new(LabelModel)
	tableName := t.TableName()
	orm := GetOrm().Table(tableName).Where("label_id = ?", uid).First(backLabel)
	if orm.Error != nil {
		if orm.RecordNotFound() {
			return nil, nil
		}
	}
	return backLabel, orm.Error
}

//GetLabelIDByName 通过label_name获取label_id,如果不存在返回-1
func (t *LabelModel) GetLabelIDByName(labelName string) (aid int, err error) {
	if GetOrm() == nil {
		return -1, errors.New("GetOrm is nil")
	}
	tableName := t.TableName()
	ret := new(LabelModel)
	orm := GetOrm().Table(tableName).Where("label_name = ?", labelName).First(ret)
	if orm.Error != nil {
		if orm.RecordNotFound() {
			return -1, nil
		}
	}
	return ret.LabelID, orm.Error
}

//GetLabelNamesByIDs 根据label ID获取label name
func (t *LabelModel) GetLabelNamesByIDs(LabelIDs []int) ([]string, error) {
	if GetOrm() == nil {
		return nil, errors.New("GetOrm is nil")
	}

	labelNames := make([]string, 0)
	orm := GetOrm().Table(t.TableName()).Where("label_id in (?)", LabelIDs).Find(&labelNames)
	if orm.Error != nil {
		if orm.RecordNotFound() {
			return nil, nil
		}
	}
	return labelNames, orm.Error
}

//GetLabelNameByLabelID 根据label_id查询label_name（ZHB）
func (t *LabelModel) GetLabelNameByLabelID(LabelID int) (string, error) {
	if GetOrm() == nil {
		return "", errors.New("GetOrm is nil")
	}

	labelInfo := new(LabelModel)
	orm := GetOrm().Table(t.TableName()).Where("label_id = ?", LabelID).First(labelInfo)
	if orm.Error != nil {
		if orm.RecordNotFound() {
			return "", nil
		}
	}

	return labelInfo.LabelName, orm.Error
}

//GetAllLabel 获取整个活动类型表（ZHB）
func (t *LabelModel) GetAllLabel() ([]LabelModel, error) {
	if GetOrm() == nil {
		return nil, errors.New("GetOrm is nil")
	}

	var allLabel []LabelModel
	orm := GetOrm().Table(t.TableName()).Find(&allLabel)

	if orm.Error != nil {
		//如果查询为空，说明没有建立活动类型表
		if orm.RecordNotFound() {
			return nil, nil
		}
	}

	return allLabel, orm.Error
}

//GetLabelNum 获取活动类型数量（ZHB）
func (t *LabelModel) GetLabelNum() (int, error) {
	if GetOrm() == nil {
		return 0, errors.New("GetOrm is nil")
	}

	var num int
	orm := GetOrm().Table(t.TableName()).Count(&num)

	return num, orm.Error
}

// //DeleteLabel 删除一条活动记录
// func (t *LabelModel) DeleteLabel(aid int) error {
// 	if GetOrm() == nil {
// 		return errors.New("GetOrm is nil")
// 	}
// 	return GetOrm().Delete(&LabelModel{}, &LabelModel{LabelID: aid}).Error
// }

// //updateColsByActivityID 利用map更新活动
// func (t *LabelModel) updateColsByLabelID(lid int, updateCols map[string]interface{}) error {

// 	// 无更新
// 	if len(updateCols) <= 0 {
// 		return nil
// 	}

// 	if GetOrm() == nil {
// 		return errors.New("GetOrm is nil")
// 	}

// 	return GetOrm().Table(t.TableName()).Where("label_id = ?", lid).Updates(updateCols).Error
// }
