package models

import (
	"fmt"

	"github.com/astaxie/beego/orm"
)

//MessageModel 消息表
type MessageModel struct {
	ID                 int     `orm:"column(message_id);auto" description:"消息ID"`
	ActivityID         int     `orm:"column(activity_id)" description:"活动ID"`
	UserID             int     `orm:"column(user_id)" description:"用户ID"`
	MessageContent     string  `orm:"column(message_content);size(255);null" description:"存储消息的内容"`
	MessageTime        string  `orm:"column(message_time);size(255)" description:"消息发送时间"`
	DistanceToActivity float64 `orm:"column(distance_to_activity)" description:"用户发送消息时距离活动中心的距离"`
}

//TableName 定义表名
func (t *MessageModel) TableName() string {
	return fmt.Sprintf("message")
}

func init() {
	orm.RegisterModel(new(MessageModel))
}

// AddMessage insert a new Message into database and returns
// last inserted Id on success.
// func AddMessage(m *MessageModel) (id int64, err error) {
// 	o := orm.NewOrm()
// 	id, err = o.Insert(m)
// 	return
// }

// // GetMessageByID 按ID检索消息。如果Id不存在，则返回错误
// func GetMessageByID(id int) (v *MessageModel, err error) {
// 	o := orm.NewOrm()
// 	v = &MessageModel{ID: id}
// 	if err = o.Read(v); err == nil {
// 		return v, nil
// 	}
// 	return nil, err
// }

// // GetAllMessage 检索所有Message匹配的特定条件。如果不存在记录，则返回空列表
// func GetAllMessage(query map[string]string, fields []string, sortby []string, order []string,
// 	offset int64, limit int64) (ml []interface{}, err error) {
// 	o := orm.NewOrm()
// 	qs := o.QueryTable(new(MessageModel))
// 	// query k=v
// 	for k, v := range query {
// 		// rewrite dot-notation to Object__Attribute
// 		k = strings.Replace(k, ".", "__", -1)
// 		if strings.Contains(k, "isnull") {
// 			qs = qs.Filter(k, (v == "true" || v == "1"))
// 		} else {
// 			qs = qs.Filter(k, v)
// 		}
// 	}
// 	// order by:
// 	var sortFields []string
// 	if len(sortby) != 0 {
// 		if len(sortby) == len(order) {
// 			// 1) for each sort field, there is an associated order
// 			for i, v := range sortby {
// 				orderby := ""
// 				if order[i] == "desc" {
// 					orderby = "-" + v
// 				} else if order[i] == "asc" {
// 					orderby = v
// 				} else {
// 					return nil, errors.New("Error: Invalid order. Must be either [asc|desc]")
// 				}
// 				sortFields = append(sortFields, orderby)
// 			}
// 			qs = qs.OrderBy(sortFields...)
// 		} else if len(sortby) != len(order) && len(order) == 1 {
// 			// 2) there is exactly one order, all the sorted fields will be sorted by this order
// 			for _, v := range sortby {
// 				orderby := ""
// 				if order[0] == "desc" {
// 					orderby = "-" + v
// 				} else if order[0] == "asc" {
// 					orderby = v
// 				} else {
// 					return nil, errors.New("Error: Invalid order. Must be either [asc|desc]")
// 				}
// 				sortFields = append(sortFields, orderby)
// 			}
// 		} else if len(sortby) != len(order) && len(order) != 1 {
// 			return nil, errors.New("Error: 'sortby', 'order' sizes mismatch or 'order' size is not 1")
// 		}
// 	} else {
// 		if len(order) != 0 {
// 			return nil, errors.New("Error: unused 'order' fields")
// 		}
// 	}

// 	var l []MessageModel
// 	qs = qs.OrderBy(sortFields...)
// 	if _, err = qs.Limit(limit, offset).All(&l, fields...); err == nil {
// 		if len(fields) == 0 {
// 			for _, v := range l {
// 				ml = append(ml, v)
// 			}
// 		} else {
// 			// trim unused fields
// 			for _, v := range l {
// 				m := make(map[string]interface{})
// 				val := reflect.ValueOf(v)
// 				for _, fname := range fields {
// 					m[fname] = val.FieldByName(fname).Interface()
// 				}
// 				ml = append(ml, m)
// 			}
// 		}
// 		return ml, nil
// 	}
// 	return nil, err
// }

// // UpdateMessageByID 按ID更新消息，如果要更新的记录不存在，则返回错误
// func UpdateMessageByID(m *MessageModel) (err error) {
// 	o := orm.NewOrm()
// 	v := MessageModel{ID: m.ID}
// 	// ascertain id exists in the database
// 	if err = o.Read(&v); err == nil {
// 		var num int64
// 		if num, err = o.Update(m); err == nil {
// 			fmt.Println("Number of records updated in database:", num)
// 		}
// 	}
// 	return
// }

// // DeleteMessage 按Id删除消息，如果要删除的记录不存在，则返回错误
// func DeleteMessage(id int) (err error) {
// 	o := orm.NewOrm()
// 	v := MessageModel{ID: id}
// 	// ascertain id exists in the database
// 	if err = o.Read(&v); err == nil {
// 		var num int64
// 		if num, err = o.Delete(&MessageModel{ID: id}); err == nil {
// 			fmt.Println("Number of records deleted in database:", num)
// 		}
// 	}
// 	return
// }
