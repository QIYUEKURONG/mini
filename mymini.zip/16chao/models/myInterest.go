package models

import (
	"errors"
	"sync"

	"github.com/astaxie/beego/orm"
)

//MyInterestModel 兴趣表
type MyInterestModel struct {
	MyInterestID int `orm:"column(my_interest_id);pk" description:"兴趣ID"`
	UserID       int `orm:"column(user_id);null" description:"用户ID"`
	LabelID      int `orm:"column(label_id);null" description:"活动类型ID"`
}

var defaultMyInterestModel *MyInterestModel
var myInterestModelOnce sync.Once

//TableName 定义表名
func (m *MyInterestModel) TableName() string {
	return "my_interest"
}

func init() {
	orm.RegisterModel(new(MyInterestModel))
}

// GetMyInterestModel get MyInterestModel object
func GetMyInterestModel() *MyInterestModel {
	myInterestModelOnce.Do(func() {
		defaultMyInterestModel = &MyInterestModel{}
	})

	return defaultMyInterestModel
}

// InsertOne 插入一条记录
func (m *MyInterestModel) InsertOne(record *MyInterestModel) error {
	if GetOrm() == nil {
		return errors.New("GetOrm is nil")
	}

	if record == nil {
		return errors.New("record is nil")
	}

	return GetOrm().Create(record).Error
}

//GetLabelIDsByUserID 根据userID获取感兴趣的label IDs
func (m *MyInterestModel) GetLabelIDsByUserID(userID int) ([]int, error) {
	if GetOrm() == nil {
		return nil, errors.New("GetOrm is nil")
	}

	var lableIDs []MyInterestModel
	orm := GetOrm().Table(m.TableName()).Where("user_id = ?", userID).Find(&lableIDs)
	if orm.Error != nil {
		if orm.RecordNotFound() {
			return nil, nil
		}
	}

	var retID []int
	for _, value := range lableIDs {
		retID = append(retID, value.LabelID)
	}
	return retID, orm.Error
}

//GetMyInterestByUserID 根据user_id查询一组记录（ZHB）
func (m *MyInterestModel) GetMyInterestByUserID(userID int) ([]MyInterestModel, error) {
	if GetOrm() == nil {
		return nil, errors.New("GetOrm is nil")
	}

	var myInterest []MyInterestModel
	orm := GetOrm().Table(m.TableName()).Where("user_id = ?", userID).Find(&myInterest)

	if orm.Error != nil {
		//如果查询为空，说明没有记录，只是说明没有用户对应的记录，并不代表出错
		if orm.RecordNotFound() {
			return nil, nil
		}
	}

	return myInterest, orm.Error
}

//SearchInfoByUserIDAndLabelID 根据user_id和label_id查询记录是否存在，若存在则返回完整记录（ZHB）
func (m *MyInterestModel) SearchInfoByUserIDAndLabelID(userID int, labelID int) (bool, MyInterestModel, error) {
	if GetOrm() == nil {
		return false, MyInterestModel{}, errors.New("GetOrm is nil")
	}

	var myInterest MyInterestModel
	orm := GetOrm().Table(m.TableName()).Where("user_id = ? AND label_id = ?", userID, labelID).Find(&myInterest)

	if orm.Error != nil {
		//如果查询为空，说明没有记录，只是说明没有用户对应的记录，并不代表出错
		if orm.RecordNotFound() {
			return false, MyInterestModel{}, nil
		}
	}

	return true, myInterest, orm.Error
}

//DeleteByUserIDAndLabelID 根据user_id和label_id删除对应记录（ZHB）
func (m *MyInterestModel) DeleteByUserIDAndLabelID(userID int, labelID int) error {
	if GetOrm() == nil {
		return errors.New("GetOrm is nil")
	}

	return GetOrm().Table(m.TableName()).Delete(&MyInterestModel{}, &MyInterestModel{UserID: userID, LabelID: labelID}).Error
}

//DeleteByUserID 根据user_id删除所有记录（ZHB）
func (m *MyInterestModel) DeleteByUserID(userID int) error {
	if GetOrm() == nil {
		return errors.New("GetOrm is nil")
	}

	return GetOrm().Table(m.TableName()).Delete(&MyInterestModel{}, "user_id = ?", userID).Error
}
