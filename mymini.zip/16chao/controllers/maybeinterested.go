package controllers

import (
	"16chao/services"
	"16chao/util/errs"
	"encoding/json"
	"fmt"

	"github.com/astaxie/beego/logs"
)

var (
	longitudeMin float64 = -180
	longitudeMax float64 = 180
	latitudeMin  float64 = -90
	latitudeMax  float64 = 90
)

//MaybeInterestedController 可能感兴趣的活动
type MaybeInterestedController struct {
	BaseController
}

// MaybeInterestedParam  获取接口参数
type MaybeInterestedParam struct {
	UserID               int     `json:"user_id"`
	UserCurrentLongitude float64 `json:"user_current_longitude"`
	UserCurrentLatitude  float64 `json:"user_current_latitude"`
}

func (p *MaybeInterestedParam) isValid() error {
	if p.UserCurrentLongitude < longitudeMin || p.UserCurrentLongitude > longitudeMax || p.UserCurrentLatitude < latitudeMin || p.UserCurrentLatitude > latitudeMax {
		fmt.Printf("location is wrong: p.UserCurrentLongitude%f, p.UserCurrentLatitude: %f\n", p.UserCurrentLongitude, p.UserCurrentLatitude)
		return fmt.Errorf("location is wrong")
	}

	return nil
}

// MaybeInterested 用户可能感兴趣的活动
func (c *MaybeInterestedController) MaybeInterested() {
	var param MaybeInterestedParam
	// 获取参数
	logs.Info("\n\nMaybeInterested get json: %s", c.Ctx.Input.RequestBody)
	err := json.Unmarshal(c.Ctx.Input.RequestBody, &param)
	if err != nil {
		logs.Warn("MaybeInterested： invalid param, %v", err)
		c.apiFail(errs.NewAppFail("参数有误"))
		return
	}

	// 检验参数
	if err := param.isValid(); err != nil {
		logs.Warn("MaybeInterested param is error, err:%v", err)
		c.apiFail(errs.NewAppFail("参数有误"))
		return
	}
	// 调用 service 的业务处理
	ret, aEr := services.NewMaybeInterestedService().MaybeInterested(param.UserID, param.UserCurrentLongitude, param.UserCurrentLatitude)
	if aEr != nil {
		logs.Warn("MaybeInterested is error, aEr:%v", aEr)
		c.apiFail(errs.NewAppFail("查询失败"))
		return
	}

	out := make(map[string]interface{})
	out["status"] = "true"
	out["message"] = "数据返回成功"
	out["activities"] = ret
	logs.Info("MaybeInterested successful   ret:%v", ret)
	c.apiResult(out)
}
