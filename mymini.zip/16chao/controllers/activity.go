package controllers

import (
	"16chao/def"
	"16chao/models"
	"16chao/services"
	"16chao/util"
	"16chao/util/errs"
	"encoding/json"
	"fmt"
	"strconv"
	"time"

	"github.com/astaxie/beego/logs"
)

//ActivityController 活动信息相关接口
type ActivityController struct {
	BaseController
}

var (
	publishSuc  = "发出集结成功"
	publishFail = "发出集结失败"
)

// ActivityPublishParam  发出集结需要接收的活动参数信息
type ActivityPublishParam struct {
	UserID       int     `json:"user_id"`
	ActivityName string  `json:"activity_name"`
	LabelName    string  `json:"label_name"`
	StartTime    string  `json:"start_time"`
	EndTime      string  `json:"end_time"`
	MaxMember    int     `json:"max_member"`
	MinMember    int     `json:"min_member"`
	Longtitude   float64 `json:"location_longtitude"`
	Latitude     float64 `json:"location_latitude"`
	LocationName string  `json:"location_name"`
	Description  string  `json:"description"`
	ImgDefault   bool    `json:"img_default"`
	//Image        string  `json:"image"`
}

//isValid 判断用户的输入是否有效
func (p *ActivityPublishParam) isValid() error {
	//活动名称是否为空
	if p.ActivityName == "" {
		logs.Warn("activity_name is null")
		return fmt.Errorf("activity_name is null")
	}
	//活动人数是否正确，也是前端判断
	if p.MaxMember < p.MinMember || p.MaxMember < 0 || p.MinMember < 0 {
		logs.Warn("max_member is smaller than min_member, or the number is not correct")
		return fmt.Errorf("max_member is smaller than min_member, or the number is not correct")
	}
	// //活动时间,交由前端判断
	sTime, _ := time.ParseInLocation(def.TimeStampFmt, p.StartTime, time.Local)
	eTime, _ := time.ParseInLocation(def.TimeStampFmt, p.EndTime, time.Local)
	fmt.Println(sTime)
	fmt.Println(eTime)
	if eTime.Before(sTime) {
		logs.Warn("end_time is before start_time")
		return fmt.Errorf("end_time is before start_time")
	}
	//用户输入的label_name是否在label库里
	if ret, _ := models.GetLabelModel().GetLabelIDByName(p.LabelName); ret == -1 {
		logs.Warn("this type of label_name does not exist on database")
		return fmt.Errorf("this type of label_name does not exist on database")
	}
	return nil
}

//Publish 活动注册 将用户信息添加到数据库中
func (c *ActivityController) Publish() {
	var param ActivityPublishParam
	//	var response ActivityPublishResp
	// 获取参数
	logs.Info("\n[/v1/publish]rec json: %s\n\n", c.Ctx.Input.RequestBody)
	//json序列化到参数param中
	err := json.Unmarshal(c.Ctx.Input.RequestBody, &param)
	if err != nil {
		logs.Error("[/v1/publish]invalid param:, %v", err)
		c.apiError(errs.NewErrCode(def.ErrMsg[def.EInvalidParam], def.EInvalidParam))
		return
	}
	// 判断用户输入是否有效
	if err := param.isValid(); err != nil {
		logs.Warn("[/v1/publish]activity register param is error, err:%v", err)
		out := make(map[string]interface{})
		out["status"] = "false"
		out["message"] = publishFail
		out["activity_ID"] = -1
		c.apiResult(out)
		return
	}
	// 调用 service 中的具体业务处理，这里是Publish 发出集结
	ActivityID, _, aEr := services.NewActivityService().Publish(
		param.ActivityName, param.LabelName, param.LocationName, param.Description, "", param.StartTime, param.EndTime, param.UserID, param.MaxMember, param.MinMember, param.Longtitude, param.Latitude, param.ImgDefault)
	if aEr != nil {
		logs.Warn("[/v1/publish]publish is error, aEr:%v", aEr)
		out := make(map[string]interface{})
		out["status"] = "false"
		out["message"] = publishFail
		out["activity_ID"] = ActivityID
		c.apiResult(out)
		return
	}
	//response.UserID = userID
	logs.Info("[/v1/publish]activity publish success activity_id:%d", ActivityID)
	out := make(map[string]interface{})
	out["status"] = "true"
	out["message"] = publishSuc
	out["activity_ID"] = ActivityID
	c.apiResult(out)
	//c.apiSuccess(response)
}

//-----------------------------------------获取查看集结列表--------------------------------------------------

// ScanActivityRespL  查看集结列表返回结构
type ScanActivityRespL struct {
	List    []*ScanActivityResp `json:"activities"`
	Status  bool                `json:"status"`  //活动状态
	Message string              `json:"message"` //活动消息
}

// ScanActivityResp  查看集结列表返回结构
type ScanActivityResp struct {
	ID            int    `json:"activity_id"`    //活动ID
	Name          string `json:"activity_name"`  //活动名称
	Description   string `json:"description"`    //活动描述
	Image         string `json:"image"`          //活动图片
	LocationName  string `json:"location_name"`  //活动中心点的名称
	MinMember     int    `json:"min_member"`     //活动最少人数
	MaxMember     int    `json:"max_member"`     //活动最大人数
	CurrentMember int    `json:"current_member"` //活动当前人数
	StartTime     string `json:"start_time"`     //活动开始时间
	EndTime       string `json:"end_time"`       //活动结束时间
	Distance      string `json:"distance"`       //活动地点离自己的距离
}

// ScanActivityParam  活动参数信息
type ScanActivityParam struct {
	UserID     int     `json:"user_id"`
	Type       string  `json:"gather_type"`
	StartTime  string  `json:"gather_start_time"`
	EndTime    string  `json:"gather_end_time"`
	Latitude   float64 `json:"gather_latitude"`
	Longitude  float64 `json:"gather_longitude"`
	Radius     float64 `json:"gather_radius"`
	SortByTime string  `json:"sort_by_time"`
	SortByDis  string  `json:"sort_by_dis"`
}

const (
	//DESC 降序
	DESC string = "DESC"
	//ASC 升序
	ASC string = "ASC"
)

// ScanActivity 获取查看集结列表
func (c *ActivityController) ScanActivity() {
	var param ScanActivityParam
	var result ScanActivityRespL
	var distances []float64
	// 获取参数
	logs.Info("\n[/v1/scanActivity] rec json: %s\n\n", c.Ctx.Input.RequestBody)
	//json反序列化到参数param中
	err := json.Unmarshal(c.Ctx.Input.RequestBody, &param)
	if err != nil {
		logs.Warn("[/v1/scanActivity]invalid param:, %v", err)
		c.apiError(errs.NewErrCode(def.ErrMsg[def.EInvalidParam], def.EInvalidParam))
		return
	}
	list, distances, aEr := services.NewActivityService().ScanActivity(param.UserID, param.Type, param.StartTime, param.EndTime, param.Latitude, param.Longitude, param.Radius, param.SortByTime, param.SortByDis)
	if aEr != nil {
		logs.Warn("[/v1/scanActivity]ScanActivity is error, aEr:%v", aEr)
		c.apiError(aEr)
		return
	}

	//logs.Info("ScanActivity success acitivity_id:%d", Activity_ID)
	var tempList []*ScanActivityResp
	for index, temp := range list {
		var sc ScanActivityResp
		sc.CurrentMember = temp.CurrentMember
		sc.Description = temp.Description
		distanceTemp := util.Decimal(distances[index])
		if util.GetDecimalNumber(distanceTemp) == 0 {
			disToString := strconv.FormatFloat(distanceTemp, 'g', -1, 64)
			sc.Distance = disToString + "m"
		} else {
			disToString := strconv.FormatFloat(distanceTemp, 'g', -1, 64)
			sc.Distance = disToString + "km"
		}
		sc.EndTime = temp.EndTime.Format("2006-01-02 15:04:05")
		sc.ID = temp.ID
		sc.Image = temp.Image
		sc.LocationName = temp.LocationName
		sc.MaxMember = temp.MaxMember
		sc.MinMember = temp.MinMember
		sc.Name = temp.Name
		sc.StartTime = temp.StartTime.Format("2006-01-02 15:04:05")
		tempList = append(tempList, &sc)
	}
	result.List = tempList
	if result.List != nil {
		result.Status = true
		result.Message = "数据返回成功"
		logs.Info("[/v1/scanActivity]data get successful")
	} else {
		result.Status = false
		result.Message = "数据返回失败"
		logs.Info("[/v1/scanActivity]data get failed")
	}
	c.apiResult(result)
}
