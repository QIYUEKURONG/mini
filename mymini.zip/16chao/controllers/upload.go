package controllers

import (
	"fmt"
	"strings"

	"github.com/astaxie/beego/logs"

	"github.com/astaxie/beego"
)

//Demo3Controller 。。。
type Demo3Controller struct {
	beego.Controller
}

//Getfile ...
func (c *Demo3Controller) Getfile() {

	c.TplName = "upfile.html"

}

//Postfile ...
func (c *Demo3Controller) Postfile() {
	file, header, e := c.GetFile("file")

	defer file.Close()
	if e != nil {
		c.Ctx.WriteString("文件上传失败！" + fmt.Sprint(e))
	} else {

		headers := strings.Split(header.Filename, "\\")
		err := c.SaveToFile("file", "static"+"/"+headers[len(headers)-1])
		if err != nil {
			logs.Warn("文件保存失败！ ")
			c.Ctx.WriteString("文件保存失败！" + fmt.Sprint(err))
		} else {
			logs.Warn("文件保存成功！ ")
			c.Ctx.WriteString("文件保存成功！")
		}

	}

}
