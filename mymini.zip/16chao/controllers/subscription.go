//Package controllers 该文件由ZHB编写
package controllers

import (
	"16chao/services"
	"16chao/util/errs"
	"encoding/json"
	"fmt"

	"github.com/astaxie/beego/logs"
)

//SubscriptionController 订阅设置相关接口
type SubscriptionController struct {
	BaseController
}

//SubscriptionController 数据返回类型
var (
	SubscriptionSuc  = "数据返回成功"
	SubscriptionFail = "数据返回失败"
)

//SubscriptionController 数据修改类型
var (
	SubscriptionSettingSuc  = "修改成功"
	SubscriptionSettingFail = "修改失败"
)

// SubscriptionParam  查看订阅设置时的传入参数
type SubscriptionParam struct {
	UserID int `json:"user_id"`
}

// SubscriptionSettingParam  提交订阅设置时的传入参数
type SubscriptionSettingParam struct {
	UserID          int                            `json:"user_id"`
	SubscriptionSet []services.SubscriptionSetInfo `json:"subscription_set"`
}

//检查传入的用户id是否合法
func (s *SubscriptionParam) isValid() error {
	if s.UserID <= 0 {
		logs.Warn("user_id is invalid")
		return fmt.Errorf("user_id is invalid")
	}
	return nil
}

//检查传入的用户id及兴趣信息是否合法
func (s *SubscriptionSettingParam) isValid() error {
	//判断用户ID是否合法
	if s.UserID <= 0 {
		logs.Warn("user_id is invalid")
		return fmt.Errorf("user_id is invalid")
	}
	//判断兴趣是否为空
	if s.SubscriptionSet == nil {
		logs.Warn("subscription_set is invalid")
		return fmt.Errorf("subscription_set is invalid")
	}

	//如果兴趣不是空，则在兴趣信息当中逐条查看参数是否合法
	for _, value := range s.SubscriptionSet {
		//判断label_id是否合法
		if value.LabelID < 0 {
			logs.Warn("label_id is invalid")
			return fmt.Errorf("label_id is invalid")
		}
		//is_interest是boolean型，只有true与false两种情况，不需要判断参数的合法性
	}
	return nil
}

//Subscription 查看订阅设置
func (s *SubscriptionController) Subscription() {
	var param SubscriptionParam
	//从请求体中获取参数
	logs.Info("\nrec json: %s\n\n", s.Ctx.Input.RequestBody)
	//json序列化到参数param中
	err := json.Unmarshal(s.Ctx.Input.RequestBody, &param)
	if err != nil {
		logs.Warn("invalid param, %v", err)
		s.apiFail(errs.NewAppFail(SubscriptionFail))
		return
	}

	//判断输入参数是否有效
	if err := param.isValid(); err != nil {
		logs.Warn("subscription param is error, err:%v", err)
		s.apiFail(errs.NewAppFail(SubscriptionFail))
		return
	}

	//调用service的业务处理
	labelcategoryresp, myinterestresp, aEr := services.ViewSubscriptionService().Subscription(param.UserID)
	if aEr != nil {
		logs.Warn("subscription is error, aEr:%v", aEr)
		s.apiFail(errs.NewAppFail(SubscriptionFail))
		return
	}

	logs.Info("Subscription success")
	out := make(map[string]interface{})
	out["status"] = "true"
	out["message"] = SubscriptionSuc
	out["label_category"] = labelcategoryresp
	out["my_interest"] = myinterestresp
	s.apiResult(out)
}

//SubscriptionSetting 提交订阅设置
func (s *SubscriptionController) SubscriptionSetting() {
	var param SubscriptionSettingParam
	//从请求体中获取参数
	fmt.Printf("\nrec json: %s\n\n", s.Ctx.Input.RequestBody)
	//json序列化到参数param中
	err := json.Unmarshal(s.Ctx.Input.RequestBody, &param)
	if err != nil {
		logs.Warn("invalid param, %v", err)
		s.apiFail(errs.NewAppFail(SubscriptionSettingFail))
		return
	}

	//判断输入参数是否有效
	if err := param.isValid(); err != nil {
		logs.Warn("subscription param is error, err:%v", err)
		s.apiFail(errs.NewAppFail(SubscriptionSettingFail))
		return
	}

	//调用service的业务处理
	aEr := services.SubscriptionSettingService().SubscriptionSetting(param.UserID, param.SubscriptionSet)
	if aEr != nil {
		logs.Warn("SubscriptionSetting is error, aEr:%v", aEr)
		s.apiFail(errs.NewAppFail(SubscriptionSettingFail))
		return
	}

	logs.Info("SubscriptionSetting success")
	out := make(map[string]interface{})
	out["status"] = "true"
	out["message"] = SubscriptionSettingSuc
	s.apiResult(out)
}
