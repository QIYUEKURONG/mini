package controllers

import (
	"16chao/services"
	"16chao/util/errs"
	"encoding/json"

	"github.com/astaxie/beego/logs"
)

//KickPeopleController 踢人相关接口
type KickPeopleController struct {
	BaseController
}

// KickPeopleParam  踢人参数信息
type KickPeopleParam struct {
	UserCaptainID int `json:"usercaptain_id"` //队长ID
	UserPlayerID  int `json:"userplayer_id"`  //队员ID
	ActivityID    int `json:"activity_id"`
}

//KickPeopleResp 踢人返回参数信息
type KickPeopleResp struct {
	Status  bool   `json:"status"`
	Message string `json:"message"`
}

//KickPeople 踢人
func (c *KickPeopleController) KickPeople() {
	var param KickPeopleParam
	out := make(map[string]interface{}) //定义返回参数
	// 获取参数
	logs.Info("\nrec json: %s\n\n", c.Ctx.Input.RequestBody)
	//json序列化到参数param中
	err := json.Unmarshal(c.Ctx.Input.RequestBody, &param)
	if err != nil {
		logs.Warn("invalid param, %v", err)
		// c.apiError(errs.NewErrCode(def.ErrMsg[def.EInvalidParam], def.EInvalidParam))
		c.apiFail(errs.NewAppFail("参数有误"))
		return
	}

	// 调用 service 的业务处理
	aEr := services.NewKickPeopleService().KickPeople(param.UserCaptainID, param.UserPlayerID, param.ActivityID)
	if aEr != nil {
		logs.Warn("kickpeople is error, aEr:%v", aEr)
		c.apiFail(aEr)
		return
	}
	//response.UserID = userID
	logs.Info("kickpeople success acitivity_id:%d usercaptain_id:%d userplayer_id：%d", param.ActivityID, param.UserCaptainID, param.UserPlayerID)
	out["status"] = "true"
	out["message"] = "踢人成功"
	c.apiResult(out)
	//c.apiSuccess(response)
}
