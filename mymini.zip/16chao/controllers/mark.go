package controllers

import (
	"16chao/services"
	"16chao/util/errs"
	"encoding/json"

	"github.com/astaxie/beego/logs"
)

//MarkController 评价接口
type MarkController struct {
	BaseController
}

// MarkParam  获取接口参数
type MarkParam struct {
	UserID       int     `json:"user_id"`
	TargetUserID int     `json:"target_user_id"`
	Score        float64 `json:"score"`
	ActivityID   int     `json:"activity_id"`
}

// func (p *MarkParam) isFullScore() int {
// 	MIN := 0.000001
// 	if math.Dim(p.Score, fullScore) < MIN {
// 		return 1
// 	}
// 	return 0
// }

//Mark  用户打分接口
func (c *MarkController) Mark() {
	var param MarkParam
	// 获取参数
	logs.Info("\n Mark controller get json: %s\n\n", c.Ctx.Input.RequestBody)
	err := json.Unmarshal(c.Ctx.Input.RequestBody, &param)
	if err != nil {
		logs.Warn("Mark invalid param, %v", err)
		c.apiFail(errs.NewAppFail("参数有误"))
		return
	}

	// if flag := param.isFullScore(); flag == 1 {
	// 	logs.Info("用户打满分")
	// 	// 系统在24小时后给
	// 	out := make(map[string]interface{})
	// 	out["status"] = "true"
	// 	out["message"] = "打分成功"
	// 	c.apiResult(out)
	// 	return
	// }

	// 调用 service 的业务处理
	aEr := services.NewMarkService().Mark(param.UserID, param.TargetUserID, param.Score, param.ActivityID)
	if aEr != nil {
		logs.Warn("Controller Mark is error, aEr:%v", aEr)
		c.apiFail(errs.NewAppFail("打分失败"))
		return
	}

	out := make(map[string]interface{})
	out["status"] = "true"
	out["message"] = "打分成功"
	c.apiResult(out)
}
