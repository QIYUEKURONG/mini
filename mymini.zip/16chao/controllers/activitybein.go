package controllers

import (
	"16chao/def"
	"16chao/services"
	"16chao/util/errs"
	"encoding/json"

	"github.com/astaxie/beego/logs"
)

//ActivityBeInController 用户信息相关接口
type ActivityBeInController struct {
	BaseController
}

var (
	beInSuc      = "数据返回成功"
	beInNothing  = "数据为空"
	beInFailed   = "服务器数据错误"
	beInNotExist = "用户ID不存在"
)

// ActivityBeInParam 用户正在进行的活动需要的参数
type ActivityBeInParam struct {
	UserID int `json:"user_id"`
}

// ActivityBeInInsertParam 用户报名需要的参数
type ActivityBeInInsertParam struct {
	UserID     int `json:"user_id"`
	ActivityID int `json:"activity_id"`
}

//BeIn 返回用户对应的活动信息
func (c *ActivityController) BeIn() {
	var param ActivityBeInParam
	// 获取参数
	logs.Info("\n[/v1/isParticipateAcitivity]rec json: %s\n\n", c.Ctx.Input.RequestBody)
	//json序列化到参数param中
	err := json.Unmarshal(c.Ctx.Input.RequestBody, &param)
	if err != nil {
		logs.Warn("[/v1/isParticipateAcitivity]invalid param, %v", err)
		c.apiError(errs.NewErrCode(def.ErrMsg[def.EInvalidParam], def.EInvalidParam))
		return
	}
	out := make(map[string]interface{})
	//判断前端返回的用户ID是否存在,这个是必要的，因为BeInID（）并不能通过底层查表判断user是否存在
	flag, aEr := services.NewUserService().Exist(param.UserID)
	//用户不存在 数据库操作没出错
	if flag == false && aEr == nil {
		out["status"] = "false"
		out["message"] = beInNotExist
		out["activities"] = nil
	} else {
		//调用 service 中的具体业务处理，这里是Bein 向前端返回用户对应的活动ID
		ActivityID, err1 := services.NewActivityBeInService().BeInID(param.UserID)
		ret, err2 := services.NewActivityBeInService().BeInInfo(ActivityID, 10)
		if err1 != nil || err2 != nil {
			out["status"] = "null"
			out["message"] = beInFailed
		}
		if len(ret) == 0 {
			out["status"] = "false"
			out["message"] = beInNothing
		} else {
			out["status"] = "true"
			out["message"] = beInSuc
		}
		out["activities"] = ret
		//测试行
		//fmt.Println(out)
	}
	logs.Info("BeIn success")
	c.apiResult(out)
}

//BeInInsert 用户报名参加活动
func (c *ActivityController) BeInInsert() {
	var param ActivityBeInInsertParam
	// 获取参数
	logs.Info("[/v1/SignUp]rec json: %s", c.Ctx.Input.RequestBody)
	//json序列化到参数param中
	err := json.Unmarshal(c.Ctx.Input.RequestBody, &param)
	if err != nil {
		logs.Warn("[/v1/SignUp]invalid param, %v", err)
		c.apiError(errs.NewErrCode(def.ErrMsg[def.EInvalidParam], def.EInvalidParam))
		return
	}
	out := make(map[string]interface{})
	//判断前端返回的用户ID是否存在
	data, aEr := services.NewActivityBeInService().BeInInsert(param.ActivityID, param.UserID)
	//用户不存在 数据库操作没出错
	if aEr != nil {
		out["status"] = "false"
		out["message"] = "数据返回失败"
	} else {
		out["status"] = data.Status
		out["message"] = data.Message
		//测试行
		//fmt.Println(out)
	}
	c.apiResult(out)
}
