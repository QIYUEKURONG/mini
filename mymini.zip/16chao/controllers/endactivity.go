package controllers

import (
	"16chao/services"
	"16chao/util/errs"
	"encoding/json"

	"github.com/astaxie/beego/logs"
)

//EndActivityController 结束集结相关接口
type EndActivityController struct {
	BaseController
}

// EndActivityParam  结束集结参数信息
type EndActivityParam struct {
	UserID     int `json:"user_id"`
	ActivityID int `json:"activity_id"`
}

//EndActivityResp 结束集结返回参数信息
type EndActivityResp struct {
	Status  bool   `json:"status"`
	Message string `json:"message"`
}

//EndActivity 结束集结
func (c *EndActivityController) EndActivity() {
	var param EndActivityParam
	out := make(map[string]interface{}) //定义返回参数
	// 获取参数
	logs.Info("\nrec json: %s\n\n", c.Ctx.Input.RequestBody)
	//json序列化到参数param中
	err := json.Unmarshal(c.Ctx.Input.RequestBody, &param)
	if err != nil {
		logs.Warn("invalid param, %v", err)
		c.apiFail(errs.NewAppFail("参数有误"))
		return
	}

	// 调用 service 的业务处理
	aEr := services.NewEndActivityService().EndActivity(param.UserID, param.ActivityID)
	if aEr != nil {
		logs.Warn("endactivity is error, aEr:%v", aEr)
		c.apiFail(aEr)
		return
	}
	//response.UserID = userID
	logs.Info("endactivity success acitivity_id:%d user_id:%d", param.ActivityID, param.UserID)
	out["status"] = "true"
	out["message"] = "结束集结成功"
	c.apiResult(out)
	//c.apiSuccess(response)
}
