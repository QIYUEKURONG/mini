package controllers

import (
	"16chao/services"
	"16chao/util/errs"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"

	"github.com/astaxie/beego/logs"

	//"strconv"
	"strings"
)

//LoginController 用户信息相关接口
type LoginController struct {
	BaseController
}

//AppSecret ...小程序密钥
const AppSecret string = "61e633ceb583e711643d2a6cf29937b0"

//AppID ...小程序ID
const AppID string = "wx97bea2b6425409c4"

// LoginParam  用户注册参数
type LoginParam struct {
	Code string `json:"code"`
}

// // LoginResp  注册返回的参数
// type LoginResp struct {
// 	UserID int    `json:"user_id"`
// 	OpenID string `json:"open_id"`
// 	Logged bool   `json:"logged"`
// 	Error  string `json:"error"`
// }

//

// Login 用户注册
func (g *LoginController) Login() {
	var param LoginParam
	// 获取参数
	logs.Info("\nrec json: %s\n\n", g.Ctx.Input.RequestBody)
	err := json.Unmarshal(g.Ctx.Input.RequestBody, &param)
	if err != nil {
		logs.Warn("invalid param, %v", err)
		g.apiFail(errs.NewAppFail("参数有误"))
		return
	}
	//URL  appid + secret +code
	Code2SessURL := "https://api.weixin.qq.com/sns/jscode2session?appid={appid}&secret={secret}&js_code={code}&grant_type=authorization_code"
	Code2SessURL = strings.Replace(Code2SessURL, "{appid}", AppID, -1)
	Code2SessURL = strings.Replace(Code2SessURL, "{secret}", AppSecret, -1)
	Code2SessURL = strings.Replace(Code2SessURL, "{code}", param.Code, -1)
	// fmt.Println("-------------------------get 地址--------------------------------")
	// fmt.Println(Code2SessURL)
	// fmt.Println("-------------------------get 地址---------------------------------")
	// fmt.Printf("\n\n\n\n\n\n")
	resp, err := http.Get(Code2SessURL)
	// fmt.Println("------resp 根据code appid secret组成的url  get到的信息-------------")
	// fmt.Println(resp)
	// fmt.Println("------resp 根据code appid secret组成的url  get到的信息-------------")
	// fmt.Printf("\n\n\n\n\n\n")
	//关闭资源
	if resp != nil && resp.Body != nil {
		defer resp.Body.Close()
	}
	if err != nil {
		logs.Warn("http get failed, %v", err)
		g.apiFail(errs.NewAppFail("http get failed"))
		return
	}
	//获取返回的参数 即openid等
	var jMap map[string]interface{}
	err = json.NewDecoder(resp.Body).Decode(&jMap)
	if err != nil {
		logs.Warn("NewDecoder resp.Body failed, %v", err)
		g.apiFail(errs.NewAppFail("NewDecoder resp.Body failed"))
		return

	}
	//获取返回错误信息，判断获取是否成功
	fmt.Println("------resp Jmap 的信息-------------")
	fmt.Println(jMap)
	fmt.Println("------resp Jmap 的信息-------------")
	fmt.Printf("\n\n\n\n\n\n")
	var errmsg string
	if jMap["errcode"] != nil {
		errmsg = jMap["errmsg"].(string)
	}
	err = errors.New(errmsg)
	//这里如果没有错误就无事发生，没法.(string)
	out := make(map[string]interface{})
	if jMap["errcode"] == nil || jMap["errcode"] == 0 {
		//正确获得返回信息，去判断openID是否已经存在
		//jMap["openid"].(string)
		fmt.Println("--------------成功调用NewLoginService.Login()------------------")
		uid, aEr := services.NewLoginService().Login(jMap["openid"].(string))
		out["user_id"] = uid
		// aEr != nil ||
		if uid == -1 || uid == 0 || aEr != nil {
			out["logged"] = false
		} else {
			out["logged"] = true
		}
		out["error"] = err
		out["open_id"] = jMap["openid"].(string)
	} else { //返回错误信息
		out["error"] = err
		logs.Warn("----------- %v--------------", err)
	}
	fmt.Println("------out 的信息-------------")
	fmt.Println(out)
	fmt.Println("------out 的信息-------------")
	fmt.Printf("\n\n")
	g.apiResult(out)
}
