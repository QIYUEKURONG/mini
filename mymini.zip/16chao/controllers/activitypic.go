package controllers

import (
	"16chao/def"
	"16chao/models"
	"strconv"
	//"16chao/models"
	//"16chao/def"
	"16chao/services"
	"16chao/util/errs"
	"fmt"
	"github.com/astaxie/beego/logs"
	"github.com/nfnt/resize"
	"image/jpeg"
	"io"
	"io/ioutil"
	"log"
	"mime/multipart"
	"net/http"
	"net/url"
	"os"
	"time"
)

//Activity2Controller 活动信息相关接口
type Activity2Controller struct {
	BaseController
}

// Activity2Param  发出集结需要接收的活动参数信息
type Activity2Param struct {
	//FileName     string  `from:"file_name"`
	UserID       int     `form:"user_id"`
	ActivityName string  `form:"activity_name"`
	LabelName    string  `form:"label_name"`
	StartTime    string  `form:"start_time"`
	EndTime      string  `form:"end_time"`
	MaxMember    int     `form:"max_member"`
	MinMember    int     `form:"min_member"`
	Longitude    float64 `form:"location_longitude"`
	Latitude     float64 `form:"location_latitude"`
	LocationName string  `form:"location_name"`
	Description  string  `form:"description"`
	ImgDefault   bool    `form:"img_default"`
}

//CloseFile ...
func CloseFile(f multipart.File, err error) {
	if err == nil {
		f.Close()
	}
}

//JPGResize -------------改变图片尺寸--------------
func JPGResize(imgpath string) error {
	//打开源文件
	file, erropen := os.Open(imgpath)
	if erropen != nil {
		logs.Info("---------没打开用户上传的图片---------")
		return erropen
	}
	defer file.Close()
	//把原文件编码为Jpg图片
	img, errdecode := jpeg.Decode(file)
	if errdecode != nil {
		fmt.Fprintf(os.Stderr, "%s: %v\n", imgpath, errdecode)
		return errdecode
	}
	//resize
	resizeimg := resize.Resize(1240, 638, img, resize.Lanczos3)
	newfile, errcte := os.Create(imgpath)
	if errcte != nil {
		log.Fatal(errcte)
	}
	defer newfile.Close()
	// 把新图写入新文件（与源文件同名） 这里直接写入原文件没改变
	jpeg.Encode(newfile, resizeimg, nil)
	return nil
}

//CopyFile ----------------复制文件-------------------
func CopyFile(dstName, srcName string) (written int64, err error) {
	src, err := os.Open(srcName)
	if err != nil {
		fmt.Println(src)
		logs.Info("没打开源文件")
		return
	}
	defer src.Close()
	dst, err := os.OpenFile(dstName, os.O_WRONLY|os.O_CREATE, 0644)
	if err != nil {
		logs.Info("打开新文件")
		return
	}
	defer dst.Close()
	return io.Copy(dst, src)
}

//Request 客户端发起短连接请求
func Request(userID, activityID string) error {
	resp, err := http.PostForm(def.ChartIP+"/chat/init",
		url.Values{"user_id": {userID}, "activity_id": {activityID}})

	if err != nil {
		logs.Info("发起短连接")
		return fmt.Errorf("发起短连接")
	}
	//defer resp.Body.Close()
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		logs.Info("获取返回信息失败")
		return fmt.Errorf("获取返回信息失败")
	}
	fmt.Println(string(body))
	if string(body) == "success" {
		return nil
	}
	return fmt.Errorf("body == fail")

}

//isValid 判断用户的输入是否有效
func (p *Activity2Param) isValid() error {
	//活动名称是否为空
	if p.ActivityName == "" {
		logs.Info("activity_name is null")
		return fmt.Errorf("activity_name is null")
	}
	//活动人数是否正确，也是前端判断
	if p.MaxMember < p.MinMember || p.MaxMember < 0 || p.MinMember < 0 {
		logs.Info("max_member is smaller than min_member, or the number is not correct")
		return fmt.Errorf("max_member is smaller than min_member, or the number is not correct")
	}
	// //活动时间,交由前端判断
	sTime, _ := time.ParseInLocation(def.TimeStampFmt, p.StartTime, time.Local)
	eTime, _ := time.ParseInLocation(def.TimeStampFmt, p.EndTime, time.Local)
	fmt.Println(sTime)
	fmt.Println(eTime)
	if eTime.Before(sTime) {
		logs.Info("end_time is before start_time")
		return fmt.Errorf("end_time is before start_time")
	}
	//用户输入的label_name是否在label库里
	if ret, _ := models.GetLabelModel().GetLabelIDByName(p.LabelName); ret == -1 {
		logs.Info("this type of label_name does not exist on database")
		return fmt.Errorf("this type of label_name does not exist on database")
	}
	return nil
}

//Publish2 ...
func (p *Activity2Controller) Publish2() {
	//formdata数据
	logs.Info("\nrec form: %v\n\n", p.Ctx.Request.PostForm)
	fmt.Println("-----------------------------------")
	fmt.Println("----------进入pubulish2------------")
	fmt.Println("-----------------------------------")
	param := Activity2Param{}
	if errparse := p.ParseForm(&param); errparse != nil {
		logs.Warn("invalid param, %v", errparse)
		p.apiError(errs.NewErrCode(def.ErrMsg[def.EInvalidParam], def.EInvalidParam))
		return
	}
	//读文件
	f, _, nopost := p.GetFile("file")
	if nopost != nil {
		// log.Fatal("getfile err ", nopost)
		fmt.Println("the user did not post the pic")
	}
	//结束后关闭文件
	defer CloseFile(f, nopost)
	//结束后关闭文件

	// 判断用户输入是否有效
	if errvalid := param.isValid(); errvalid != nil {
		logs.Warn("activity register param is error, err:%v", errvalid)
		out := make(map[string]interface{})
		out["status"] = "false"
		out["message"] = publishFail
		out["activity_ID"] = -1
		p.apiResult(out)
		return
	}
	//----------回滚事务开启-------------
	/*	errback := models.GetOrm().Begin()
		if errback != nil {
			logs.Info("开启事务失败")
		}*/
	//调用具体业务去发出集结
	ActivityID, _, aEr := services.NewActivityService().Publish(
		param.ActivityName, param.LabelName, param.LocationName, param.Description, def.PrefixDef, param.StartTime, param.EndTime, param.UserID, param.MaxMember, param.MinMember, param.Longitude, param.Latitude, param.ImgDefault)
	if aEr != nil {
		logs.Warn("publish is error, aEr:%v", aEr)
		out := make(map[string]interface{})
		out["status"] = "false"
		out["message"] = publishFail
		out["activity_ID"] = ActivityID
		p.apiResult(out)
		return
	}
	//保存图片
	fmt.Println("-----------------p.SaveToFile---------------------------")
	//如果不是默认图片 直接保存
	if param.ImgDefault != true {
		errsave := p.SaveToFile("file", "static/userpost/"+strconv.Itoa(ActivityID)+".jpg")
		if errsave != nil {
			fmt.Printf("%v\n\n", errsave)
		}

		imgpath := "static/userpost/" + strconv.Itoa(ActivityID) + ".jpg"
		//改变图片尺寸
		if errresize := JPGResize(imgpath); errresize != nil {
			logs.Warn("resize userpost pic failed, err:%v", errresize)
		}
		//改变图片尺寸完成
	} else { //是默认图片，就把对应label默认的图片复制过来然后保存
		src := "static/default/" + def.Label[param.LabelName] + ".jpg"
		logs.Info("%s", src)
		CopyFile("static/userpost/"+strconv.Itoa(ActivityID)+".jpg", src)
	}
	fmt.Println("-----------------p.SaveToFile-----------------------------")
	//保存图片完成

	//发起生成聊天室请求
	errReq := Request(strconv.Itoa(param.UserID), strconv.Itoa(ActivityID))
	fmt.Println(errReq)
	//--------------事务回滚----------------
	// time.Sleep(10 * time.Minute)
	/*	if errReq != nil {
			errback = models.GetOrm().Rollback()
		} else {
			errback = models.GetOrm().Commit()
		}*/
	logs.Info("activity publish success acitivity_id:%d", ActivityID)
	out := make(map[string]interface{})
	out["status"] = "true"
	out["message"] = publishSuc
	out["activity_ID"] = ActivityID
	p.apiResult(out)

}
