package controllers

import (
	"16chao/services"
	"16chao/util/errs"
	"encoding/json"

	"github.com/astaxie/beego/logs"
)

//AgainActivityController 再次集结相关接口
type AgainActivityController struct {
	BaseController
}

// AgainActivityParam  结束集结参数信息
type AgainActivityParam struct {
	UserID     int `json:"user_id"`
	ActivityID int `json:"activity_id"`
}

//AgainActivityResp 结束集结返回参数信息
type AgainActivityResp struct {
	Status  bool   `json:"status"`
	Message string `json:"message"`
}

//AgainActivity 结束集结
func (c *AgainActivityController) AgainActivity() {
	var param AgainActivityParam
	out := make(map[string]interface{}) //定义返回参数
	// 获取参数
	logs.Info("\nrec json: %s\n\n", c.Ctx.Input.RequestBody)
	//json序列化到参数param中
	err := json.Unmarshal(c.Ctx.Input.RequestBody, &param)
	if err != nil {
		logs.Warn("invalid param, %v", err)
		c.apiFail(errs.NewAppFail("参数有误"))
		return
	}

	// 调用 service 的业务处理
	aEr := services.NewAgainActivityService().AgainActivity(param.UserID, param.ActivityID)
	if aEr != nil {
		logs.Warn("againactivity is error, aEr:%v", aEr)
		c.apiFail(aEr)
		return
	}
	//response.UserID = userID
	logs.Info("againactivity success acitivity_id:%d user_id:%d", param.ActivityID, param.UserID)
	out["status"] = "true"
	out["message"] = "再次集结成功"
	c.apiResult(out)
	//c.apiSuccess(response)
}
