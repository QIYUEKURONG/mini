package controllers

import (
	"16chao/services"
	"16chao/util/errs"
	"encoding/json"
	"fmt"

	"github.com/astaxie/beego/logs"
)

var (
	ageMin       = 0
	ageMax       = 150
	genderX      = 0
	genderMale   = 1
	genderFemale = 2
)

//UserController 用户信息相关接口
type UserController struct {
	BaseController
}

// UserRegParam  用户注册参数
type UserRegParam struct {
	Name   string `json:"user_name"`
	Avatar string `json:"user_avatar"`
	Gender int    `json:"user_gender"`
	Region string `json:"user_region"`
	OpenID string `json:"open_id"`
}

// UserRegResp  用户注册返回参数
type UserRegResp struct {
	UserID int `json:"user_id"`
}

func (p *UserRegParam) isValid() error {
	if p.Name == "" {
		logs.Warn("user_name is null")
		return fmt.Errorf("user_name is null")
	}
	if !(p.Gender == genderFemale || p.Gender == genderMale || p.Gender == genderX) {
		logs.Warn("gender inlegal")
		return fmt.Errorf("gender inlegal")
	}
	return nil
}

// Register 用户注册
func (c *UserController) Register() {
	var param UserRegParam
	//	var response UserRegResp
	// 获取参数
	logs.Info("\nrec json: %s\n\n", c.Ctx.Input.RequestBody)
	err := json.Unmarshal(c.Ctx.Input.RequestBody, &param)
	if err != nil {
		logs.Warn("invalid param, %v", err)
		c.apiFail(errs.NewAppFail("参数有误"))
		return
	}

	// 检验参数
	if err := param.isValid(); err != nil {
		logs.Warn("register param is error, err:%v", err)
		c.apiFail(errs.NewAppFail("参数有误"))
		return
	}
	// 调用 service 的业务处理
	userID, aEr := services.NewUserService().Register(param.Name, param.Avatar, param.Region, param.OpenID, param.Gender)
	if aEr != nil {
		logs.Warn("register is error, aEr:%v", aEr)
		c.apiFail(aEr)
		return
	}

	logs.Info("user register success user_id:%d", userID)
	out := make(map[string]interface{})
	out["status"] = "true"
	out["message"] = "用户信息存储成功"
	out["user_id"] = userID
	out["open_id"] = param.OpenID
	c.apiResult(out)
}
