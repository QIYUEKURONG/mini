package controllers

import (
	"16chao/models"
	"strconv"
)

//MonitorController ...	后台监控
type MonitorController struct {
	BaseController
}

// Get ...
func (m *MonitorController) Get() {
	m.Ctx.SetCookie("name", "liuyisi", "abc", "/")
	m.Ctx.SetCookie("pwd", "zouhao", "456", "/")
	m.Ctx.WriteString("监控数据界面\n")
	m.Ctx.WriteString("当前用户总人数：  ")
	a := models.GetUserModel().CountUser()
	m.Ctx.WriteString(strconv.Itoa(a))
	// m.Ctx.WriteString(m.Data)
	// m.Data["Website"] = "beego.me"
	// m.Data["Email"] = "astaxie@gmail.com"

}
