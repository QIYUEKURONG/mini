package controllers

import (
	"16chao/services"
	"16chao/util/errs"
	"encoding/json"

	"github.com/astaxie/beego/logs"
)

//DismissActivityController 解散活动相关接口
type DismissActivityController struct {
	BaseController
}

// DismissActivityParam  解散活动参数信息
type DismissActivityParam struct {
	UserID     int `json:"user_id"`
	ActivityID int `json:"activity_id"`
}

//DismissActivityResp 解散活动返回参数信息
type DismissActivityResp struct {
	Status  bool   `json:"status"`
	Message string `json:"message"`
}

//DismissActivity 解散活动
func (c *DismissActivityController) DismissActivity() {
	var param DismissActivityParam
	out := make(map[string]interface{}) //定义返回参数
	// 获取参数
	logs.Info("\nrec json: %s\n\n", c.Ctx.Input.RequestBody)
	//json序列化到参数param中
	err := json.Unmarshal(c.Ctx.Input.RequestBody, &param)
	if err != nil {
		logs.Warn("invalid param, %v", err)
		c.apiFail(errs.NewAppFail("参数有误"))
		return
	}

	// 调用 service 的业务处理
	aEr := services.NewDismissActivityService().DismissActivity(param.UserID, param.ActivityID)
	if aEr != nil {
		logs.Warn("dismissactivity is error, aEr:%v", aEr)
		c.apiFail(aEr)
		return
	}
	//response.UserID = userID
	logs.Info("dismissactivity success acitivity_id:%d user_id:%d", param.ActivityID, param.UserID)
	out["status"] = "true"
	out["message"] = "解散活动成功"
	c.apiResult(out)
	//c.apiSuccess(response)
}
