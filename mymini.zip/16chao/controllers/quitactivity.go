package controllers

import (
	"16chao/services"
	"16chao/util/errs"
	"encoding/json"

	"github.com/astaxie/beego/logs"
)

//QuitActivityController 退出活动相关接口
type QuitActivityController struct {
	BaseController
}

// QuitActivityParam  退出活动参数信息
type QuitActivityParam struct {
	UserID     int `json:"user_id"`
	ActivityID int `json:"activity_id"`
}

//QuitActivityResp 退出活动返回参数信息
type QuitActivityResp struct {
	Status  bool   `json:"status"`
	Message string `json:"message"`
}

//QuitActivity 退出活动
func (c *QuitActivityController) QuitActivity() {
	var param QuitActivityParam
	out := make(map[string]interface{}) //定义返回参数
	// 获取参数
	logs.Info("\nrec json: %s\n\n", c.Ctx.Input.RequestBody)
	//json序列化到参数param中
	err := json.Unmarshal(c.Ctx.Input.RequestBody, &param)
	if err != nil {
		logs.Warn("invalid param, %v", err)
		// c.apiError(errs.NewErrCode(def.ErrMsg[def.EInvalidParam], def.EInvalidParam))
		c.apiFail(errs.NewAppFail("参数有误"))
		return
	}

	// 调用 service 的业务处理
	aEr := services.NewQuitActivityService().QuitActivity(param.UserID, param.ActivityID)
	if aEr != nil {
		logs.Warn("quitactivity is error, aEr:%v", aEr)
		c.apiFail(aEr)
		return
	}
	//response.UserID = userID
	logs.Info("quitactivity success acitivity_id:%d user_id:%d", param.ActivityID, param.UserID)
	out["status"] = "true"
	out["message"] = "退出活动成功"
	c.apiResult(out)
	//c.apiSuccess(response)
}
