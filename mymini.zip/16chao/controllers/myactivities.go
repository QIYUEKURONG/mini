package controllers

import (
	"16chao/def"
	"16chao/services"
	"16chao/util/errs"
	"encoding/json"

	"github.com/astaxie/beego/logs"
)

//MyActivitiesController 用户信息相关接口
type MyActivitiesController struct {
	BaseController
}

// MyActivitiesParam  获取接口参数
type MyActivitiesParam struct {
	UserID int `json:"user_id"`
}

//GetMyActivities ...
func (m *MyActivitiesController) GetMyActivities() {
	var param MyActivitiesParam
	//打印接受到前端的信息
	logs.Info("\nrec json: %s\n\n", m.Ctx.Input.RequestBody)
	//json序列化到参数param中
	err := json.Unmarshal(m.Ctx.Input.RequestBody, &param)
	if err != nil {
		logs.Warn("invalid param, %v", err)
		m.apiError(errs.NewErrCode(def.ErrMsg[def.EInvalidParam], def.EInvalidParam))
		return
	}
	out := make(map[string]interface{})
	//判断前端返回的用户ID是否存在,这个是必要的，因为BeInID（）并不能通过底层查表判断user是否存在
	flag, aEr := services.NewUserService().Exist(param.UserID)
	//用户不存在 数据库操作没出错
	if flag == false && aEr == nil {
		out["status"] = "false"
		out["message"] = beInNotExist
		out["activities"] = nil
	} else {
		//调用server中具体的业务 GetMyAcitivities(uid int) ([]MyActivitiesGetResp, *errs.AppError)
		//获取我的活动相关信息
		myactivities, aEr := services.NewMyActivitiesService().GetMyActivities(param.UserID)
		if aEr != nil {
			out["status"] = "false"
			out["message"] = "服务器数据错误"
		}
		if len(myactivities) == 0 {
			out["status"] = "true"
			out["message"] = "数据为空或者数据库有脏东西"
		} else {
			out["status"] = "true"
			out["message"] = "数据返回成功"
			logs.Info("data return success")
		}
		out["activities"] = myactivities
	}
	m.apiResult(out)
}
