package controllers

import (
	"16chao/def"
	"16chao/util/errs"

	"github.com/astaxie/beego"
)

//BaseController ...
type BaseController struct {
	beego.Controller
}

//accessLog record access log
func (c *BaseController) accessLog() {
	return
}

// apiResult Ajax返回结果
func (c *BaseController) apiResult(data ...interface{}) {
	if len(data) == 1 {
		c.Data["json"] = data[0]
		c.ServeJSON()
	}

	c.accessLog()
}

// apiSuccess Ajax返回正确结果
func (c *BaseController) apiSuccess(data ...interface{}) {
	out := make(map[string]interface{})
	out["status"] = "true"
	out["message"] = "ok"
	out["data"] = nil
	if len(data) == 1 {
		out["data"] = data[0]
	}
	if len(data) == 2 {
		out["data"] = data[0]
		out["msg"] = data[1]
	}

	if out["data"] == nil {
		delete(out, "data")
	}

	c.apiResult(out)
}

// apiError Ajax返回错误结果
func (c *BaseController) apiError(e *errs.AppError) {
	out := make(map[string]interface{})
	out["rtn"] = e.Code()
	out["msg"] = e.Msg()
	out["data"] = e.Data()

	if out["data"] == nil {
		delete(out, "data")
	}

	c.apiResult(out)
}

// apiErrorCode Ajax返回错误结果
func (c *BaseController) apiErrorCode(code int) {
	out := make(map[string]interface{})
	out["rtn"] = code
	out["msg"] = def.ErrMsg[code]
	c.apiResult(out)
}

// apiError Ajax返回错误结果
func (c *BaseController) apiFail(e *errs.AppFail) {
	out := make(map[string]interface{})
	out["status"] = e.Status()
	out["message"] = e.Message()
	c.apiResult(out)
}
