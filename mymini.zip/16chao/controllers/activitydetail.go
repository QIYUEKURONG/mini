package controllers

import (
	"16chao/def"
	"16chao/services"
	"16chao/util"
	"16chao/util/errs"
	"encoding/json"
	"fmt"
	"strconv"

	"github.com/astaxie/beego/logs"
)

//ActivityDetailsController 活动详细信息相关接口
type ActivityDetailsController struct {
	BaseController
}

// ActivityRegParam  活动传递参数
type ActivityRegParam struct {
	UserID     int     `json:"user_id"`
	ActivityID int     `json:"activity_id"`
	Latitude   float64 `json:"user_current_latitude"`
	Longitude  float64 `json:"user_current_longitude"`
	//Radius     float64 `json:"gather_radius"`
}

//MemberListType ...
type MemberListType struct {
	UserID     int    `json:"user_id"`
	UserAvatar string `json:"user_avatar"`
	IsCaptain  int    `json:"is_captain"`
}

//检查活动id
func (a *ActivityRegParam) isValid() error {
	if a.ActivityID <= 0 {
		logs.Warn("[activityDetail]activity is null")
		return fmt.Errorf("activity  is null")
	}
	if a.UserID <= 0 {
		logs.Warn("[activityDetail]UserID is null")
		return fmt.Errorf("UserID  is null")
	}
	return nil
}

// ActivityDetails 活动详情  zhangtianlong
func (a *ActivityDetailsController) ActivityDetails() {
	var param ActivityRegParam
	var distance float64
	// var parfm ActivityRegResp
	// 获取参数
	fmt.Printf("\nrec json: %s\n\n", a.Ctx.Input.RequestBody)
	err := json.Unmarshal(a.Ctx.Input.RequestBody, &param) //将json字符串解码到相应的数据结构
	if err != nil {
		logs.Warn("invalid param, %v", err)
		a.apiError(errs.NewErrCode(def.ErrMsg[def.EInvalidParam], def.EInvalidParam))
		return
	}

	// 检验参数
	if err := param.isValid(); err != nil {
		logs.Warn("ActivityDetails param is error, err:%v", err)
		out := make(map[string]interface{})
		out["status"] = "false"
		out["message"] = "活动信息查询失败"
		a.apiResult(out)
		return
	}
	// 调用 service 的业务处理
	parfm, distance, aEr := services.GetActivityDetailService().Details(param.ActivityID, param.UserID, param.Latitude, param.Longitude)
	if aEr != nil {
		logs.Warn("ActivityDetails is error, aEr:%v", aEr)
		// a.apiError(aEr)
		out := make(map[string]interface{})
		out["status"] = "false"
		out["message"] = "活动信息查询失败"
		a.apiResult(out)
		return
	}

	//logs.Info("ActivityDetails success ", parfm)
	out := make(map[string]interface{})
	out["status"] = "true"
	out["message"] = "活动信息查询成功"
	out["user_id"] = parfm.UserID
	out["activity_name"] = parfm.ActivityName
	out["label_name"] = parfm.LabelName
	out["start_time"] = parfm.StartTime.Format("2006-01-02 15:04:05") //格式化时间
	out["end_time"] = parfm.EndTime.Format("2006-01-02 15:04:05")
	out["max_member"] = parfm.MaxMember
	out["min_member"] = parfm.MinMember
	out["location_longtitude"] = parfm.Longtitude
	out["location_latitude"] = parfm.Latitude
	out["description"] = parfm.Description
	out["image"] = parfm.Image
	out["location_name"] = parfm.LocationName
	out["current_member"] = parfm.CurrentMember
	//对活动状态进行判断再返回相应字符串
	if parfm.Status == 0 {
		out["activity_status"] = "正在集结"
	} else if parfm.Status == 1 {
		out["activity_status"] = "集结完成"
	} else if parfm.Status == 2 {
		out["activity_status"] = "活动进行中"
	} else if parfm.Status == 3 {
		out["activity_status"] = "活动已结束"
	} else if parfm.Status == 4 {
		out["activity_status"] = "活动已解散"
	}
	//对返回的距离进行处理
	distanceTemp := util.Decimal(distance)
	if util.GetDecimalNumber(distanceTemp) == 0 {
		disToString := strconv.FormatFloat(distanceTemp, 'g', -1, 64)
		out["distance"] = disToString + "m"
	} else {
		disToString := strconv.FormatFloat(distanceTemp, 'g', -1, 64)
		out["distance"] = disToString + "km"
	}
	//把所有活动成员的信息返回，以数组形式
	var membersList []*MemberListType
	for _, value := range parfm.MemberLists {
		// members := make(map[string]interface{})
		// members["user_id"] = value.UserID
		// members["user_avatar"] = value.UserAvatar
		// members["is_captain"] = value.IsCaptain
		// a.apiResult(members)
		var members MemberListType
		members.UserID = value.UserID
		members.UserAvatar = value.UserAvatar
		members.IsCaptain = value.IsCaptain
		membersList = append(membersList, &members)
	}
	out["members"] = membersList
	a.apiResult(out)

}
