package def

import (
	"16chao/util/errs"
	"errors"
	"fmt"
)

// 错误码
const (
	EOK                      int = 0
	EInvalidParam                = 50001
	EInternalErr                 = 50002
	ESessionTimeout              = 50003
	ESessionInvalidOrKickOut     = 50004
	EReqInvalid                  = 50005
	EAuthCodeInvalid             = 50006
	EPasswdExist                 = 50007
	EPasswdWrong                 = 50008
	EPasswdUpdateFailed          = 50009
	EInvitationCodeInvalid       = 50010
	EPosAlreadyACtived           = 50011
	EInvalidShopOrder            = 50012
	ESignCheckFail               = 50013
	ERateUpgrade                 = 50014
	EReverseNotAllow             = 50015
	EPayCodeInvalid              = 50016
	EPosActiveSNInvalid          = 50017
	EPosActiveCodeInvalid        = 50018
	EPosActiveCodeTimeout        = 50019
	EPosActiveError              = 50020
	EPosSNInvalid                = 50021
	EPosSNNotBindUser            = 50022
	EPosAndroidPushMsg           = 50023
	EPosIOSPushMsg               = 50024
	EPosPushMsgAlready           = 50025
	EBalanceNotEnough            = 50026
	EC2CSystemBusy               = 50027
	EC2CSelf2Self                = 50028
	EPosInactive                 = 50029
	EPosActiveSNNotExist         = 50030
	ERecvCodeNotExist            = 50031
	EShopSelf2Self               = 50032
	EModPayPWLimit               = 50033
	EOrderAlreadyPaied           = 50034
	EOrderNotExist               = 50035
	EServerAccessForbidden       = 50036
	ETransForbidden              = 50037
	EInvalidLinkAddress          = 50038
	EPrepayIDNotReady            = 50039
	EUserNoExists                = 50040
	EHasUnbindWeek               = 50041
	EHadBindLinkAddress          = 50042
	EWithrawDailyLimit           = 50043
	EDepositDailyLimit           = 50044
	ECheckSessionInterface       = 50047
	ENotInChangeRateTime         = 50048
	ESysAlreadyHasRateRecord     = 50049
	ENotOpenAutoPay              = 50050
	EHadOpenAutoPay              = 50051
	ENotAutoPayElement           = 50052
	ENotRealName                 = 50053
	ECardNoExists                = 50054
	ECardHadDrop                 = 50055
	ECardUnBindLimit             = 50056
	ECardHasBeenBund             = 50057
	ECardBindCountLimit          = 50058
	ECardBindTotalLimit          = 50059
	EFreqLimit                   = 50060
	EChainFailed                 = 50061
	ECardNoTrue                  = 50062
	EMustBeUpgrade               = 50063
	EUserFreeze                  = 50065
	EImageHadExpire              = 50066

	EZombieUser = 50064

	// 下一个从50080开始，为了解决分支创建错误码冲突

	//EFeedbackFileSize file size too big
	EFeedbackFileSize = 51001
)

const (
	//EPasswdAlreadyLock passwd locked
	EPasswdAlreadyLock = 60000

	//EPasswdError password error
	EPasswdError = 60001

	//ETransToSelf trans zct to self
	ETransToSelf = 60002

	//EPosActiveCodeAlreadyLock lock ip if active code err too much
	EPosActiveCodeAlreadyLock = 60003

	// ECreateOrderTooFrequency 创建订单过于频繁
	ECreateOrderTooFrequency = 60008
	// EGetAuthCodeTooFrequency 获取兑换码过于频繁
	EGetAuthCodeTooFrequency = 60009
	// ECheckInvitationTooFrequency 提交邀请码过于频繁
	ECheckInvitationTooFrequency = 60010
	// EShopCreateOrderTooFrequency pos机创建订单过于频繁
	EShopCreateOrderTooFrequency = 60011
	// EPaymentTooFrequency 支付过于频繁
	EPaymentTooFrequency = 60012

	// EGetDailyRateTooFrequency 获取每日汇率频繁
	EGetDailyRateTooFrequency = 60013
	// EGetUploadFileTooFrequency 获取上传文件频繁
	EGetUploadFileTooFrequency = 60014
)

// ErrMsg 错误描述信息
var ErrMsg = map[int]string{
	EOK:                      "ok",
	EInvalidParam:            "非法参数",
	EInternalErr:             "系统忙，请稍后重试",
	ESessionTimeout:          "登录态超时",
	ESessionInvalidOrKickOut: "登录态校验非法或被踢",
	EReqInvalid:              "请求非法",
	EAuthCodeInvalid:         "付款码异常,请重新扫描提交订单",
	EPasswdExist:             "密码已存在",
	EPasswdWrong:             "旧兑换密码输入错误",
	EPasswdUpdateFailed:      "更新密码错误,稍后重试",
	EInvitationCodeInvalid:   "邀请码不存在",
	EPosAlreadyACtived:       "pos机已激活",
	EInvalidShopOrder:        "支付失败,订单不存在或已过期或已支付",
	ESignCheckFail:           "签名错误",
	ERateUpgrade:             "订单汇率不是最新，请更新汇率",
	EReverseNotAllow:         "订单失效，请返回重试",
	EPayCodeInvalid:          "付款码已失效",
	EPosActiveSNInvalid:      "序列号非法",
	EPosActiveCodeInvalid:    "激活失败，该激活码不存在，激活码输错5次需要去官网再次获得新的激活码",
	EPosActiveCodeTimeout:    "激活失败，该激活码已失效，请去官网获取新的激活码",
	EPosActiveError:          "激活失败，请稍后重试",
	EPosSNInvalid:            "pos机客户端信息不存在",
	EPosSNNotBindUser:        "pos机未绑定商户",
	EPosAndroidPushMsg:       "Android消息接口推送不成功",
	EPosIOSPushMsg:           "IOS消息接口推送不成功",
	EPosPushMsgAlready:       "该MSGID消息已经被推送了",
	EBalanceNotEnough:        "很抱歉,您的积分不足",
	EC2CSystemBusy:           "系统忙，请返回重试",
	EC2CSelf2Self:            "不能给自己转账",
	EPosInactive:             "pos机未激活",
	EPosActiveSNNotExist:     "激活失败，该设备未在官网登记，请先去官网登记该设备的SN码",
	ERecvCodeNotExist:        "当前二维码无效",
	EShopSelf2Self:           "订单非法",
	EModPayPWLimit:           "当日内您最多可修改3次兑换密码！",
	EOrderNotExist:           "订单不存在",
	EOrderAlreadyPaied:       "订单已支付,请勿重复支付",
	EServerAccessForbidden:   "禁止访问",
	ETransForbidden:          "转账被禁止",

	EPosActiveCodeAlreadyLock:    "输入激活码错误次数过多,已锁定,还需%s解锁",
	ECreateOrderTooFrequency:     "创建订单过于频繁，请%s后再操作",
	EGetAuthCodeTooFrequency:     "获取积分码过于频繁，请%s后再操作", //"获取兑换码过于频繁，请%s后再操作",
	ECheckInvitationTooFrequency: "提交邀请码过于频繁，请%s后再操作",
	EShopCreateOrderTooFrequency: "提交订单过于频繁，请%s后再操作",
	EPaymentTooFrequency:         "操作过于频繁，请%s后再操作", //"支付过于频繁，请%s后再操作",
	EGetDailyRateTooFrequency:    "获取每次汇率过于频繁，请%s后再操作",
	EGetUploadFileTooFrequency:   "上传文件过于频繁，请%s后再操作",

	EPasswdAlreadyLock:       "您的账户已冻结，还需%s解除冻结",
	EPasswdError:             "兑换密码错误,已错误%d次,连续错误%d次您的账户将被冻结%s",
	ETransToSelf:             "不能给自己账号转入积分",
	EInvalidLinkAddress:      "未绑定链克地址,或者链克地址格式错误",
	EPrepayIDNotReady:        "申请prepayID未就绪",
	EUserNoExists:            "该用户不存在",
	EHasUnbindWeek:           "每个用户每周只允许删除一次",
	EHadBindLinkAddress:      "同一用户最多只允许绑定一个账户地址",
	EWithrawDailyLimit:       "转出积分超限，请调整",
	EDepositDailyLimit:       "转入积分超限，请调整",
	ECheckSessionInterface:   "迅雷checkSession接口错误，err:%v",
	ENotInChangeRateTime:     "现在这个时间点不能修改汇率",
	ESysAlreadyHasRateRecord: "该时间段已有汇率记录,请勿重复添加",
	ENotAutoPayElement:       "找不到该免密支付选项",
	ENotOpenAutoPay:          "该用户还没开通免密支付",
	EHadOpenAutoPay:          "该用户已经开通了免密支付",
	ENotRealName:             "未实名认证",
	ECardNoExists:            "会员卡不存在",
	ECardHadDrop:             "会员卡已被注销",
	ECardUnBindLimit:         "每个用户每周只允许删除一次",
	ECardHasBeenBund:         "会员卡已被绑定",
	ECardBindCountLimit:      "每位用户只允许绑定%d张会员卡",
	ECardBindTotalLimit:      "每位用户累计只允许绑定%d张会员卡",
	EFreqLimit:               "请求过于频繁，请稍后再试",
	EChainFailed:             "访问区块链失败",
	ECardNoTrue:              "会员卡号不正确",
	EMustBeUpgrade:           "此功能需要您升级至最新版本",
	EUserFreeze:              "您的账号已被冻结",
	EImageHadExpire:          "图片已过期，请重新上传",

	EZombieUser: "很抱歉，您的账号已被冻结，操作被禁止",

	EFeedbackFileSize: "文件大小超过系统限制",
}

//ErrBalanceNotEnough balance not enough
var ErrBalanceNotEnough = errors.New("balance not enough") // 钻克抵扣失败，余额不足

//ErrTransToSelf transf to self
var ErrTransToSelf = errors.New("transfer to self") //给自己转账

// ErrRecvCodeNotExist 无效的收款码
var ErrRecvCodeNotExist = errors.New("recvcode not exist")

//ErrNotFound Not Found
var ErrNotFound = errors.New("Not Found")

// ErrUserHadExist user had exist
var ErrUserHadExist = errors.New("user had exist")

// ErrUserFreeze user had freeze
var ErrUserFreeze = errors.New("user freeze")

//GetErrMsg get error message
func GetErrMsg(code int) string {
	msg, _ := ErrMsg[code]
	return msg
}

//NewAppError new app error
func NewAppError(code int, params ...interface{}) *errs.AppError {
	var msg string
	if len(params) > 0 {
		msg = fmt.Sprintf(ErrMsg[code], params...)
	} else {
		msg = ErrMsg[code]
	}

	return errs.NewErrCode(msg, code)
}

// ErrorInvalidParam means invalid parameter error
var ErrorInvalidParam = errors.New(ErrMsg[EInvalidParam])

//ErrorOrmIsNil orm nil
var ErrorOrmIsNil = errors.New("Orm is nil")
