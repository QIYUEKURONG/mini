package def

import (
	"time"
)

// 时间格式
const (
	//TimeStampFmt a mysql timestamp fmt
	TimeStampFmt    = "2006-01-02 15:04:05"
	TimeStampDayFmt = "2006-01-02"
	TimeStampYYMMDD = "20060102"

	TimeStampYYMM    = "200601"
	TimeStampRateFmt = TimeStampYYMMDD
)

//PrefixDef ...https://jijiehao.hnonething.com/default/
var PrefixDef = "https://jijiehao.hnonething.com/default/"

//PrefixUser ...
var PrefixUser = "https://jijiehao.hnonething.com/userpost/"

//activity_status  int  0  活动状态  0：正在集结 1：集结完成 2：活动进行中 3:活动已结束 4：活动被解散
const (
	StatIsCalling        int = 0
	StatCallFinished     int = 1
	Statbein             int = 2
	StatActivityFinished int = 3
	StatDismissed        int = 4

	// 评价打分   分5个级别
	MarkFullScore = float64(5)
	MarkLevel4    = float64(4)
	MarkLevel3    = float64(3)
	MarkLevel2    = float64(2)
	MarkLevel1    = float64(1)

	DefaultMark = 1
	UserMark    = 2
)

//Label 中文拼音映射表
var Label = map[string]string{
	"篮球":   "lanqiu",
	"足球":   "zuqiu",
	"羽毛球":  "yumaoqiu",
	"排球":   "paiqiu",
	"网球":   "wangqiu",
	"乒乓球":  "pingpangqiu",
	"散步":   "sanbu",
	"王者荣耀": "wangzherongyao",
	"绝地求生": "juediqiusheng",
	"英雄联盟": "yingxionglianmeng",
	"守望先锋": "shouwangxianfeng",
	"唱歌":   "changge",
	"狼人杀":  "langrensha",
	"自习":   "zixi",
	"烧烤":   "shaokao",
	"火锅":   "huoguo",
	"拼单":   "pindan",
	"麻将":   "majiang",
	"跳舞":   "tiaowu",
	"逛街":   "guangjie",
	"慢跑":   "manpao",
	"刺激战场": "cijizhanchang",
	"三国杀":  "sanguosha",
	"电影":   "dianying",
}

//ChartIP ...
const ChartIP string = "http://127.0.0.1:8086"

//ActivityTime 活动时间结构体
type ActivityTime struct {
	ActivityID int
	StartTime  time.Time
	EndTime    time.Time
	Status     int
}

// ActivityTimeList 活动时间Map
var ActivityTimeList = []ActivityTime{}
