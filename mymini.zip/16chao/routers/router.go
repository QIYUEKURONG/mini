//Package routers ...
// @APIVersion 1.0.0
// @Title beego Test API
// @Description beego has a very cool tools to autogenerate documents for your API
// @Contact astaxie@gmail.com
// @TermsOfServiceUrl http://beego.me/
// @License Apache 2.0
// @LicenseUrl http://www.apache.org/licenses/LICENSE-2.0.html
package routers

import (
	"16chao/controllers"
	"16chao/models"

	"github.com/astaxie/beego"
)

func init() {

	//start mysql
	models.InitialMySQL()
	//路由表
	beego.Router("/v1/register", &controllers.UserController{}, "post:Register")
	beego.Router("/v1/publish", &controllers.ActivityController{}, "post:Publish")    //lys
	beego.Router("/v1/publish2", &controllers.Activity2Controller{}, "post:Publish2") //lys
	beego.Router("/v1/QuitActivity", &controllers.QuitActivityController{}, "post:QuitActivity")
	beego.Router("/v1/EndActivity", &controllers.EndActivityController{}, "post:EndActivity")
	beego.Router("/v1/AgainActivity", &controllers.AgainActivityController{}, "post:AgainActivity")
	beego.Router("/v1/KickPeople", &controllers.KickPeopleController{}, "post:KickPeople")
	beego.Router("/v1/DismissActivity", &controllers.DismissActivityController{}, "post:DismissActivity")
	beego.Router("/v1/scanActivity", &controllers.ActivityController{}, "post:ScanActivity")
	beego.Router("/v1/getfile", &controllers.Demo3Controller{}, "Get:Getfile;Post:Postfile")
	beego.Router("/v1/isParticipateAcitivity", &controllers.ActivityController{}, "Post:BeIn") //lys
	beego.Router("/v1/SignUp", &controllers.ActivityController{}, "Post:BeInInsert")
	beego.Router("/v1/ActivityDetails", &controllers.ActivityDetailsController{}, "post:ActivityDetails")
	beego.Router("/v1/Subscription", &controllers.SubscriptionController{}, "post:Subscription")
	beego.Router("/v1/SubscriptionSetting", &controllers.SubscriptionController{}, "post:SubscriptionSetting")
	beego.Router("/v1/InterestActivity", &controllers.MaybeInterestedController{}, "post:MaybeInterested")
	beego.Router("/v1/ScanActivityDetails", &controllers.ScanActivityDetailsController{}, "post:ScanActivityDetails")
	beego.Router("/v1/GetMyActivities", &controllers.MyActivitiesController{}, "post:GetMyActivities") //lys
	beego.Router("/v1/login", &controllers.LoginController{}, "post:Login")
	beego.Router("/v1/Mark", &controllers.MarkController{}, "post:Mark")
	beego.Router("/", &controllers.MonitorController{}) //lys

}
