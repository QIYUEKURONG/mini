package main

import (
	"16chao/def"
	"16chao/models"
	_ "16chao/routers"
	"encoding/json"
	"fmt"
	"time"

	"github.com/astaxie/beego"
	"github.com/astaxie/beego/logs"
)

func main() {
	if beego.BConfig.RunMode == "dev" {
		beego.BConfig.WebConfig.DirectoryIndex = true
		beego.BConfig.WebConfig.StaticDir["/swagger"] = "swagger"
	}

	// 日志模块配置 begin  cxh
	// initial log
	logConfig := map[string]interface{}{
		"filename": beego.AppConfig.DefaultString("logFilename", "logs/16chao.log"),
		"level":    beego.AppConfig.DefaultInt("logLevel", 7), //beego.LevelDebug
		"maxlines": beego.AppConfig.DefaultInt("logMaxlines", 0),
		"maxsize":  beego.AppConfig.DefaultInt("logMaxsize", 0),
		"daily":    beego.AppConfig.DefaultBool("logDaily", true),
		"maxdays":  beego.AppConfig.DefaultInt("logMaxdays", 15),
	}

	logConfigJSON, _ := json.Marshal(logConfig)
	err := beego.BeeLogger.SetLogger(logs.AdapterFile, string(logConfigJSON))
	if err != nil {
		fmt.Printf("ERROR_SYSTEM initial log failed, %v\r\n", err)
	}

	logs.EnableFuncCallDepth(true) //enable func call depth
	logs.SetLogFuncCallDepth(3)

	// 打开输出日志到logs
	beego.BConfig.Log.AccessLogs = true
	filterURIPrint()
	// 设置logs.X相关打印不输出到控制台，只输出到文件
	//beego.BeeLogger.DelLogger("console")
	// 日志模块配置 end

	//第一次跑程序的把activity表的信息导入到def.ActivityTimeList中
	errtransfer := models.GetActivityModel().TransferData()
	if errtransfer != nil {
		logs.Info("%v", errtransfer)
	}
	//每隔一分钟更新一个活动状态的携程
	go SetActivityStatus()

	//设置静态文件路径
	beego.BConfig.WebConfig.StaticDir["/static"] = "static"
	beego.SetStaticPath("/userpost", "static/userpost")
	beego.SetStaticPath("/default", "static/default")
	beego.Run()
}

// 过滤不需要打印的URI, router.go
func filterURIPrint() {
	filterURI := "/internal/pos/v1/sys/checktransfer/getdatabyid"
	beego.BConfig.WebConfig.StaticDir[filterURI] = filterURI
}

//SetActivityStatus ...处理活动状态的goroutine
func SetActivityStatus() {
	for {
		//遍历活动时间表
		for i := 0; i < len(def.ActivityTimeList); i++ {
			// 集结中 -> 活动进行中 之后不再对该活动状态进行表操作更新。
			if def.ActivityTimeList[i].StartTime.Before(time.Now()) &&
				def.ActivityTimeList[i].EndTime.After(time.Now()) &&
				def.ActivityTimeList[i].Status == def.StatIsCalling {
				def.ActivityTimeList[i].Status = def.Statbein
				//时间满足更新条件，去看对应状态是否需要更新，排除活动状态是3和4的
				//第二个参数是updateType  0表示 从活动未开始更新到活动开始
				err := models.GetActivityModel().UpdateStatus(def.ActivityTimeList[i].ActivityID, 0)
				if err != nil {
					logs.Error("%v", err)
					return
				}
			}
			//活动进行中->活动结束
			if def.ActivityTimeList[i].EndTime.Before(time.Now()) {
				//时间满足更新条件，去看对应状态是否需要更新，排除活动状态是3和4的
				//第二个参数是updateType  1表示 从活动进行中更新到活动结束
				err := models.GetActivityModel().UpdateStatus(def.ActivityTimeList[i].ActivityID, 1)
				if err != nil {
					logs.Error("%v", err)
					return
				}
			}
		}
		time.Sleep(30 * time.Second)
	}
}
