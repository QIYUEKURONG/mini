package services

import (
	"16chao/def"
	"16chao/models"
	"16chao/util/errs"
	"fmt"

	"github.com/astaxie/beego/logs"
)

// AgainActivityService  define
type AgainActivityService struct {
}

//NewAgainActivityService ..
func NewAgainActivityService() *AgainActivityService {
	return &AgainActivityService{}
}

// AgainActivity 队长点击集结完毕
func (s *AgainActivityService) AgainActivity(UserID, ActivityID int) *errs.AppFail {
	//根据activity_id查询活动信息表对应的记录
	activityInfo, err := models.GetActivityModel().GetActivityByID(ActivityID)
	if activityInfo == nil {
		fmt.Printf("err : %v", err)
		return errs.NewAppFail("该活动不存在")
	}
	if err != nil {
		fmt.Printf("err : %v", err)
		return errs.NewAppFail("内部错误")
	}

	//确定是否处于正在集结完成状态
	if activityInfo.Status != def.StatCallFinished {
		logs.Info("activity_status is not StatCallFinished (activityid %d)", ActivityID)
		return errs.NewAppFail("当前活动状态不是集结完成状态")
	}
	//根据user_id，activity_id查询活动成员表对应的记录
	activitymemberInfo, err := models.GetActivityMemberListModel().GetActivityMemberInfo(UserID, ActivityID)
	if err != nil {
		fmt.Printf("err : %v", err)
		logs.Info("activitymemberList query failed (activityid %d userid %d)", ActivityID, UserID)
		return errs.NewAppFail("内部错误")
	}
	//确定UserID是否为队长
	if activitymemberInfo.IsCaptain != 1 {
		logs.Info("UserID is not Captain (activityid %d userid %d)", ActivityID, UserID)
		return errs.NewAppFail("只有队长才有此权限")
	}
	//根据活动信息表ID更新当前活动状态信息
	err = models.GetActivityModel().UpdateStateByActivityID(ActivityID, def.StatIsCalling)
	if err != nil {
		fmt.Printf("err : %v", err)
		logs.Info("againactivity is failed (activityid %d userid %d)", ActivityID, UserID)
		return errs.NewAppFail("内部错误")
	}

	return nil
}
