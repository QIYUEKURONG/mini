package services

import (
	"16chao/def"
	"16chao/models"
	"16chao/util"
	"16chao/util/errs"
	//"cxh/params"
	"fmt"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/astaxie/beego/logs"
)

// ActivityService  define
type ActivityService struct {
}

//NewActivityService ..
func NewActivityService() *ActivityService {
	return &ActivityService{}
}

// Publish 发布活动
func (a *ActivityService) Publish(
	ActivityName, LabelName, LocationName, Description, Prefix, Stime, Etime string, UserID, MaxMember, MinMember int, Longitude float64, Latitude float64, ImgDefault bool) (int, string, *errs.AppError) {
	// ActivityID := int(time.Now().UnixNano())
	// ActivityMemberListID := int(time.Now().UnixNano())
	//def.IDinc++
	//LabelID由label_name获取
	LabelID, errlabel := models.GetLabelModel().GetLabelIDByName(LabelName)
	if errlabel != nil {
		fmt.Printf("errlabel : %v", errlabel)
		return -1, "", errs.NewErrCode(def.ErrMsg[def.EInternalErr], def.EInternalErr)
	}
	s, _ := time.ParseInLocation(def.TimeStampFmt, Stime, time.Local)
	e, _ := time.ParseInLocation(def.TimeStampFmt, Etime, time.Local)
	//发布集结，涉及更新两个表，一个是activity表 一个是activity_member_list表
	record := &models.ActivityModel{
		//ID:                ActivityID,
		Name:              ActivityName,
		Description:       Description,
		Status:            0,
		LocationLongitude: Longitude,
		LocationLatitude:  Latitude,
		LocationName:      LocationName,
		MinMember:         MinMember,
		MaxMember:         MaxMember,
		CurrentMember:     1,
		StartTime:         s,
		EndTime:           e,
		LabelID:           LabelID,
		Image:             def.PrefixDef,
	}
	//插入完成
	errinsert := models.GetActivityModel().InsertOne(record)
	//发起聊天室连接

	if errinsert != nil {
		logs.Warn("[Publish]errinsert : %v", errinsert)
		return record.ID, "", errs.NewErrCode(def.ErrMsg[def.EInternalErr], def.EInternalErr)
	}
	Picpath := strconv.Itoa(record.ID) + ".jpg"
	record.Image = def.PrefixUser + Picpath

	//记录活动的开始时间和结束时间，供后台更新状态和创建评价表
	atime := new(def.ActivityTime)
	atime.ActivityID = record.ID
	atime.StartTime = s
	atime.EndTime = e
	atime.Status = 0
	def.ActivityTimeList = append(def.ActivityTimeList, *atime)
	fmt.Println("--------活动时间列表----------")
	fmt.Println(def.ActivityTimeList)
	fmt.Println("--------活动时间列表----------")
	//记录结束
	temp := make(map[string]interface{}, 0)
	temp["image"] = record.Image
	errimg := models.GetActivityModel().UpdateColsByActivityID(record.ID, temp)
	if errimg != nil {
		logs.Warn("[Publish]errimg : %v", errimg)
		return record.ID, "", errs.NewErrCode(def.ErrMsg[def.EInternalErr], def.EInternalErr)
	}
	//activity_member_list表
	recordMemberList := &models.ActivityMemberListModel{
		//ActivityMemberListID: ActivityMemberListID,
		ActivityID: record.ID,
		UserID:     UserID,
		IsCaptain:  1,
	}
	errMemberList := models.GetActivityMemberListModel().InsertOne(recordMemberList)
	if errMemberList != nil {
		logs.Warn("[Publish]InsertActivityMemberListErr : %v", errMemberList)
		return record.ID, "", errs.NewErrCode(def.ErrMsg[def.EInternalErr], def.EInternalErr)
	}
	return record.ID, record.Image, nil
}

// ScanActivity 查看集结获取
func (a *ActivityService) ScanActivity(
	UserID int, Type string, StartTime string, EndTime string, Latitude float64, Longitude float64, Radius float64, sortByTime string, sortByDis string) ([]*models.ActivityModel, []float64, *errs.AppError) {
	var resp []*models.ActivityModel
	/**
	*usage：查询用户参加了哪些活动
	*input:用户ID
	*output:活动ID的列表
	 */
	arra, err := models.GetActivityMemberListModel().GetActivityMemberListByUserID(UserID)
	if err != nil {
		fmt.Printf("[ScanActivity]GetActivityMemberListByUserIDErr : %v", err)
	}
	//利用Type查询对应的labelid
	Type = strings.Replace(Type, " ", "", -1)
	Types := strings.Split(Type, ",")
	var labelID int
	var labelErr error
	var labelIDs []string
	if Type != "" {
		for _, label := range Types {
			labelID, labelErr = models.GetLabelModel().GetLabelIDByName(label)
			labelIDs = append(labelIDs, strconv.Itoa(labelID))
		}
	}

	var condition string

	if labelIDs != nil && labelErr == nil {
		var strL = "("
		for _, tempID := range labelIDs {
			if tempID != "-1" {
				if strL != "(" {
					strL += "or label_id ='" + tempID + "'"
				} else {
					strL += " label_id ='" + tempID + "' "
				}
			}
		}
		strL += ") "
		if strL != "() " {
			condition += strL
		}
	}
	if StartTime != "" {
		if condition != "" {
			condition += "and start_time > '" + StartTime + "' "
		} else {
			condition += "start_time > '" + StartTime + "' "
		}
	}
	if EndTime != "" {
		if condition != "" {
			condition += "and start_time <'" + EndTime + "' "
		} else {
			condition += "start_time <'" + EndTime + "' "
		}
	}
	logs.Info("condition:", condition)
	/**
	*usage：获取用户的查看集结的列表
	*input:活动ID的列表
	*output：用户没有参加过的活动列表
	 */
	data, errGBC := models.GetActivityModel().GetActivitysByCondition(arra, condition)
	if errGBC != nil {
		logs.Info("condition:", condition)
		logs.Warn("[ScanActivity]GetActivitysByConditionError:", errGBC)
	}
	//fmt.Print(data[0].LabelID)
	//latitude范围为-90 ~ 90 longitude范围为-180 ~ 180
	var distances []float64

	for _, arr := range data {
		//fmt.Println(arr.ID)
		p1, errP1 := util.NewPosition(Latitude, Longitude)
		p2Longitude := arr.LocationLongitude
		p2Latitude := arr.LocationLatitude
		p2, errP2 := util.NewPosition(p2Latitude, p2Longitude)

		if errP1 != nil {
			logs.Info("p1Longitude:", Longitude, "p1Latitude:", Latitude)
			logs.Error("[ScanActivity]errP1 : %v", errP1)
			return nil, nil, errs.NewErrCode("Value out of range", def.EInternalErr)
		}
		if errP2 != nil {
			logs.Info("p2Longitude:", p2Longitude, "p2Latitude:", p2Latitude)
			logs.Error("[ScanActivity]errP2 : %v", err)
			return nil, nil, errs.NewErrCode("Value out of range", def.EInternalErr)
		}
		distance := util.EarthDistance(p1, p2)
		distances = append(distances, distance)
	}

	if data != nil {
		for _, detail := range data {
			tmp, err := detail.GetActivityByID(detail.ID)
			resp = append(resp, tmp) //resp[index]

			if err != nil {
				fmt.Printf("err : %v", err)
			}
		}

	}
	respO, distancesO := SearchAndOrderByInstance(resp, distances, Radius, sortByDis, sortByTime)
	for index, arr := range respO {
		fmt.Println(arr.ID)
		fmt.Println(distancesO[index])
	}
	return respO, distancesO, nil
}

// ModelAndInstance as models.ActivityModel and instance
type ModelAndInstance struct {
	ac       models.ActivityModel
	instance float64
}

const (
	//DESC 降序
	DESC string = "DESC"
	//ASC 升序
	ASC string = "ASC"
)

//SearchAndOrderByInstance 根据距离筛选活动，并按照距离排序
func SearchAndOrderByInstance(acs []*models.ActivityModel, instances []float64, Radius float64, sortByDis string, sortByTime string) ([]*models.ActivityModel, []float64) {
	var mais []*ModelAndInstance
	var resacRes []*models.ActivityModel
	var resinsRes []float64
	if Radius != 0 && Radius != -1 {
		for i := range acs {
			if instances[i] < Radius {
				var mai ModelAndInstance
				mai.ac = *acs[i]
				mai.instance = instances[i]
				mais = append(mais, &mai)
			}
		}
	} else {
		for i := range acs {
			var mai ModelAndInstance
			mai.ac = *acs[i]
			mai.instance = instances[i]
			mais = append(mais, &mai)
		}
	}
	if sortByDis == "" {
		if sortByTime != "" {
			if sortByTime == DESC {
				sort.Sort(sort.Reverse(ModelAndStartTimeSplice(mais)))
			} else {
				sort.Sort(ModelAndStartTimeSplice(mais))
			}
		} else {
			sort.Sort(ModelAndInstanceSplice(mais))
		}
	} else {
		if sortByDis == ASC {
			sort.Sort(ModelAndInstanceSplice(mais))
		} else {
			sort.Sort(sort.Reverse(ModelAndInstanceSplice(mais)))
		}
	}

	for i := 0; i < len(mais); i++ {
		resacRes = append(resacRes, &mais[i].ac)
		resinsRes = append(resinsRes, mais[i].instance)
	}
	return resacRes, resinsRes
}

//ModelAndInstanceSplice 排序类型
type ModelAndInstanceSplice []*ModelAndInstance

func (a ModelAndInstanceSplice) Len() int {
	return len(a)
}
func (a ModelAndInstanceSplice) Swap(i, j int) {
	a[i], a[j] = a[j], a[i]
}
func (a ModelAndInstanceSplice) Less(i, j int) bool {
	return a[i].instance < a[j].instance
}

//ModelAndStartTimeSplice 排序类型(按时间倒序)
type ModelAndStartTimeSplice []*ModelAndInstance

func (a ModelAndStartTimeSplice) Len() int {
	return len(a)
}
func (a ModelAndStartTimeSplice) Swap(i, j int) {
	a[i], a[j] = a[j], a[i]
}
func (a ModelAndStartTimeSplice) Less(i, j int) bool {
	return a[i].ac.StartTime.Before(a[j].ac.StartTime)
}
