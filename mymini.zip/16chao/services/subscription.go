//Package services 该文件由ZHB编写
package services

import (
	"16chao/models"
	"16chao/util/errs"
	"sort"

	"github.com/astaxie/beego/logs"
)

//CategoryInfo 结构体
type CategoryInfo struct {
	LabelCategoryID      int    `json:"label_category_id"`
	LabelCategoryName    string `json:"label_category_name"`
	LabelCategoryPicture string `json:"label_category_picture"`
}

//MyInterestInfo 结构体
type MyInterestInfo struct {
	LabelID         int    `json:"label_id"`
	LabelName       string `json:"label_name"`
	LabelPicture    string `json:"label_picture"`
	LabelCategoryID int    `json:"label_category_id"`
	IsInterest      bool   `json:"is_interest"`
}

//SubscriptionSetInfo 结构体
type SubscriptionSetInfo struct {
	LabelID    int  `json:"label_id"`
	IsInterest bool `json:"is_interest"`
}

// SubscriptionService  define
type SubscriptionService struct {
}

//ViewSubscriptionService 查看订阅设置
func ViewSubscriptionService() *SubscriptionService {
	return &SubscriptionService{}
}

//SubscriptionSettingService 提交订阅设置
func SubscriptionSettingService() *SubscriptionService {
	return &SubscriptionService{}
}

//Subscription 查看订阅设置
func (s *SubscriptionService) Subscription(UserID int) ([]CategoryInfo, []MyInterestInfo, *errs.AppFail) {
	var categoryresp []CategoryInfo
	var myinterestresp []MyInterestInfo

	//对UserID进行判断，是否存在与用户表当中
	userInfo, err := models.GetUserModel().GetUserInfo(UserID)
	if err != nil {
		logs.Warn("GetUserInfo err : %v", err)
		return nil, nil, errs.NewAppFail("查询数据库错误")
	}
	if userInfo == nil {
		logs.Warn("user_id = %d not exist", UserID)
		return nil, nil, errs.NewAppFail("用户不存在")
	}

	//根据UserID获取该用户所设置的订阅
	myInterest, err := models.GetMyInterestModel().GetMyInterestByUserID(UserID)
	if err != nil {
		logs.Warn("GetMyInterestByUserID err:%v", err)
		return nil, nil, errs.NewAppFail("获取用户兴趣信息错误")
	}

	//获得所有活动类型
	allLabel, err := models.GetLabelModel().GetAllLabel()
	if err != nil {
		logs.Warn("GetAllLabel err:%v", err)
		return nil, nil, errs.NewAppFail("获取所有活动类型错误")
	}

	//如果活动类型表为空，则直接返回空
	if allLabel == nil {
		logs.Warn("allLabel is null")
		return nil, nil, nil
	}

	//获得活动大类表
	allLabelCategory, err := models.GetLabelCategoryModel().GetAllLabelCategory()
	if err != nil {
		logs.Warn("GetAllLabelCategory err:%v", err)
		return nil, nil, errs.NewAppFail("获取所有活动大类错误")
	}

	//如果活动大类表为空，则直接返回空
	if allLabelCategory == nil {
		logs.Warn("allLabelCategory is null")
		return nil, nil, nil
	}

	for _, value := range allLabelCategory {
		categoryresp = append(categoryresp, CategoryInfo{value.LabelCategoryID, value.LabelCategoryName, value.LabelCategoryPicture})
	}

	//如果用户的兴趣为空，则返回的所有活动类型对应的IsInterest字段均为false
	if myInterest == nil {
		for _, interest := range allLabel {
			myinterestresp = append(myinterestresp, MyInterestInfo{interest.LabelID, interest.LabelName, interest.LabelPicture, interest.LabelCategoryID, false})
		}
		return categoryresp, myinterestresp, nil
	}

	//如果有记录，则需要逐条查看哪些有兴趣
	//m用于记录用户对哪些活动有兴趣
	m := make(map[int]*MyInterestInfo)
	for _, value := range allLabel {
		m[value.LabelID] = &MyInterestInfo{value.LabelID, value.LabelName, value.LabelPicture, value.LabelCategoryID, false}
	}

	for _, value := range myInterest {
		//如果用户的兴趣活动labelID不在活动类型表当中，说明有问题
		if _, ok := m[value.LabelID]; !ok {
			logs.Warn("my_interest labelID is not exist in the Label")
			return nil, nil, errs.NewAppFail("内部错误")
		}
		//若存在则更改对应的值
		m[value.LabelID].IsInterest = true
	}

	//由于map没有顺序，所以这里按照LabelID从小到大排序输出
	var labelID []int
	for k := range m {
		labelID = append(labelID, k)
	}
	sort.Ints(labelID)

	//按照LabelID顺序，为resp赋值
	for _, keys := range labelID {
		myinterestresp = append(myinterestresp, MyInterestInfo{m[keys].LabelID, m[keys].LabelName, m[keys].LabelPicture, m[keys].LabelCategoryID, m[keys].IsInterest})
	}

	return categoryresp, myinterestresp, nil
}

//SubscriptionSetting 提交订阅设置
func (s *SubscriptionService) SubscriptionSetting(UserID int, SubscriptionSet []SubscriptionSetInfo) *errs.AppFail {
	//以下代码用于处理前端返回所有的活动项
	//对UserID进行判断，是否存在与用户表当中
	userInfo, err := models.GetUserModel().GetUserInfo(UserID)
	if err != nil {
		logs.Warn("GetUserInfo err : %v", err)
		return errs.NewAppFail("查询数据库错误")
	}
	if userInfo == nil {
		logs.Warn("user_id = %d not exist", UserID)
		return errs.NewAppFail("用户不存在")
	}

	//对SubscriptionSet中的数量进行检测，label_id数量必须等于数据库中已有的
	num, numerr := models.GetLabelModel().GetLabelNum()
	if numerr != nil {
		logs.Warn("GetLabelNum err : %v", err)
		return errs.NewAppFail("查询数据库错误")
	}
	if len(SubscriptionSet) != num {
		logs.Warn("input labelnum = %d is not equal to database label_num = %d", len(SubscriptionSet), num)
		return errs.NewAppFail("传入label数量错误")
	}

	//对SubscriptionSet中的label_id进行检查，判断其是否存在于label表当中，防止写入错误信息
	for _, value := range SubscriptionSet {
		ret, geterr := models.GetLabelModel().GetLabelNameByLabelID(value.LabelID)
		if geterr != nil {
			logs.Warn("GetLabelNameByLabelID err : %v", geterr)
			return errs.NewAppFail("查询数据库错误")
		}
		if ret == "" {
			logs.Warn("label_id = %d 不存在", value.LabelID)
			return errs.NewAppFail("label_id不存在")
		}
	}

	//根据UserID将兴趣表当中已有的记录全部清除
	err = models.GetMyInterestModel().DeleteByUserID(UserID)
	if err != nil {
		logs.Warn("DeleteByUserID err : %v", err)
		return errs.NewAppFail("删除用户兴趣信息错误")
	}

	//根据传入的数据，如果兴趣为true，则加入兴趣表
	for _, value := range SubscriptionSet {
		if value.IsInterest {
			//将此项加入兴趣表
			record := &models.MyInterestModel{
				UserID:  UserID,
				LabelID: value.LabelID,
			}
			err = models.GetMyInterestModel().InsertOne(record)
			if err != nil {
				logs.Warn("InsertOne err : %v", err)
				return errs.NewAppFail("加入用户兴趣信息错误")
			}
		}
	}

	return nil
}
