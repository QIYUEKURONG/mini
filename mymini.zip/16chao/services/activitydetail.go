package services

import (
	"16chao/def"
	"16chao/models"
	"16chao/util"
	"16chao/util/errs"
	"fmt"
	"time"

	"github.com/astaxie/beego/logs"
)

// ActivityRegResp   返回活动参数信息
type ActivityRegResp struct {
	UserID        int              `json:"user_id"`
	ActivityName  string           `json:"activity_name"`
	LabelName     string           `json:"label_name"`
	StartTime     time.Time        `json:"start_time"`
	EndTime       time.Time        `json:"end_time"`
	MaxMember     int              `json:"max_member"`
	MinMember     int              `json:"min_member"`
	Longtitude    float64          `json:"location_longtitude"`
	Latitude      float64          `json:"location_latitude"`
	Description   string           `json:"description"`
	Status        int              `json:"activity_status"`
	MemberLists   []MemberListType `json:"members"`
	Image         string           `json:"image"`
	LocationName  string           `json:"location_name"`
	CurrentMember int              `json:"current_name"`
}

// MemberListType ..
type MemberListType struct {
	UserID     int    `json:"user_id"`
	UserAvatar string `json:"user_avatar"`
	IsCaptain  int    `json:"is_captain"`
}

// ActivityDetailService  define
type ActivityDetailService struct {
}

//GetActivityDetailService ..
func GetActivityDetailService() *ActivityDetailService {
	return &ActivityDetailService{}
}

// Details 活动详情   zhangtianlong
func (a *ActivityDetailService) Details(ActivityID, UserID int, Latitude float64, Longitude float64) (ActivityRegResp, float64, *errs.AppError) {

	var resp ActivityRegResp

	// //判断用户是否在该活动中   在我参加的活动详情页 需要判断，查看集结详情页不需判断 由于目前项目1.0马上上线，且这两模块都调用该接口 故先不做修改
	// dmp, drr := models.GetActivityMemberListModel().GetActivityMemberInfo(UserID, ActivityID)
	// if dmp == nil {
	// 	logs.Warn("ActivityMemberService :用户不在该活动表中")
	// 	return ActivityRegResp{}, -1, errs.NewErrCode(def.ErrMsg[def.EInternalErr], def.EInternalErr)
	// }
	// if drr != nil {
	// 	logs.Warn("ActivityMemberService :GetMembers, err:%v", drr)
	// 	return ActivityRegResp{}, -1, errs.NewErrCode(def.ErrMsg[def.EInternalErr], def.EInternalErr)
	// }

	tmp, arr := models.GetActivityModel().GetActivityByID(ActivityID)
	logs.Warn("act info : %v\n", tmp)
	if arr != nil || tmp == nil {
		logs.Warn("err : %v", arr)
		return ActivityRegResp{}, -1, errs.NewErrCode(def.ErrMsg[def.EInternalErr], def.EInternalErr)
	}

	resp.ActivityName = tmp.Name
	resp.Description = tmp.Description
	resp.EndTime = tmp.EndTime
	resp.Latitude = tmp.LocationLatitude
	resp.Longtitude = tmp.LocationLongitude
	resp.MaxMember = tmp.MaxMember
	resp.MinMember = tmp.MinMember
	resp.StartTime = tmp.StartTime
	resp.Status = tmp.Status
	resp.Image = tmp.Image
	resp.LocationName = tmp.LocationName
	resp.CurrentMember = tmp.CurrentMember
	resp.UserID = UserID

	//通过labelid查询到labelname  tmp.labelid
	amp, err1 := models.GetLabelModel().GetLabelByID(tmp.LabelID)
	if err1 != nil {
		logs.Warn("err : %v", err1)
	}
	resp.LabelName = amp.LabelName

	var rel []MemberListType
	//通过ActivityID查询到活动成员信息
	bmp, err := models.GetActivityMemberListModel().GetActivityMemberListByActivityID(ActivityID)
	var distance float64 //定义距离

	if err != nil || bmp == nil {
		logs.Warn("ActivityDetailService :Details, err:%v", err)
		return ActivityRegResp{}, distance, errs.NewErrCode(def.ErrMsg[def.EInternalErr], def.EInternalErr)
	}

	//通过bmp.UserID分别查询所有用户的头像
	for _, value := range bmp {
		if value.UserID < 0 {
			logs.Warn("UserID is null")
		}

		ump, err2 := models.GetUserModel().GetUserInfo(value.UserID)
		if err2 != nil {
			logs.Warn("ActivityDetailService :GetUserInfo, err:%v", err)
			return ActivityRegResp{}, distance, errs.NewErrCode(def.ErrMsg[def.EInternalErr], def.EInternalErr)
		}
		if ump == nil {
			logs.Warn("ActivityDetailService :GetUserInfo is null")
			return ActivityRegResp{}, distance, errs.NewErrCode(def.ErrMsg[def.EInternalErr], def.EInternalErr)
		}
		member := MemberListType{
			UserID:     value.UserID,
			UserAvatar: ump.Avatar,
			IsCaptain:  value.IsCaptain,
		}
		rel = append(rel, member)
		resp.MemberLists = rel
	}
	//计算距离
	//latitude范围为-90 ~ 90 longitude范围为-180 ~ 180

	p1, errP1 := util.NewPosition(Latitude, Longitude)
	p2Latitude := tmp.LocationLatitude
	p2Longitude := tmp.LocationLongitude
	p2, errP2 := util.NewPosition(p2Latitude, p2Longitude)
	if errP1 != nil {
		logs.Warn("errP1 : %v", errP1)
	}
	if errP2 != nil {
		logs.Warn("errP2 : %v", err)
		//return nil, nil, errs.NewErrCode("Value out of range", def.EInternalErr)
	}
	distance = util.EarthDistance(p1, p2)
	fmt.Println(distance)

	return resp, distance, nil
}
