package services

import (
	"16chao/def"
	"16chao/models"
	"16chao/util/errs"
	"time"

	"github.com/astaxie/beego/logs"
)

// UserService  define
type UserService struct {
}

//NewUserService ..
func NewUserService() *UserService {
	return &UserService{}
}

// Register 用户注册
func (s *UserService) Register(Name, Avatar, Region, OpenID string, Gender int) (int, *errs.AppFail) {
	userID := int(time.Now().Unix())

	userInfo, err := models.GetUserModel().GetUserInfo(userID)
	if err != nil {
		logs.Warn("UserService :Register, err:%v", err)
		return 0, errs.NewAppFail("内部错误")
	}
	if userInfo != nil {
		logs.Info("user_id exist, don't register again!(%d)", userID)
		return userID, errs.NewAppFail("内部错误")
	}
	record := &models.UserModel{
		ID:     userID,
		Name:   Name,
		Avatar: Avatar,
		Gender: Gender,
		Region: Region,
		OpenID: OpenID,
	}
	err = models.GetUserModel().InsertOne(record)
	if err != nil {
		logs.Error("[Register]insert err : %v", err)
		return 0, errs.NewAppFail("内部错误")
	}
	return userID, nil
}

//Exist 判断用户是否为已经注册（存在）的用户
func (s *UserService) Exist(UserID int) (bool, *errs.AppError) {
	userInfo, err := models.GetUserModel().GetUserInfo(UserID)
	//用户不存在，操作成功
	if userInfo == nil && err == nil {
		return false, nil
	} else if userInfo == nil && err != nil {
		return false, errs.NewErrCode(def.ErrMsg[def.EInternalErr], def.EInternalErr)
		//无法确定用户情况， 操作失败
	} else {
		return true, nil
		//用户存在，操作成功
	}
}
