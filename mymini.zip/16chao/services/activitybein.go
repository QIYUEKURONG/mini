package services

import (
	"16chao/def"
	"16chao/models"
	"16chao/util/errs"
	"fmt"

	"github.com/astaxie/beego/logs"
)

// ActivityBeInService  define
type ActivityBeInService struct {
}

//ActivityBeInResp 正在进行的活动返回的参数
type ActivityBeInResp struct {
	ActivityID        int    `json:"activity_id"`
	ActivityName      string `json:"activity_name"`
	ActivityStatus    int    `json:"activity_status"`
	ActivityMaxMember int    `json:"activity_max_member"`
	ActivityCurMember int    `json:"activity_current_member"`
	ActivityImage     string `json:"image"`
}

//ActivityBeInInsertResp 用户插入活动关系数据返回的参数
type ActivityBeInInsertResp struct {
	Status  string `json:"status"`
	Message string `json:"message"`
}

//NewActivityBeInService ..
func NewActivityBeInService() *ActivityBeInService {
	return &ActivityBeInService{}
}

//BeInID 根据用户ID，返回用户参加的活动Id数组
func (a *ActivityBeInService) BeInID(UserID int) ([]int, *errs.AppError) {
	aid, err := models.GetActivityMemberListModel().GetActivtityByUserID(UserID)
	if err != nil {
		logs.Warning("BeInID:", err)
		return aid, errs.NewErrCode(def.ErrMsg[def.EInternalErr], def.EInternalErr)
	}
	return aid, nil
}

//BeInInfo 根据活动ID，返回用户正在参加活动的信息
func (a *ActivityBeInService) BeInInfo(aid []int, limit int) ([]ActivityBeInResp, *errs.AppError) {
	ret := make([]ActivityBeInResp, 0)
	for i := 0; i < len(aid); i++ {
		ActivitiyModel, err := models.GetActivityModel().GetActivityByID(aid[i])
		if err != nil {
			logs.Warning("BeInInfo:", err)
			return ret, errs.NewErrCode(def.ErrMsg[def.EInternalErr], def.EInternalErr)
		}
		if ActivitiyModel.Status == 0 || ActivitiyModel.Status == 1 || ActivitiyModel.Status == 2 {
			tmp := ActivityBeInResp{
				ActivityID:        ActivitiyModel.ID,
				ActivityName:      ActivitiyModel.Name,
				ActivityStatus:    ActivitiyModel.Status,
				ActivityMaxMember: ActivitiyModel.MaxMember,
				ActivityCurMember: ActivitiyModel.CurrentMember,
				ActivityImage:     ActivitiyModel.Image,
			}
			ret = append(ret, tmp)
			//只返回limit条正在参加的活动信息
			if len(ret) >= limit {
				return ret, nil
			}
			//测试行fmt.Println(out)
		}
	}
	return ret, nil
}

//BeInInsert 在表中插入一条数据 aid:活动ID  uid:用户ID
func (a *ActivityBeInService) BeInInsert(aid int, uid int) (ActivityBeInInsertResp, error) {
	var ret ActivityBeInInsertResp
	var aml models.ActivityMemberListModel
	tx := models.GetOrm().Begin()
	retGet, _ := models.GetActivityMemberListModel().GetActivityMemberInfo(uid, aid)
	fmt.Println(retGet)
	if retGet.ActivityMemberListID == 0 {
		aml.ActivityID = aid
		aml.UserID = uid
		// aml.ActivityMemberListID = int(time.Now().Unix())
		aml.IsCaptain = 0
		acn, errAC := models.GetActivityModel().GetActivityByID(aid)
		if errAC != nil || acn == nil {
			tx.Rollback()
			ret = ActivityBeInInsertResp{
				Message: "活动查询失败，数据返回异常",
				Status:  "false",
			}
			logs.Warn("GetActivityByID:", errAC)
			return ret, errAC
		}
		//在ActivityMemberListModel表中插入活动关系记录
		errInsert := models.GetActivityMemberListModel().InsertOne(&aml)
		if errInsert != nil {
			tx = models.GetOrm().Rollback()
			ret = ActivityBeInInsertResp{
				Message: "数据返回失败",
				Status:  "false",
			}
			logs.Warn("errInsert:", errInsert)
			return ret, errInsert
		}
		errUp := acn.UpdateCurrentMemberByActivityID(aid, acn.CurrentMember+1)
		if errUp != nil {
			tx.Rollback()
			ret = ActivityBeInInsertResp{
				Message: "数据返回失败",
				Status:  "false",
			}
			logs.Warn("UpdateCurrentMemberByActivityID:", errUp)
			return ret, errUp
		}

		ret = ActivityBeInInsertResp{
			Message: "报名成功",
			Status:  "true",
		}
		logs.Info("Be in successful")
		return ret, tx.Commit().Error

	}
	ret = ActivityBeInInsertResp{
		Message: "您已报名成功",
		Status:  "false",
	}
	logs.Warn("have successfully,have not be in insert")
	return ret, tx.Commit().Error
}
