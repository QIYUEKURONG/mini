package services

import (
	"16chao/def"
	"16chao/models"
	"16chao/util/errs"
	"errors"
	"fmt"

	"github.com/astaxie/beego/logs"
)

// this file edit by 陈向煌

// MarkService  define
type MarkService struct {
}

//NewMarkService ..
func NewMarkService() *MarkService {
	return &MarkService{}
}

// Mark 用户主动打分
func (s *MarkService) Mark(UserID, TargetUserID int, MarkScore float64, ActivityID int) *errs.AppFail {

	flag, err := models.GetMarkModel().IsParamValid(UserID, TargetUserID, ActivityID)
	if err != nil || flag == 0 {
		logs.Warn("mark param err ：UserID %d, TargetUserID %d, ActivityID %d", UserID, TargetUserID, ActivityID)
		return errs.NewAppFail("参数错误")
	}

	record := &models.MarkModel{
		UserID:       UserID,
		TargetUserID: TargetUserID,
		Score:        MarkScore,
		ActivityID:   ActivityID,
		DefaultFlag:  def.UserMark,
	}
	err = models.GetMarkModel().UpdateMarkScore(record)
	if err != nil {
		fmt.Printf("err : %v", err)
		return errs.NewAppFail("内部错误")
	}

	// 打完分后要更新分数
	//对UserID进行判断，是否存在与用户表当中
	targetUserInfo, err := models.GetUserModel().GetUserInfo(TargetUserID)
	if err != nil {
		logs.Warn("GetUserInfo err : %v", err)
		return errs.NewAppFail("查询数据库错误")
	}
	if targetUserInfo == nil {
		logs.Warn("user_id = %d not exist", UserID)
		return errs.NewAppFail("用户不存在")
	}
	// score =（ score × 总被评价次数 × 5 + 当前评分）/  （（总被评价次数  + 1） × 5）
	oldScore := targetUserInfo.Score
	newScore := (targetUserInfo.Score*float64(targetUserInfo.MarkCount)*def.MarkFullScore + MarkScore) / ((float64(targetUserInfo.MarkCount) + 1.0) * def.MarkFullScore)
	targetUserInfo.Score = newScore
	targetUserInfo.MarkCount++

	err = models.GetUserModel().Update(targetUserInfo)
	if err != nil {
		logs.Warn("Update user info err : %v", err)
		return errs.NewAppFail("数据库错误")
	}
	logs.Info("用户(%d) 获得 用户(%d)的评价( %f 分),分数( %f -> %f)", TargetUserID, UserID, MarkScore, oldScore, newScore)
	return nil
}

// MarkBySystem 系统帮助用户打上默认分数  （该函数服务于UpdateUserScoreByAcitity函数，  所以比起Mark函数，很多参数不用校验（因为从库中读出来的），也不用更新mark表，只需要更新user表的信息）
func MarkBySystem(UserID, TargetUserID int, MarkScore float64) error {

	//取出targetUser信息
	targetUserInfo, err := models.GetUserModel().GetUserInfo(TargetUserID)
	if err != nil {
		logs.Warn("GetUserInfo err : %v", err)
		return errors.New("查询数据库错误")
	}
	if targetUserInfo == nil {
		logs.Warn("user_id = %d not exist", UserID)
		return errors.New("用户不存在")
	}
	// score =（ score × 总被评价次数 × 5 + 当前评分）/  （（总被评价次数  + 1） × 5）
	oldScore := targetUserInfo.Score
	newScore := (targetUserInfo.Score*float64(targetUserInfo.MarkCount)*def.MarkFullScore + MarkScore) / ((float64(targetUserInfo.MarkCount) + 1.0) * def.MarkFullScore)
	targetUserInfo.Score = newScore
	targetUserInfo.MarkCount++

	err = models.GetUserModel().Update(targetUserInfo)
	if err != nil {
		logs.Warn("Update user info err : %v", err)
		return errors.New("数据库错误")
	}
	logs.Info("用户(%d) 获得 用户(%d)的评价( %f 分),分数( %f -> %f)(超过评价时间，系统打分)", TargetUserID, UserID, MarkScore, oldScore, newScore)
	return nil
}

// UpdateUserScoreAfterAcitity 在一个活动结束、且评价时间段过后，把所有默认好评（未被打分的）加入到用户分数计算中     该函数由后台检查程序调用
func UpdateUserScoreAfterAcitity(ActivityID int) error {
	//time.Sleep(24 * time.Hour) //  24小时后

	// 取出该活动对应的所有评分关系条目中，未被用户主动打分的。   对每一个，调用service MarkBySystem
	defaultMarks, err := models.GetMarkModel().GetDefaultMarkInfoByActivityID(ActivityID)
	if err != nil {
		logs.Info("err : %v", err)
		return errors.New("内部错误")
	}
	if len(defaultMarks) == 0 {
		return nil
	}
	for _, v := range defaultMarks {
		err = MarkBySystem(v.UserID, v.TargetUserID, def.MarkFullScore)
		if err != nil {
			logs.Warn("MarkBySystem err : %v", err)
		}
	}
	return nil
}

// ReCalculateUserScore  统计某用户在所有活动中收获的评分，计算出分数,更新user表的分数    该函数写了不一定用，后续可能在审计分数的时候会用   （万一分数统计出来和现在user表里算的不一样，那mark count怎么处理？
func ReCalculateUserScore(UserID int) error {
	score, markNum, err := models.GetMarkModel().CalculateUserScore(UserID)
	fmt.Printf("socre: %f (user : %d)", score, UserID)
	if err != nil {
		logs.Warn("CalculateUserScore err : %v", err)
	}

	//取出User信息
	UserInfo, err := models.GetUserModel().GetUserInfo(UserID)
	if err != nil {
		logs.Warn("GetUserInfo err : %v", err)
		return errors.New("查询数据库错误")
	}
	if UserInfo == nil {
		logs.Warn("user_id = %d not exist", UserID)
		return errors.New("用户不存在")
	}
	UserInfo.Score = score
	UserInfo.MarkCount = markNum

	err = models.GetUserModel().Update(UserInfo)
	if err != nil {
		logs.Warn("Update user info err : %v", err)
		return errors.New("数据库错误")
	}
	logs.Info("经系统审计，用户(%d) 分数为 %f  被评价次数为：%d", UserID, score, markNum)
	return nil
}
