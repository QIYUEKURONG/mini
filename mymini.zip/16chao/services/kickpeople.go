package services

import (
	"16chao/def"
	"16chao/models"
	"16chao/util/errs"
	"fmt"

	"github.com/astaxie/beego/logs"
)

// KickPeopleService  define
type KickPeopleService struct {
}

//NewKickPeopleService ..
func NewKickPeopleService() *KickPeopleService {
	return &KickPeopleService{}
}

// KickPeople 队长踢人
func (s *KickPeopleService) KickPeople(UserCaptainID, UserPlayerID, ActivityID int) *errs.AppFail {
	//根据activity_id查询活动信息表对应的记录
	activityInfo, err := models.GetActivityModel().GetActivityByID(ActivityID)
	if activityInfo == nil {
		fmt.Printf("err : %v", err)
		return errs.NewAppFail("该活动不存在")
	}
	if err != nil {
		fmt.Printf("err : %v", err)
		return errs.NewAppFail("内部错误")
	}

	//根据活动信息表ID查看当前人数是否合法
	if activityInfo.CurrentMember < 1 {
		logs.Info("currentmember is ininvalid (activityid %d)", ActivityID)
		return errs.NewAppFail("当前人数不合法")
	}
	//根据活动信息表ID查看当前活动状态是否合法
	if (activityInfo.Status != def.StatIsCalling) && (activityInfo.Status != def.StatCallFinished) && (activityInfo.Status != def.Statbein) {
		logs.Info("currentstatus is illegal (activityid %d)", ActivityID)
		return errs.NewAppFail("当前活动状态不允许此操作")
	}

	//根据usercaptainID，activity_id查询活动成员表对应的记录
	activitycaptainInfo, err := models.GetActivityMemberListModel().GetActivityMemberInfo(UserCaptainID, ActivityID)
	if err != nil {
		fmt.Printf("err : %v", err)
		return errs.NewAppFail("内部错误")
	}
	//根据userplayerID，activity_id查询活动成员表对应的记录
	activityplayerInfo, err := models.GetActivityMemberListModel().GetActivityMemberInfo(UserPlayerID, ActivityID)
	if err != nil {
		fmt.Printf("err : %v", err)
		return errs.NewAppFail("内部错误")
	}
	//确认是队长踢队员
	if (activitycaptainInfo.IsCaptain != 1) || (activityplayerInfo.IsCaptain != 0) {
		logs.Info("the information of captain or player is incorrect (activityid:%d captainid:%d playerid:%d)", ActivityID, UserCaptainID, UserPlayerID)
		return errs.NewAppFail("只有队长才有此权限")
	}
	//根据活动信息表ID更新当前人数信息
	err = models.GetActivityModel().UpdateCurrentMemberByActivityID(ActivityID, activityInfo.CurrentMember-1)
	if err != nil {
		fmt.Printf("err : %v", err)
		return errs.NewAppFail("内部错误")
	}
	//根据活动成员表ID删除该记录
	err = models.GetActivityMemberListModel().Delete(activityplayerInfo.ActivityMemberListID)
	if err != nil {
		fmt.Printf("err : %v", err)
		//如果删除记录失败，则根据活动信息表ID把当前人数信息恢复
		err = models.GetActivityModel().UpdateCurrentMemberByActivityID(ActivityID, activityInfo.CurrentMember)
		if err != nil {
			//如果根据活动信息表ID把当前人数信息恢复失败，则生成错误日志
			logs.Info("currentmember is incorrect (activityid %d)", ActivityID)
		}
		return errs.NewAppFail("内部错误")
	}

	return nil
}
