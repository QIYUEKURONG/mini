package services

import (
	"16chao/def"
	"16chao/models"
	"16chao/util/errs"
	"fmt"
	//"time"
)

//MyActivitiesService  define
type MyActivitiesService struct {
}

//MyActivitiesGetResp 正在进行的活动返回的参数
type MyActivitiesGetResp struct {
	ActivityID          int    `json:"activity_id"`
	ActivityName        string `json:"activity_name"`
	ActivityStatus      int    `json:"activity_status"`
	ActivityMaxMember   int    `json:"activity_max_member"`
	ActivityCurMember   int    `json:"activity_current_member"`
	ActivityImage       string `json:"image"`
	ActivityCaptainName string `json:"activity_captain_name"`
	ActivityStartTime   string `json:"activity_start_time"`
	ActivityLocation    string `json:"activity_location_name"`
}

//NewMyActivitiesService ...
func NewMyActivitiesService() *MyActivitiesService {
	return &MyActivitiesService{}
}

//GetMyActivities 返回我的活动列表
func (*MyActivitiesService) GetMyActivities(uid int) ([]MyActivitiesGetResp, *errs.AppError) {
	//aids里存着该用户的所有活动ID
	aids, err := models.GetActivityMemberListModel().GetActivtityByUserID(uid)
	if err != nil {
		return nil, errs.NewErrCode(def.ErrMsg[def.EInternalErr], def.EInternalErr)
	}
	// //测试开始
	// fmt.Println("---------------用户所有的活动ID---------------------")
	// for i := 0; i < len(aids); i++ {
	// 	fmt.Println(aids[i])
	// }
	// fmt.Println("---------------用户所有的活动ID---------------------")
	// //测试结束
	//通过活动IDs aids 去返回需要的信息到ret里
	ret := make([]MyActivitiesGetResp, 0)
	for i := 0; i < len(aids); i++ {
		amodel, err := models.GetActivityModel().GetActivityByID(aids[i])
		if err != nil {
			return ret, errs.NewErrCode(def.ErrMsg[def.EInternalErr], def.EInternalErr)
		}
		temp := MyActivitiesGetResp{
			ActivityID:          amodel.ID,
			ActivityName:        amodel.Name,
			ActivityStatus:      amodel.Status,
			ActivityMaxMember:   amodel.MaxMember,
			ActivityCurMember:   amodel.CurrentMember,
			ActivityImage:       amodel.Image,
			ActivityCaptainName: "",
			ActivityStartTime:   amodel.StartTime.Format(def.TimeStampFmt),
			ActivityLocation:    amodel.LocationName,
		}
		//通过活动id在ActivityMemberList里查找该活动的队长id
		cid, err1 := models.GetActivityMemberListModel().GetCaptainIDByActivityID(amodel.ID)
		if err1 != nil {
			return ret, errs.NewErrCode(def.ErrMsg[def.EInternalErr], def.EInternalErr)
		}
		//再通过队长id查找队长姓名
		cname, err2 := models.GetUserModel().GetUserNameByID(cid)
		if err2 != nil {
			return ret, errs.NewErrCode(def.ErrMsg[def.EInternalErr], def.EInternalErr)
		}
		//添加队长姓名
		temp.ActivityCaptainName = cname

		ret = append(ret, temp)
	}
	//测试开始
	fmt.Println("---------------用户所有的活动返回信息---------------------")
	for i := 0; i < len(ret); i++ {
		fmt.Println(ret[i])
	}
	fmt.Println("---------------用户所有的活动返回信息---------------------")
	//测试结束
	return ret, nil
}
