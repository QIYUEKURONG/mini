package services

import (
	"16chao/util"
	"fmt"

	//"16chao/def"
	"16chao/models"
	"16chao/util/errs"
	"math"
	"strconv"

	"github.com/astaxie/beego/logs"
)

var (
	maxQueryResult = 15
)

// MaybeInterestedService  define
type MaybeInterestedService struct {
}

//NewMaybeInterestedService ..
func NewMaybeInterestedService() *MaybeInterestedService {
	return &MaybeInterestedService{}
}

//ScanActivityResp ..
type ScanActivityResp struct {
	List []*models.ActivityModel `json:"list"`
}

// ScanActivityRespL 查看集结列表返回结构
// type ScanActivityRespL struct {
// 	    List []*models.ScanActivityResp `json:"activities"`
// 	    status int `json:"status"` //活动ID
// 	    message int `json:"message"` //活动ID
// 	}

// MaybeInterestedResult 感兴趣列表返回结构  	Name   string `json:"user_name"`
type MaybeInterestedResult struct {
	ActivityID           int    `json:"activity_id"`            //活动ID
	Name                 string `json:"activity_name"`          //活动名称
	ActivityMaxCount     int    `json:"activity_max_count"`     //活动最大人数
	ActivityCurrentCount int    `json:"activity_current_count"` //活动当前人数
	ActivityMinCount     int    `json:"activity_min_count"`     //活动最少人数
	Image                string `json:"activity_image"`         //活动图片
	StartTime            string `json:"activity_start_time"`    //活动开始时间
	EndTime              string `json:"activity_end_time"`      //活动结束时间
	LocationName         string `json:"activity_location_name"` //活动中心点的名称
	Distance             string `json:"distance"`               //活动地点离自己的距离
}

//ConvertDistance 转换距离
func ConvertDistance(d float64) string {
	var s string
	distanceTemp := util.Decimal(d)
	if util.GetDecimalNumber(distanceTemp) == 0 {
		disToString := strconv.FormatFloat(distanceTemp, 'g', -1, 64)
		s = disToString + "m"
	} else {
		disToString := strconv.FormatFloat(distanceTemp, 'g', -1, 64)
		s = disToString + "km"
	}
	return s
}

//GetActivitiesWithoutCondition 没有筛选条件时，按照距离返回size个活动信息
func GetActivitiesWithoutCondition(userID, size int, Longitude, Latitude float64) ([]MaybeInterestedResult, *errs.AppFail) {

	var ret []MaybeInterestedResult
	var actInstance []float64
	// 查询用户已经参加的活动
	beInActivities, err := models.GetActivityMemberListModel().GetActivityMemberListByUserID(userID)
	if err != nil {
		logs.Warn("GetActivitysByUserID err")
		return nil, errs.NewAppFail("内部错误")
	}

	// 读数据库，取出所有活动 (已参加的除外)
	setLimit := ""
	if size > 0 {
		setLimit = " limit " + strconv.Itoa(size)
	}
	getActivities, err := models.GetActivityModel().GetActivitysByCondition(beInActivities, setLimit)
	if err != nil {
		logs.Warn("GetActivitysByUserID err")
		return nil, errs.NewAppFail("内部错误")
	}

	//计算距离
	for _, v := range getActivities {
		//	logs.Info("计算距离 Latitude, Longitude: %f,%f", Latitude, Longitude)
		p1, errP1 := util.NewPosition(Latitude, Longitude)
		//	logs.Info("v.LocationLatitude, v.LocationLongitude: %f,%f", v.LocationLatitude, v.LocationLongitude)
		p2, errP2 := util.NewPosition(v.LocationLatitude, v.LocationLongitude)
		if errP1 != nil {
			fmt.Printf("errP1 : %v", errP1)
			return nil, errs.NewAppFail("Value out of range")
		}
		if errP2 != nil {
			fmt.Printf("errP2 : %v", err)
			return nil, errs.NewAppFail("Value out of range")
		}
		distanceTmp := util.EarthDistance(p1, p2)
		actInstance = append(actInstance, distanceTmp)
	}

	// 根据距离排序
	sortedAcs, distances := SearchAndOrderByInstance(getActivities, actInstance, math.MaxFloat64, "", "")

	// 构造返回结果
	for i, v := range sortedAcs {
		tmp := MaybeInterestedResult{
			ActivityID:           v.ID,
			Name:                 v.Name,
			ActivityMaxCount:     v.MaxMember,
			ActivityCurrentCount: v.CurrentMember,
			ActivityMinCount:     v.MinMember,
			Image:                v.Image,
			StartTime:            v.StartTime.Format("2006-01-02 15:04:05"),
			EndTime:              v.EndTime.Format("2006-01-02 15:04:05"),
			LocationName:         v.LocationName,
			Distance:             ConvertDistance(distances[i]),
		}
		ret = append(ret, tmp)
	}
	return ret, nil
}

// MaybeInterested 可能感兴趣的活动
func (s *MaybeInterestedService) MaybeInterested(userID int, Longitude, Latitude float64) ([]MaybeInterestedResult, *errs.AppFail) {

	getNum := maxQueryResult

	labelIDs, err := models.GetMyInterestModel().GetLabelIDsByUserID(userID)
	if err != nil {
		logs.Warn("Service MaybeInterested :GetLabelIDsByUserID, err:%v", err)
		return nil, errs.NewAppFail("内部错误")
	}
	var ret []MaybeInterestedResult
	if len(labelIDs) > 0 {
		//存在感兴趣label，那么获取相应label的活动

		// 查询用户已经参加的活动
		beInActivities, err := models.GetActivityMemberListModel().GetActivityMemberListByUserID(userID)
		if err != nil {
			logs.Warn("GetActivityMemberListModel err")
			return nil, errs.NewAppFail("内部错误")
		}

		acsInLabels, err := models.GetActivityModel().GetActivityByLabelIDs(labelIDs, maxQueryResult, beInActivities)
		if err != nil {
			logs.Warn("MaybeInterested :GetActivityByLabelIDs, err:%v", err)
			return nil, errs.NewAppFail("内部错误")
		}
		if len(acsInLabels) > 0 {
			// 获取到了相应label的活动
			for _, v := range acsInLabels {
				//	logs.Info("Latitude, Longitude: %f,%f", Latitude, Longitude)
				p1, errP1 := util.NewPosition(Latitude, Longitude)
				//		logs.Info("v.LocationLatitude, v.LocationLongitude: %f,%f", v.LocationLatitude, v.LocationLongitude)
				p2, errP2 := util.NewPosition(v.LocationLatitude, v.LocationLongitude)
				if errP1 != nil {
					fmt.Printf("errP1 : %v", errP1)
					return nil, errs.NewAppFail("Value out of range")
				}
				if errP2 != nil {
					fmt.Printf("errP2 : %v", err)
					return nil, errs.NewAppFail("Value out of range")
				}
				distanceTmp := util.EarthDistance(p1, p2)
				tmp := MaybeInterestedResult{
					ActivityID:           v.ID,
					Name:                 v.Name,
					ActivityMaxCount:     v.MaxMember,
					ActivityCurrentCount: v.CurrentMember,
					ActivityMinCount:     v.MinMember,
					Image:                v.Image,
					StartTime:            v.StartTime.Format("2006-01-02 15:04:05"),
					EndTime:              v.EndTime.Format("2006-01-02 15:04:05"),
					LocationName:         v.LocationName,
					Distance:             ConvertDistance(distanceTmp),
				}
				ret = append(ret, tmp)
			}
			getNum = maxQueryResult - len(acsInLabels)
		}

	}
	//没有感兴趣标签，或者根据用户的兴趣标签没有查到任何一个活动， 则按照距离选一些
	ret2, aEr := GetActivitiesWithoutCondition(userID, getNum, Longitude, Latitude)
	if aEr != nil {
		logs.Warn("Service GetActivitiesWithoutCondition, err:%v", aEr)
		return nil, aEr
	}
	// ret2可能会包含ret1的内容，去重。
	for _, v1 := range ret2 {
		flag := 0
		for _, v2 := range ret {
			if v2.ActivityID == v1.ActivityID {
				flag = 1
				break
			}
		}
		if flag == 0 {
			ret = append(ret, v1)
		}
		flag = 0
	}

	//	ret = append(ret, ret2...)
	return ret, nil
}
