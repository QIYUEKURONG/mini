package services

import (
	"16chao/def"
	"16chao/models"
	"16chao/util/errs"
	"fmt"

	"github.com/astaxie/beego/logs"
)

// QuitActivityService  define
type QuitActivityService struct {
}

//NewQuitActivityService ..
func NewQuitActivityService() *QuitActivityService {
	return &QuitActivityService{}
}

// QuitActivity 用户退出活动
func (s *QuitActivityService) QuitActivity(UserID, ActivityID int) *errs.AppFail {
	//根据activity_id查询活动信息表对应的记录
	activityInfo, err := models.GetActivityModel().GetActivityByID(ActivityID)
	if activityInfo == nil {
		fmt.Printf("err : %v", err)
		return errs.NewAppFail("该活动不存在")
	}
	if err != nil {
		fmt.Printf("err : %v", err)
		return errs.NewAppFail("内部错误")
	}
	//根据活动信息表ID查看当前人数是否合法
	if activityInfo.CurrentMember < 1 {
		logs.Info("currentmember is ininvalid (activityid %d)", ActivityID)
		return errs.NewAppFail("当前人数不合法")
	}
	//根据活动信息表ID查看当前活动状态是否合法
	if (activityInfo.Status != def.StatIsCalling) && (activityInfo.Status != def.StatCallFinished) && (activityInfo.Status != def.Statbein) {
		logs.Info("currentstatus is illegal (activityid %d)", ActivityID)
		return errs.NewAppFail("当前活动状态不合法")
	}
	//根据活动信息表ID更新当前人数信息
	err = models.GetActivityModel().UpdateCurrentMemberByActivityID(ActivityID, activityInfo.CurrentMember-1)
	if err != nil {
		fmt.Printf("err : %v", err)
		return errs.NewAppFail("内部错误")
	}

	//根据user_id，activity_id查询活动成员表对应的记录
	activitymemberInfo, err := models.GetActivityMemberListModel().GetActivityMemberInfo(UserID, ActivityID)
	if err != nil {
		fmt.Printf("err : %v", err)
		//如果查询记录失败，则根据活动信息表ID把当前人数信息恢复
		err = models.GetActivityModel().UpdateCurrentMemberByActivityID(ActivityID, activityInfo.CurrentMember)
		if err != nil {
			//如果根据活动信息表ID把当前人数信息恢复失败，则生成错误日志
			logs.Info("currentmember is incorrect (activityid %d)", ActivityID)
		}
		return errs.NewAppFail("内部错误")
	}
	//根据活动成员表ID删除该记录
	err = models.GetActivityMemberListModel().Delete(activitymemberInfo.ActivityMemberListID)
	if err != nil {
		fmt.Printf("err : %v", err)
		//如果删除记录失败，则根据活动信息表ID把当前人数信息恢复
		err = models.GetActivityModel().UpdateCurrentMemberByActivityID(ActivityID, activityInfo.CurrentMember)
		if err != nil {
			//如果根据活动信息表ID把当前人数信息恢复失败，则生成错误日志
			logs.Info("currentmember is incorrect (activityid %d)", ActivityID)
		}
		return errs.NewAppFail("内部错误")
	}

	return nil
}
