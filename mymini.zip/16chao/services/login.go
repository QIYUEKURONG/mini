package services

import (
	"16chao/def"
	"16chao/models"
	"16chao/util/errs"
	"fmt"
)

// LoginService  define
type LoginService struct {
}

//NewLoginService ..
func NewLoginService() *LoginService {
	return &LoginService{}
}

// Login 根据OpenID获取用户id
func (p *LoginService) Login(OpenID string) (int, *errs.AppError) {

	uid, errcheck := models.GetUserModel().CheckOpenID(OpenID)
	if errcheck != nil {
		fmt.Printf("the OpenID does not exist : %v", errcheck)
		return -1, errs.NewErrCode(def.ErrMsg[def.EInternalErr], def.EInternalErr)
	}
	return uid, nil
}
