package test

import (
	"16chao/models"
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/astaxie/beego"
	. "github.com/smartystreets/goconvey/convey"
)

// type GetRegisterResult struct {
// 	Status  int                    `json:"status"`
// 	Message  string                 `json:"message"`
// 	UserID `json:"user_id"`
// }

func TestControllerMaybeInterested(t *testing.T) {
	ClearTable(models.GetMyInterestModel().TableName())
	ClearTable(models.GetActivityModel().TableName())
	defer func() {
		ClearTable(models.GetMyInterestModel().TableName())
		ClearTable(models.GetActivityModel().TableName())
	}()

	user1 := 1563885687
	label1 := 1111
	label2 := 1112
	//	longitude := float64(100.2)
	//	latitude := float64(200.3)

	// 插入用户感兴趣的标签
	record := &models.MyInterestModel{
		MyInterestID: 11,
		UserID:       user1,
		LabelID:      label1,
	}
	models.GetMyInterestModel().InsertOne(record)
	record.MyInterestID = 12
	record.LabelID = label2
	models.GetMyInterestModel().InsertOne(record)

	// 插入一些活动信息
	actInfo := &models.ActivityModel{
		ID:                1110,
		Name:              "明晚6点麻将",
		Description:       "求组队",
		Image:             "https://ossweb-img.qq.com/images/lol/web201310/skin/big81007.jpg",
		Status:            0,
		LocationLongitude: 45.12,
		LocationLatitude:  46.48,
		LocationName:      "软件园",
		MinMember:         4,
		MaxMember:         5,
		CurrentMember:     2,
		StartTime:         time.Now(),
		EndTime:           time.Now(),
		LabelID:           label1,
	}
	err := models.GetActivityModel().InsertOne(actInfo)
	changeContent(actInfo, 1111, 102.5, 98.25)
	actInfo.LabelID = label2
	err = models.GetActivityModel().InsertOne(actInfo)
	changeContent(actInfo, 1112, 32, 62.8)
	actInfo.LabelID = 1114
	err = models.GetActivityModel().InsertOne(actInfo)

	param := map[string]interface{}{
		"user_id":                user1,
		"user_current_latitude":  50.1,
		"user_current_longitude": 45.3,
	}
	postData, _ := json.Marshal(param)
	t.Logf("json\n%s", postData)
	r, _ := http.NewRequest("POST", "/v1/InterestActivity", bytes.NewBuffer(postData))
	w := httptest.NewRecorder()
	beego.BeeApp.Handlers.ServeHTTP(w, r)

	t.Logf("Code[%d]\n%s", w.Code, w.Body.String())
	Convey("Subject: Test withrawzanct Endpoint\n", t, func() {
		Convey("Status Code Should Be 200", func() {
			So(w.Code, ShouldEqual, 200)
			So(err, ShouldEqual, nil)
		})

		Convey("TestUserRegister check Result", func() {
			var rspBody = w.Body.Bytes()

			var resp map[string]interface{}
			json.Unmarshal(rspBody, &resp)

			Convey("check user_id:", func() {
				So(resp["user_id"], ShouldEqual, 0)
			})
		})
	})
}
