package test

import (
	"16chao/models"
	"16chao/util"
	"fmt"
	"testing"
	//	. "github.com/smartystreets/goconvey/convey"
)

func ClearTable(tableName string) {
	db, _ := models.GetDB()
	trunc := fmt.Sprintf("truncate table %s", tableName)
	_, err := db.Exec(trunc)
	if err != nil {
		panic(err)
	}

	fmt.Println(trunc)
}

func TestGetDistance(t *testing.T) {
	la1 := 34.254849
	lon1 := 108.944775
	la2 := 34.246014
	lon2 := 108.955658
	distance, _ := util.GetFormatEarthDistance(la1, lon1, la2, lon2)
	fmt.Println(distance)
}
