package test

import (
	"16chao/models"
	"testing"

	. "github.com/smartystreets/goconvey/convey"
)

// type GetRegisterResult struct {
// 	Status  int                    `json:"status"`
// 	Message  string                 `json:"message"`
// 	UserID `json:"user_id"`
// }

func TestRandomUser(t *testing.T) {
	// ClearTable(models.GetUserModel().TableName())
	//activeTime, _ := time.ParseInLocation("2006-01-02 15:04:05", "2019-01-02 10:00:00", time.Local)
	// defer func() {
	// 	ClearTable(models.GetUserModel().TableName())
	// }()

	record1 := &models.UserModel{
		ID:     10,
		Name:   "szq1",
		Avatar: "apple",
		Gender: 2,
		Region: "wuhan",
	}
	record2 := &models.UserModel{
		ID:     20,
		Name:   "szq2",
		Avatar: "apple",
		Gender: 2,
		Region: "wuhan",
	}
	err := models.GetUserModel().InsertOne(record1)
	Convey("TestUserRegister check Result", t, func() {
		So(err, ShouldEqual, nil)
	})
	err = models.GetUserModel().InsertOne(record2)
	Convey("TestUserRegister check Result", t, func() {
		So(err, ShouldEqual, nil)
	})
	UserModel, err := models.GetUserModel().GetUserInfo(record1.ID)
	Convey("TestUserRegister check Result", t, func() {
		So(err, ShouldEqual, nil)
		So(UserModel.ID, ShouldEqual, record1.ID)
	})
	err = models.GetUserModel().DeleteUser(record1.ID)
	Convey("TestUserRegister check Result", t, func() {
		So(err, ShouldEqual, nil)
	})
	tem := make(map[string]interface{}, 1)
	tem["user_region"] = "xian"
	err = models.GetUserModel().UpdateByUserID(record2.ID, tem)
	Convey("TestUserRegister check Result", t, func() {
		So(err, ShouldEqual, nil)
	})
}
