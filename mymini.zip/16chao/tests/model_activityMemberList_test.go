package test

import (
	"16chao/models"
	"fmt"
	"testing"

	. "github.com/smartystreets/goconvey/convey"
)

func TestActivityMemberListInsert(t *testing.T) {
	// ClearTable(models.GetUserModel().TableName())
	// defer func() {
	// 	ClearTable(models.GetUserModel().TableName())
	// }()

	record := &models.LabelModel{
		LabelID:      121,
		LabelName:    "篮球",
		LabelPicture: "/src.jpg",
	}
	err := models.GetLabelModel().InsertOne(record)
	Convey("TestLabelInsert  check result", t, func() {
		So(err, ShouldEqual, nil)
	})
}

func TestGetActivityMemberListByUserID(t *testing.T) {

	arra, err := models.GetActivityMemberListModel().GetActivityMemberListByUserID(1563886110)

	for _, arr := range arra {
		//fmt.Println(arra[arr].ActivityID)
		fmt.Println(arr)
	}

	Convey("TestLabelInsert  check result", t, func() {
		So(err, ShouldEqual, nil)
	})
}

func TestGetActivityMemberListByUserID2(t *testing.T) {

	userID := 3333
	record := &models.ActivityMemberListModel{
		ActivityMemberListID: 1,
		ActivityID:           2,
		UserID:               userID,
		IsCaptain:            1,
	}
	err := models.GetActivityMemberListModel().InsertOne(record)

	arra, err := models.GetActivityMemberListModel().GetActivityMemberListByUserID(userID)
	Convey("TestLabelInsert  check result", t, func() {
		So(err, ShouldEqual, nil)
		So(len(arra), ShouldEqual, 1)
	})
}
