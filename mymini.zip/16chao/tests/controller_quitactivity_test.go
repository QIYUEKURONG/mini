package test

import (
	"16chao/def"
	"16chao/models"
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/astaxie/beego"
	. "github.com/smartystreets/goconvey/convey"
)

// type GetRegisterResult struct {
// 	Status  int                    `json:"status"`
// 	Message  string                 `json:"message"`
// 	UserID `json:"user_id"`
// }
//退出活动单元测试
func TestQuitActivity(t *testing.T) {
	ClearTable(models.GetActivityMemberListModel().TableName())
	ClearTable(models.GetActivityModel().TableName())
	//activeTime, _ := time.ParseInLocation("2006-01-02 15:04:05", "2019-01-02 10:00:00", time.Local)
	defer func() {
		ClearTable(models.GetActivityMemberListModel().TableName())
		ClearTable(models.GetActivityModel().TableName())
	}()
	//插入活动成员表数据、活动信息表数据
	activityID := int(9)                  //活动ID
	var uid1, uid2, uid3 int = 10, 11, 12 //成员ID
	AMrecord1 := &models.ActivityMemberListModel{
		ActivityMemberListID: 50,
		ActivityID:           activityID,
		UserID:               uid1,
		IsCaptain:            1, //用来判断该活动成员是否为队长  1 是 0 不是
	}
	AMrecord2 := &models.ActivityMemberListModel{
		ActivityMemberListID: 60,
		ActivityID:           activityID,
		UserID:               uid2,
		IsCaptain:            0, //用来判断该活动成员是否为队长  1 是 0 不是
	}
	AMrecord3 := &models.ActivityMemberListModel{
		ActivityMemberListID: 70,
		ActivityID:           activityID,
		UserID:               uid3,
		IsCaptain:            0, //用来判断该活动成员是否为队长  1 是 0 不是
	}
	Stime := "2019-07-22 15:00:00"
	Etime := "2019-07-22 18:00:00"
	s, _ := time.ParseInLocation(def.TimeStampFmt, Stime, time.Local)
	e, _ := time.ParseInLocation(def.TimeStampFmt, Etime, time.Local)

	Arecord1 := &models.ActivityModel{
		ID:                activityID,
		Name:              "健身",
		Description:       "一起去健身",
		Image:             "/src.jpg",
		Status:            def.StatIsCalling,
		LocationLongitude: 108.55,
		LocationLatitude:  33.90,
		LocationName:      "环普产业园体育场",
		MinMember:         3,
		MaxMember:         5,
		CurrentMember:     3,
		StartTime:         s,
		EndTime:           e,
		LabelID:           1,
	}
	//确认插入活动成员表数据、活动信息表数据是否成功
	err := models.GetActivityMemberListModel().InsertOne(AMrecord1)
	Convey("check the insert of AMrecord1:", t, func() {
		So(err, ShouldEqual, nil)
	})
	err = models.GetActivityMemberListModel().InsertOne(AMrecord2)
	Convey("check the insert of AMrecord2:", t, func() {
		So(err, ShouldEqual, nil)
	})
	err = models.GetActivityMemberListModel().InsertOne(AMrecord3)
	Convey("check the insert of AMrecord3:", t, func() {
		So(err, ShouldEqual, nil)
	})
	err = models.GetActivityModel().InsertOne(Arecord1)
	Convey("check the insert of Arecord1:", t, func() {
		So(err, ShouldEqual, nil)
	})
	//测试前端数据正确时后台是否返回正确结果
	param1 := map[string]interface{}{
		"user_id":     uid2,
		"activity_id": activityID,
	}

	postData1, _ := json.Marshal(param1)
	t.Logf("json\n%s", postData1)
	r1, _ := http.NewRequest("POST", "/v1/QuitActivity", bytes.NewBuffer(postData1))
	w1 := httptest.NewRecorder()
	beego.BeeApp.Handlers.ServeHTTP(w1, r1)

	t.Logf("Code[%d]\n%s", w1.Code, w1.Body.String())
	Convey("Subject: Test withrawzanct Endpoint\n", t, func() {
		Convey("Status Code Should Be 200", func() {
			So(w1.Code, ShouldEqual, 200)
		})
		Convey("TestQuitActivity check Result", func() {
			var rspBody1 = w1.Body.Bytes()

			var resp1 map[string]interface{}
			json.Unmarshal(rspBody1, &resp1)

			Convey("check respstatus:", func() {
				So(resp1["status"], ShouldEqual, "true")
			})
			Convey("check respmessage:", func() {
				So(resp1["message"], ShouldEqual, "退出活动成功")
			})
		})

	})
	//测试前端数据值错误时后台是否返回错误结果
	param2 := map[string]interface{}{
		"user_id":     -2, //值错误
		"activity_id": -3, //值错误
	}

	postData2, _ := json.Marshal(param2)
	t.Logf("json\n%s", postData2)
	r2, _ := http.NewRequest("POST", "/v1/QuitActivity", bytes.NewBuffer(postData2))
	w2 := httptest.NewRecorder()
	beego.BeeApp.Handlers.ServeHTTP(w2, r2)

	t.Logf("Code[%d]\n%s", w2.Code, w2.Body.String())
	Convey("Subject: Test withrawzanct Endpoint\n", t, func() {
		Convey("Status Code Should Be 200", func() {
			So(w2.Code, ShouldEqual, 200)
		})
		Convey("TestQuitActivity check Result", func() {
			var rspBody2 = w2.Body.Bytes()

			var resp2 map[string]interface{}
			json.Unmarshal(rspBody2, &resp2)

			Convey("check respstatus:", func() {
				So(resp2["status"], ShouldEqual, "false")
			})
			Convey("check respmessage:", func() {
				So(resp2["message"], ShouldEqual, "该活动不存在")
			})
		})

	})

}
