package test

import (
	"16chao/models"
	"testing"

	. "github.com/smartystreets/goconvey/convey"
)

//测试插入一条记录：InsertOne（ZHB）
func TestLabelCategoryInsert(t *testing.T) {
	ClearTable(models.GetLabelCategoryModel().TableName())
	defer func() {
		ClearTable(models.GetLabelCategoryModel().TableName())
	}()

	record := &models.LabelCategoryModel{
		LabelCategoryName:    "体育",
		LabelCategoryPicture: "/sports",
	}
	err := models.GetLabelCategoryModel().InsertOne(record)
	Convey("TestLabelCategoryInsert  check result", t, func() {
		So(err, ShouldEqual, nil)
	})
}

//测试通过LabelCategoryID获取LabelCategoryModel：GetLabelCategoryByID（ZHB）
func TestGetLabelCategoryByID(t *testing.T) {
	ClearTable(models.GetLabelCategoryModel().TableName())
	defer func() {
		ClearTable(models.GetLabelCategoryModel().TableName())
	}()

	//创建一条记录用来测试
	labelCategoryID := 1
	LabelCategoryName := "体育"
	LabelCategoryPicture := "/sports"
	record := &models.LabelCategoryModel{
		LabelCategoryID:      labelCategoryID,
		LabelCategoryName:    LabelCategoryName,
		LabelCategoryPicture: LabelCategoryPicture,
	}
	//将记录插入活动大类表当中
	err := models.GetLabelCategoryModel().InsertOne(record)
	Convey("TestGetLabelCategoryByID  InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})

	//通过label_id查询，判断查询结果与输入是否一致
	ret, err := models.GetLabelCategoryModel().GetLabelCategoryByID(labelCategoryID)
	t.Log(ret)
	Convey("TestGetLabelCategoryByID  check result", t, func() {
		So(err, ShouldEqual, nil)
		So(ret.LabelCategoryID, ShouldEqual, labelCategoryID)
		So(ret.LabelCategoryName, ShouldEqual, LabelCategoryName)
		So(ret.LabelCategoryPicture, ShouldEqual, LabelCategoryPicture)
	})
}

//测试获取整个活动大类表：GetAllLabelCategory
func TestGetAllLabelCategory(t *testing.T) {
	ClearTable(models.GetLabelCategoryModel().TableName())
	defer func() {
		ClearTable(models.GetLabelCategoryModel().TableName())
	}()

	//创建记录用来测试
	record1 := &models.LabelCategoryModel{
		LabelCategoryName:    "体育",
		LabelCategoryPicture: "/sports",
	}
	record2 := &models.LabelCategoryModel{
		LabelCategoryName:    "游戏",
		LabelCategoryPicture: "/games",
	}
	err := models.GetLabelCategoryModel().InsertOne(record1)
	Convey("TestGetAllLabelCategory  InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})
	err = models.GetLabelCategoryModel().InsertOne(record2)
	Convey("TestGetAllLabelCategory  InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})

	//获取整个活动大类表
	ret, err := models.GetLabelCategoryModel().GetAllLabelCategory()
	t.Log(ret)
	Convey("TestGetAllLabelCategory  check result", t, func() {
		So(err, ShouldEqual, nil)
	})
}
