package test

import (
	"16chao/models"
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/astaxie/beego"
	. "github.com/smartystreets/goconvey/convey"
)

// type GetRegisterResult struct {
// 	Status  int                    `json:"status"`
// 	Message  string                 `json:"message"`
// 	UserID `json:"user_id"`
// }

func TestUserRegister(t *testing.T) {
	ClearTable(models.GetUserModel().TableName())
	//activeTime, _ := time.ParseInLocation("2006-01-02 15:04:05", "2019-01-02 10:00:00", time.Local)
	defer func() {
		ClearTable(models.GetUserModel().TableName())
	}()

	param := map[string]interface{}{
		"user_name":   "cxh",
		"user_region": "xian",
		"user_avatar": "headImage",
		"user_gender": 0,
	}
	postData, _ := json.Marshal(param)
	t.Logf("json\n%s", postData)
	r, _ := http.NewRequest("POST", "/v1/register", bytes.NewBuffer(postData))
	//r, _ := http.NewRequest("POST", "/v1/register", bytes.NewBuffer(postData))
	w := httptest.NewRecorder()
	beego.BeeApp.Handlers.ServeHTTP(w, r)

	t.Logf("Code[%d]\n%s", w.Code, w.Body.String())
	Convey("Subject: Test withrawzanct Endpoint\n", t, func() {
		Convey("Status Code Should Be 200", func() {
			So(w.Code, ShouldEqual, 200)
		})

		Convey("TestUserRegister check Result", func() {
			var rspBody = w.Body.Bytes()

			var resp map[string]interface{}
			json.Unmarshal(rspBody, &resp)

			Convey("check user_id:", func() {
				So(resp["user_id"], ShouldEqual, 0)
			})
		})
	})
}
