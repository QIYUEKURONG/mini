package test

import (
	"16chao/models"
	"fmt"
	"testing"

	. "github.com/smartystreets/goconvey/convey"
)

func TestUserInsert(t *testing.T) {

	//	ClearTable(models.GetUserModel().TableName())
	/*defer func() {
		ClearTable(models.GetUserModel().TableName())
	}()*/

	record := &models.UserModel{
		ID:     1234,
		Name:   "ccc",
		Avatar: "Avatar",
		Gender: 0,
		Region: "Region",
	}
	err := models.GetUserModel().InsertOne(record)

	Convey("TestUserInsert  check result", t, func() {
		So(err, ShouldNotEqual, nil)
	})
}

func TestUserGetUserInfo(t *testing.T) {
	ClearTable(models.GetUserModel().TableName())
	defer func() {
		ClearTable(models.GetUserModel().TableName())
	}()
	userID := 123456
	record := &models.UserModel{
		ID:     userID,
		Name:   "ccc",
		Avatar: "Avatar",
		Gender: 0,
		Region: "Region",
	}
	err := models.GetUserModel().InsertOne(record)
	Convey("TestUserInsert  InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})

	ret, err := models.GetUserModel().GetUserInfo(userID)
	Convey("TestUserInsert  check result", t, func() {
		So(err, ShouldEqual, nil)
		So(ret.ID, ShouldEqual, userID)
	})
}

func TestDeleteUser(t *testing.T) {
	ClearTable(models.GetUserModel().TableName())
	defer func() {
		//ClearTable(models.GetUserModel().TableName())
	}()
	userID := 123456
	record := &models.UserModel{
		ID:     userID,
		Name:   "ccc",
		Avatar: "Avatar",
		Gender: 0,
		Region: "Region",
	}
	err := models.GetUserModel().InsertOne(record)
	record.ID = 100
	err = models.GetUserModel().InsertOne(record)
	Convey("TestUserInsert  InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})

	err = models.GetUserModel().DeleteUser(userID)
	Convey("TestUserInsert  check result", t, func() {
		So(err, ShouldEqual, nil)
	})
}

//TestGetUserNameByID ...
func TestGetUserNameByID(t *testing.T) {
	// ClearTable(models.GetUserModel().TableName())
	// defer func() {
	// 	ClearTable(models.GetUserModel().TableName())
	// }()
	userName, err := models.GetUserModel().GetUserNameByID(1563886110)
	Convey("TestGetUserNameByID  result", t, func() {
		fmt.Println(userName)
		Convey("err shoulde be nil", func() {
			So(err, ShouldEqual, nil)
		})
		Convey("TestGetUserNameByID  userName should be 范茗雨", func() {
			So(userName, ShouldEqual, "范茗雨")
		})
	})

}
