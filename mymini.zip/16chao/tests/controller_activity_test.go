package test

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/astaxie/beego"
	. "github.com/smartystreets/goconvey/convey"
)

func TestActivityPublish(t *testing.T) {
	//ClearTable(models.GetActivityModel().TableName())
	//ClearTable(models.GetActivityMemberListModel().TableName())
	/*defer func() {
		ClearTable(models.GetUserModel().TableName())
	}()*/
	// begin, _ := time.ParseInLocation("2006-01-02 15:04:05", "2019-07-22 18:00:00", time.Local)
	// end, _ := time.ParseInLocation("2006-01-02 15:04:05", "2019-07-22 22:00:00", time.Local)
	param := map[string]interface{}{
		"user_id":             614,
		"activity_name":       "带图",
		"label_name":          "逛街",
		"start_time":          "2019-07-29 18:00:00",
		"end_time":            "2019-07-29 22:00:00",
		"max_member":          11,
		"min_member":          10,
		"location_longtitude": 7.4,
		"location_latitude":   33.4,
		"location_name":       "钟楼回民街",
		"description":         "小吃",
		"image":               "https://jijiehao.hnonething.com/default/sanbu.jpg",
	}
	postData, _ := json.Marshal(param)
	t.Logf("json\n%s", postData)
	r, _ := http.NewRequest("POST", "/v1/publish", bytes.NewBuffer(postData))
	w := httptest.NewRecorder()
	beego.BeeApp.Handlers.ServeHTTP(w, r)

	t.Logf("Code[%d]\n%s", w.Code, w.Body.String())
	Convey("Subject: Test withrawzanct Endpoint\n", t, func() {
		Convey("Status Code Should Be 200", func() {
			So(w.Code, ShouldEqual, 200)
		})

		Convey("TestActivityPublish check Result", func() {
			var rspBody = w.Body.Bytes()
			var resp map[string]interface{}
			json.Unmarshal(rspBody, &resp)
			//fmt.Println(resp)
			Convey("check message:", func() {
				So(resp["message"], ShouldEqual, "发出集结成功")
			})
		})
	})
}

func TestScanActivity(t *testing.T) {
	param := map[string]interface{}{
		"user_id":           1564383695,
		"gather_type":       ",篮球,,,,,", //运动类型
		"gather_start_time": "2019-07-29 16:09:01",
		"gather_end_time":   "2020-07-28 16:09:01",
		"gather_latitude":   34.22259,  //默认设定为用户的实时位置
		"gather_longitude":  108.94878, //默认设定为用户的实时位置
		"gather_radius":     -1,        //用户限制距离
		"sort_by_time":      "",
		"sort_by_dis":       "ASC",
	}
	postData, _ := json.Marshal(param)
	t.Logf("json\n%s", postData)
	r, _ := http.NewRequest("POST", "/v1/scanActivity", bytes.NewBuffer(postData))
	w := httptest.NewRecorder()
	beego.BeeApp.Handlers.ServeHTTP(w, r)

	t.Logf("Code[%d]\n%s", w.Code, w.Body.String())
	Convey("Subject: Test withrawzanct Endpoint\n", t, func() {
		Convey("Status Code Should Be 200", func() {
			So(w.Code, ShouldEqual, 200)
		})

		Convey("TestActivityscanActivity check Result", func() {
			var rspBody = w.Body.Bytes()

			var resp map[string]interface{}
			json.Unmarshal(rspBody, &resp)
			fmt.Println(resp)
			Convey("check user_id:", func() {
				So(resp["user_id"], ShouldEqual, 0)
			})
		})
	})

}
