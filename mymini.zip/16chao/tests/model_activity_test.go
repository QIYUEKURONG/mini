package test

import (
	"16chao/models"
	"16chao/services"
	_ "bytes"
	_ "encoding/json"
	"fmt"
	_ "net/http"
	_ "net/http/httptest"
	"strconv"
	"testing"
	_ "testing"
	"time"

	. "github.com/smartystreets/goconvey/convey"
)

// type GetRegisterResult struct {
// 	Status  int                    `json:"status"`
// 	Message  string                 `json:"message"`
// 	UserID `json:"user_id"`
// }

func TestDeleteActivity(t *testing.T) {
	//ClearTable(models.GetUserModel().TableName())
	//activeTime, _ := time.ParseInLocation("2006-01-02 15:04:05", "2019-01-02 10:00:00", time.Local)
	defer func() {
		ClearTable(models.GetUserModel().TableName())
	}()

	record := &models.ActivityModel{
		ID:   123456,
		Name: "ccc",

		Description:       "这是一个很好的活动", //活动描述
		Image:             "/src",      //活动图片
		Status:            1,           //活动状态
		LocationLongitude: 1.0,         //活动地点经度
		LocationLatitude:  2.0,         //活动地点纬度
		LocationName:      "月球表面",      //活动中心点的名称
		MinMember:         3,           //活动最少人数
		MaxMember:         6,           //活动最大人数
		CurrentMember:     2,           //活动当前人数
		StartTime:         time.Now(),  //活动开始时间
		EndTime:           time.Now(),  //活动结束时间
		LabelID:           1001,        //活动类型

	}
	err := models.GetActivityModel().DeleteActivity(record.ID)
	Convey("TestUserInsert  check result", t, func() {
		So(err, ShouldEqual, nil)
	})
}

func TestUpdateActivityByID(t *testing.T) {
	//ClearTable(models.GetUserModel().TableName())
	//activeTime, _ := time.ParseInLocation("2006-01-02 15:04:05", "2019-01-02 10:00:00", time.Local)
	defer func() {
		ClearTable(models.GetUserModel().TableName())
	}()

	// record := &models.ActivityModel{
	// 	ID:   123456,
	// 	Name: "ccc",

	// 	Description:       "这是一个很好的活动",           //活动描述
	// 	Image:             "/src",                //活动图片
	// 	Status:            0,                     //活动状态
	// 	LocationLongitude: 1.0,                   //活动地点经度
	// 	LocationLatitude:  2.0,                   //活动地点纬度
	// 	LocationName:      "月球表面",                //活动中心点的名称
	// 	MinMember:         3,                     //活动最少人数
	// 	MaxMember:         6,                     //活动最大人数
	// 	CurrentMember:     2,                     //活动当前人数
	// 	StartTime:         "2016-12-23 10:00:00", //活动开始时间
	// 	EndTime:           "2016-12-23 10:00:00", //活动结束时间
	// 	LabelID:           1001,                  //活动类型

	// }
	//err := models.GetActivityModel().UpdateActivityByID(record)
	// Convey("TestUserInsert  check result", t, func() {
	// 	So(err, ShouldEqual, nil)
	// })
}

func TestActivityInsert(t *testing.T) {
	//ClearTable(models.GetActivityModel().TableName())
	//activeTime, _ := time.ParseInLocation("2006-01-02 15:04:05", "2019-01-02 10:00:00", time.Local)
	record12 := &models.ActivityModel{
		//	ID:                1101,
		Name:              "明晚6点麻将3Q1",
		Description:       "有两个妹子哦~ 谁输了谁出台费~ 拒绝黄赌毒！",
		Image:             "图片库",
		Status:            0,
		LocationLongitude: 45.12,
		LocationLatitude:  46.48,
		LocationName:      "天朗蓝湖树",
		MinMember:         4,
		MaxMember:         5,
		CurrentMember:     2,
		StartTime:         time.Now(),
		EndTime:           time.Now(),
		LabelID:           5,
	}
	err := models.GetActivityModel().InsertOne(record12)
	fmt.Println("-----------------------")
	fmt.Println("record12.ID", record12.ID)
	fmt.Println("-----------------------")
	Convey("TestActivityInsert check result", t, func() {
		So(err, ShouldNotEqual, nil)
	})
}

func TestUpdateStateByActivityID(t *testing.T) {
	//ClearTable(models.GetUserModel().TableName())
	//activeTime, _ := time.ParseInLocation("2006-01-02 15:04:05", "2019-01-02 10:00:00", time.Local)
	// defer func() {
	// 	ClearTable(models.GetUserModel().TableName())
	// }()

	err := models.GetActivityModel().UpdateStateByActivityID(122, 0)
	Convey("TestUpdateStateByActivityID  check result", t, func() {
		So(err, ShouldEqual, nil)
	})
}

func TestGetActivityByID(t *testing.T) {
	//ClearTable(models.GetUserModel().TableName())
	//activeTime, _ := time.ParseInLocation("2006-01-02 15:04:05", "2019-01-02 10:00:00", time.Local)
	// defer func() {
	// 	ClearTable(models.GetUserModel().TableName())
	// }()

	ac, err := models.GetActivityModel().GetActivityByID(1109)
	fmt.Println(ac.LocationName)
	Convey("TestUpdateStateByActivityID  check result", t, func() {
		So(err, ShouldNotEqual, nil)
	})
}

// func TestGetActivitysByUserID(t *testing.T) {
// 	list, _ := services.NewActivityService().ScanActivity(1201)

// 	for _, arr := range list {
// 		fmt.Println(arr.ID)
// 	}

// 	//ClearTable(models.GetUserModel().TableName())
// 	//activeTime, _ := time.ParseInLocation("2006-01-02 15:04:05", "2019-01-02 10:00:00", time.Local)
// 	// defer func() {
// 	// 	ClearTable(models.GetUserModel().TableName())
// 	// }()

// 	// ac := models.GetActivityModel().GetActivitysByUserID(1201)

// 	// for _, acs := range ac {
// 	// 	fmt.Println(acs)
// 	// }

// 	// Convey("TestUpdateStateByActivityID  check result", t, func() {
// 	// 	So(err, ShouldEqual, nil)
// 	// })
// }
//func TestGetActivitysByUserID(t *testing.T) {
// list, _ := services.NewActivityService().ScanActivity(1201)

// for _, arr := range list {
// 	fmt.Println(arr.ID)
// }

//ClearTable(models.GetUserModel().TableName())
//activeTime, _ := time.ParseInLocation("2006-01-02 15:04:05", "2019-01-02 10:00:00", time.Local)
// defer func() {
// 	ClearTable(models.GetUserModel().TableName())
// }()

// ac := models.GetActivityModel().GetActivitysByUserID(1201)

// for _, acs := range ac {
// 	fmt.Println(acs)
// }

// Convey("TestUpdateStateByActivityID  check result", t, func() {
// 	So(err, ShouldEqual, nil)
// })
//}
func TestGetActivitysByUserID(t *testing.T) {

	list, distance, _ := services.NewActivityService().ScanActivity(926, "", "", "", 34.254849, 108.944775, 10, "", "")

	for index, arr := range list {
		fmt.Println("打印出的ID" + strconv.Itoa(arr.ID))
		float32s2 := strconv.FormatFloat(distance[index], 'E', -1, 64) //float64
		fmt.Println("打印出的距离" + float32s2)
	}
	// arra, _ := models.GetActivityMemberListModel().GetActivityMemberListByUserID(1201)
	// condition := "limit 2"
	// activityModels, _ := models.GetActivityModel().GetActivitysByCondition(arra, condition)

	// for index, arr := range activityModels {
	// 	fmt.Println(index + arr.ID)
	// }
}

func TestGetActivitysByCondition(t *testing.T) {
	ClearTable(models.GetActivityModel().TableName())
	defer ClearTable(models.GetActivityModel().TableName())
	//activeTime, _ := time.ParseInLocation("2006-01-02 15:04:05", "2019-01-02 10:00:00", time.Local)
	record := &models.ActivityModel{
		ID:                1109,
		Name:              "明晚6点麻将3Q1",
		Description:       "有两个妹子哦~ 谁输了谁出台费~ 拒绝黄赌毒！",
		Image:             "图片库",
		Status:            0,
		LocationLongitude: 45.12,
		LocationLatitude:  46.48,
		LocationName:      "天朗蓝湖树",
		MinMember:         4,
		MaxMember:         5,
		CurrentMember:     2,
		StartTime:         time.Now(),
		EndTime:           time.Now(),
		LabelID:           5,
	}
	err := models.GetActivityModel().InsertOne(record)
	record.ID = 1110
	err = models.GetActivityModel().InsertOne(record)
	record.ID = 1111
	err = models.GetActivityModel().InsertOne(record)

	list := make([]*models.ActivityMemberListModel, 2)
	list[0] = &models.ActivityMemberListModel{
		ActivityMemberListID: 11,
		ActivityID:           1109,
		UserID:               777,
		IsCaptain:            0,
	}
	list[1] = &models.ActivityMemberListModel{
		ActivityMemberListID: 11,
		ActivityID:           1110,
		UserID:               777,
		IsCaptain:            0,
	}
	ret, err := models.GetActivityModel().GetActivitysByCondition(list, "limit 4")

	Convey("TestActivityInsert check result", t, func() {
		So(err, ShouldEqual, nil)
		So(len(ret), ShouldEqual, 1)
	})
}

func TestGetActivityByLabelIDs(t *testing.T) {
	ClearTable(models.GetActivityModel().TableName())
	defer ClearTable(models.GetActivityModel().TableName())

	record := &models.ActivityModel{
		ID:                1109,
		Name:              "明晚6点麻将3Q1",
		Description:       "有两个妹子哦~ 谁输了谁出台费~ 拒绝黄赌毒！",
		Image:             "图片库",
		Status:            0,
		LocationLongitude: 45.12,
		LocationLatitude:  46.48,
		LocationName:      "天朗蓝湖树",
		MinMember:         4,
		MaxMember:         5,
		CurrentMember:     2,
		StartTime:         time.Now(),
		EndTime:           time.Now(),
		LabelID:           5,
	}
	err := models.GetActivityModel().InsertOne(record)
	record.ID = 1110
	record.LabelID = 6
	err = models.GetActivityModel().InsertOne(record)
	record.ID = 1111
	record.LabelID = 7
	err = models.GetActivityModel().InsertOne(record)
	record.ID = 1112
	record.LabelID = 9
	err = models.GetActivityModel().InsertOne(record)

	list := make([]*models.ActivityMemberListModel, 1)
	list[0] = &models.ActivityMemberListModel{
		ActivityMemberListID: 11,
		ActivityID:           1109,
		UserID:               777,
		IsCaptain:            0,
	}
	// list[1] = &models.ActivityMemberListModel{
	// 	ActivityMemberListID: 11,
	// 	ActivityID:           1112,
	// 	UserID:               777,
	// 	IsCaptain:            0,
	// }
	labelIDs := []int{7, 9}
	ret, err := models.GetActivityModel().GetActivityByLabelIDs(labelIDs, 1, list)

	Convey("TestActivityInsert check result", t, func() {
		So(err, ShouldEqual, nil)
		So(len(ret), ShouldEqual, 1)
	})
}
