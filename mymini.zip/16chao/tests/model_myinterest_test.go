package test

import (
	"16chao/models"
	"testing"

	. "github.com/smartystreets/goconvey/convey"
)

func TestInsertOne(t *testing.T) {
	ClearTable(models.GetMyInterestModel().TableName())
	defer func() {
		ClearTable(models.GetMyInterestModel().TableName())
	}()

	record := &models.MyInterestModel{
		UserID:  111,
		LabelID: 1111,
	}
	err := models.GetMyInterestModel().InsertOne(record)
	Convey("TestUserInsert  check result", t, func() {
		So(err, ShouldEqual, nil)
	})
}

func TestGetLabelIDsByUserID(t *testing.T) {
	ClearTable(models.GetMyInterestModel().TableName())
	defer func() {
		ClearTable(models.GetMyInterestModel().TableName())
	}()
	userID := 123456
	record := &models.MyInterestModel{
		UserID:  userID,
		LabelID: 1111,
	}
	err := models.GetMyInterestModel().InsertOne(record)
	Convey("1:TestUserInsert  InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})
	record.LabelID = 4556
	err = models.GetMyInterestModel().InsertOne(record)
	Convey("2:TestUserInsert  InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})

	ret, err := models.GetMyInterestModel().GetLabelIDsByUserID(userID)
	Convey("TestGetLabelIDsByUserID  check result", t, func() {
		So(err, ShouldEqual, nil)
		So(len(ret), ShouldEqual, 2)
	})
}

//测试根据user_id查询一组记录:GetMyInterestByUserID（ZHB）
func TestGetMyInterestByUserID(t *testing.T) {
	ClearTable(models.GetMyInterestModel().TableName())
	defer func() {
		ClearTable(models.GetMyInterestModel().TableName())
	}()

	//创建一条记录用来测试
	userID := 12345
	labelID := 999
	record := &models.MyInterestModel{
		UserID:  userID,
		LabelID: labelID,
	}
	//将记录插入兴趣表当中
	err := models.GetMyInterestModel().InsertOne(record)
	Convey("TestGetMyInterestByUserID  InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})

	//通过user_id查询，判断查询结果与输入是否一致
	ret, err := models.GetMyInterestModel().GetMyInterestByUserID(userID)
	t.Log(ret)
	Convey("TestGetLabelNameByLabelID  check result", t, func() {
		So(err, ShouldEqual, nil)
		//此处只有一条记录
		So(ret[0].UserID, ShouldEqual, userID)
		So(ret[0].LabelID, ShouldEqual, labelID)
	})
}

//测试根据user_id和label_id查询记录是否存在：SearchInfoByUserIDAndLabelID（ZHB）
func TestSearchInfoByUserIDAndLabelID(t *testing.T) {
	ClearTable(models.GetMyInterestModel().TableName())
	defer func() {
		ClearTable(models.GetMyInterestModel().TableName())
	}()

	//创建一条记录用来测试
	userID := 12345
	labelID := 999
	record := &models.MyInterestModel{
		UserID:  userID,
		LabelID: labelID,
	}
	//将记录插入兴趣表当中
	err := models.GetMyInterestModel().InsertOne(record)
	Convey("TestSearchInfoByUserIDAndLabelID  InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})

	//查询该记录
	exist, interest, err := models.GetMyInterestModel().SearchInfoByUserIDAndLabelID(userID, labelID)
	Convey("TestSearchInfoByUserIDAndLabelID  SearchInfoByUserIDAndLabelID result", t, func() {
		So(exist, ShouldEqual, true)
		So(err, ShouldEqual, nil)
		So(interest.UserID, ShouldEqual, userID)
		So(interest.LabelID, ShouldEqual, labelID)
	})
}

//测试根据user_id和label_id删除对应记录（ZHB）
func TestDeleteByUserIDAndLabelID(t *testing.T) {
	ClearTable(models.GetMyInterestModel().TableName())
	defer func() {
		ClearTable(models.GetMyInterestModel().TableName())
	}()

	//创建一条记录用来测试
	userID := 12345
	labelID := 999
	record := &models.MyInterestModel{
		UserID:  userID,
		LabelID: labelID,
	}
	//将记录插入兴趣表当中
	err := models.GetMyInterestModel().InsertOne(record)
	Convey("TestDeleteByUserIDAndLabelID  InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})

	//删除该记录
	err = models.GetMyInterestModel().DeleteByUserIDAndLabelID(userID, labelID)
	Convey("TestDeleteByUserIDAndLabelID  DeleteByUserIDAndLabelID result", t, func() {
		So(err, ShouldEqual, nil)
		//查询记录是否存在
		exist, _, searcherr := models.GetMyInterestModel().SearchInfoByUserIDAndLabelID(userID, labelID)
		So(searcherr, ShouldEqual, nil)
		So(exist, ShouldEqual, false)
	})
}

//测试根据user_id删除所有记录（ZHB）
func TestDeleteByUserID(t *testing.T) {
	ClearTable(models.GetMyInterestModel().TableName())
	defer func() {
		ClearTable(models.GetMyInterestModel().TableName())
	}()

	//创建记录用来测试
	userID := 12345
	record1 := &models.MyInterestModel{
		UserID:  userID,
		LabelID: 123,
	}
	record2 := &models.MyInterestModel{
		UserID:  userID,
		LabelID: 444,
	}
	record3 := &models.MyInterestModel{
		UserID:  userID,
		LabelID: 555,
	}

	//将记录插入兴趣表当中
	err := models.GetMyInterestModel().InsertOne(record1)
	Convey("TestDeleteByUserID  InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})
	err = models.GetMyInterestModel().InsertOne(record2)
	Convey("TestDeleteByUserID  InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})
	err = models.GetMyInterestModel().InsertOne(record3)
	Convey("TestDeleteByUserID  InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})

	//删除该用户的所有记录
	err = models.GetMyInterestModel().DeleteByUserID(userID)
	Convey("TestDeleteByUserID  DeleteByUserID result", t, func() {
		So(err, ShouldEqual, nil)
		//查询记录是否存在
		interest, err := models.GetMyInterestModel().GetMyInterestByUserID(userID)
		So(interest, ShouldResemble, []models.MyInterestModel{})
		So(err, ShouldEqual, nil)
	})
}
