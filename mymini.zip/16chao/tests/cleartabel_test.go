package test

import (
	"16chao/models"
	"testing"
)

// 清空数据库
func TestMysqlClearTable(t *testing.T) {
	ClearTable(models.GetUserModel().TableName())               //用户信息表
	ClearTable(models.GetActivityModel().TableName())           //活动信息表
	ClearTable(models.GetActivityMemberListModel().TableName()) //活动成员表
	ClearTable(models.GetMyInterestModel().TableName())         //我感兴趣的活动
}
