package test

import (
	"16chao/models"
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/astaxie/beego"
	. "github.com/smartystreets/goconvey/convey"
)

//为方便测试定义的结构体
type RetInterestStr struct {
	LabelID         int    `json:"label_id"`
	LabelName       string `json:"label_name"`
	LabelPicture    string `json:"label_picture"`
	LabelCategoryID int    `json:"label_category_id"`
	IsInterest      bool   `json:"is_interest"`
}

type RetCategoryStr struct {
	LabelCategoryID      int    `json:"label_category_id"`
	LabelCategoryName    string `json:"label_category_name"`
	LabelCategoryPicture string `json:"label_category_picture"`
}

type RetStr struct {
	Status        string           `json:"status"`
	Message       string           `json:"message"`
	LabelCategory []RetCategoryStr `json:"label_category"`
	MyInterest    []RetInterestStr `json:"my_interest"`
}

//测试查看订阅设置：Subscription
func TestSubscription(t *testing.T) {
	//查询会涉及四个表
	ClearTable(models.GetLabelCategoryModel().TableName())
	ClearTable(models.GetMyInterestModel().TableName())
	ClearTable(models.GetLabelModel().TableName())
	ClearTable(models.GetUserModel().TableName())
	defer func() {
		ClearTable(models.GetLabelCategoryModel().TableName())
		ClearTable(models.GetMyInterestModel().TableName())
		ClearTable(models.GetLabelModel().TableName())
		ClearTable(models.GetUserModel().TableName())
	}()

	//向数据库中插入测试数据
	//(1)向活动大类表中插入数据
	categoryrecord1 := &models.LabelCategoryModel{
		LabelCategoryID:      1,
		LabelCategoryName:    "体育",
		LabelCategoryPicture: "/sports",
	}
	categoryrecord2 := &models.LabelCategoryModel{
		LabelCategoryID:      2,
		LabelCategoryName:    "游戏",
		LabelCategoryPicture: "/games",
	}
	err := models.GetLabelCategoryModel().InsertOne(categoryrecord1)
	Convey("TestSubscription  GetLabelCategoryModel：InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})
	err = models.GetLabelCategoryModel().InsertOne(categoryrecord2)
	Convey("TestSubscription  GetLabelCategoryModel：InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})
	//(2)向活动类型表中插入数据
	record1 := &models.LabelModel{
		LabelID:         1,
		LabelName:       "足球",
		LabelPicture:    "/football.jpg",
		LabelCategoryID: 1,
	}
	record2 := &models.LabelModel{
		LabelID:         2,
		LabelName:       "篮球",
		LabelPicture:    "/basketball.jpg",
		LabelCategoryID: 1,
	}
	record3 := &models.LabelModel{
		LabelID:         3,
		LabelName:       "游泳",
		LabelPicture:    "/swimming.jpg",
		LabelCategoryID: 1,
	}
	record4 := &models.LabelModel{
		LabelID:         4,
		LabelName:       "王者荣耀",
		LabelPicture:    "/KingofGlory.jpg",
		LabelCategoryID: 2,
	}
	record5 := &models.LabelModel{
		LabelID:         5,
		LabelName:       "英雄联盟",
		LabelPicture:    "/lol.jpg",
		LabelCategoryID: 2,
	}
	err = models.GetLabelModel().InsertOne(record1)
	Convey("TestSubscription  GetLabelModel：InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})
	err = models.GetLabelModel().InsertOne(record2)
	Convey("TestSubscription  GetLabelModel：InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})
	err = models.GetLabelModel().InsertOne(record3)
	Convey("TestSubscription  GetLabelModel：InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})
	err = models.GetLabelModel().InsertOne(record4)
	Convey("TestSubscription  GetLabelModel：InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})
	err = models.GetLabelModel().InsertOne(record5)
	Convey("TestSubscription  GetLabelModel：InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})
	//(3)向兴趣表中插入数据
	interestrecord1 := &models.MyInterestModel{
		UserID:  111,
		LabelID: 1,
	}
	interestrecord2 := &models.MyInterestModel{
		UserID:  111,
		LabelID: 3,
	}
	interestrecord3 := &models.MyInterestModel{
		UserID:  111,
		LabelID: 5,
	}
	err = models.GetMyInterestModel().InsertOne(interestrecord1)
	Convey("TestSubscription  GetMyInterestModel：InsertOneInterest result", t, func() {
		So(err, ShouldEqual, nil)
	})
	err = models.GetMyInterestModel().InsertOne(interestrecord2)
	Convey("TestSubscription  GetMyInterestModel：InsertOneInterest result", t, func() {
		So(err, ShouldEqual, nil)
	})
	err = models.GetMyInterestModel().InsertOne(interestrecord3)
	Convey("TestSubscription  GetMyInterestModel：InsertOneInterest result", t, func() {
		So(err, ShouldEqual, nil)
	})
	//(4)向用户表中插入数据
	record := &models.UserModel{
		ID:     111,
		Name:   "ccc",
		Avatar: "Avatar",
		Gender: 0,
		Region: "Region",
	}
	err = models.GetUserModel().InsertOne(record)
	Convey("TestUserInsert  InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})

	//期望的测试结果
	expectret := RetStr{
		Status:  "true",
		Message: "数据返回成功",
		LabelCategory: []RetCategoryStr{
			RetCategoryStr{
				LabelCategoryID:      1,
				LabelCategoryName:    "体育",
				LabelCategoryPicture: "/sports",
			},
			RetCategoryStr{
				LabelCategoryID:      2,
				LabelCategoryName:    "游戏",
				LabelCategoryPicture: "/games",
			},
		},
		MyInterest: []RetInterestStr{
			RetInterestStr{
				LabelID:         1,
				LabelName:       "足球",
				LabelPicture:    "/football.jpg",
				LabelCategoryID: 1,
				IsInterest:      true,
			},
			RetInterestStr{
				LabelID:         2,
				LabelName:       "篮球",
				LabelPicture:    "/basketball.jpg",
				LabelCategoryID: 1,
				IsInterest:      false,
			},
			RetInterestStr{
				LabelID:         3,
				LabelName:       "游泳",
				LabelPicture:    "/swimming.jpg",
				LabelCategoryID: 1,
				IsInterest:      true,
			},
			RetInterestStr{
				LabelID:         4,
				LabelName:       "王者荣耀",
				LabelPicture:    "/KingofGlory.jpg",
				LabelCategoryID: 2,
				IsInterest:      false,
			},
			RetInterestStr{
				LabelID:         5,
				LabelName:       "英雄联盟",
				LabelPicture:    "/lol.jpg",
				LabelCategoryID: 2,
				IsInterest:      true,
			},
		},
	}

	//构建传入参数
	param := map[string]interface{}{
		"user_id": 111,
	}

	postData, _ := json.Marshal(param)
	t.Logf("json\n%s", postData)
	r, _ := http.NewRequest("POST", "/v1/Subscription", bytes.NewBuffer(postData))
	w := httptest.NewRecorder()
	beego.BeeApp.Handlers.ServeHTTP(w, r)

	t.Logf("Code[%d]\n%s", w.Code, w.Body.String())

	Convey("Subject: Test withrawzanct Endpoint\n", t, func() {
		//判断服务器返回状态
		Convey("Status Code Should Be 200", func() {
			So(w.Code, ShouldEqual, 200)
		})
		//判断返回结果
		Convey("TestSubscription check Result", func() {
			//取出结果
			var rspBody = w.Body.Bytes()
			t.Log(string(rspBody))
			//反序列化
			var resp RetStr
			json.Unmarshal(rspBody, &resp)

			t.Log(resp)
			//返回结果与期望结果做对比
			Convey("check status:", func() {
				So(resp, ShouldResemble, expectret)
			})
		})
	})

}

//测试提交订阅设置：SubscriptionSetting
func TestSubscriptionSetting(t *testing.T) {
	//查询会涉及四个表
	ClearTable(models.GetLabelCategoryModel().TableName())
	ClearTable(models.GetMyInterestModel().TableName())
	ClearTable(models.GetLabelModel().TableName())
	ClearTable(models.GetUserModel().TableName())
	defer func() {
		ClearTable(models.GetLabelCategoryModel().TableName())
		ClearTable(models.GetMyInterestModel().TableName())
		ClearTable(models.GetLabelModel().TableName())
		ClearTable(models.GetUserModel().TableName())
	}()

	//向数据库中插入测试数据
	//(1)向活动大类表中插入数据
	categoryrecord1 := &models.LabelCategoryModel{
		LabelCategoryID:      1,
		LabelCategoryName:    "体育",
		LabelCategoryPicture: "/sports",
	}
	categoryrecord2 := &models.LabelCategoryModel{
		LabelCategoryID:      2,
		LabelCategoryName:    "游戏",
		LabelCategoryPicture: "/games",
	}
	err := models.GetLabelCategoryModel().InsertOne(categoryrecord1)
	Convey("TestSubscription  GetLabelCategoryModel：InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})
	err = models.GetLabelCategoryModel().InsertOne(categoryrecord2)
	Convey("TestSubscription  GetLabelCategoryModel：InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})
	//(2)向活动类型表中插入数据
	record1 := &models.LabelModel{
		LabelID:         1,
		LabelName:       "足球",
		LabelPicture:    "/football.jpg",
		LabelCategoryID: 1,
	}
	record2 := &models.LabelModel{
		LabelID:         2,
		LabelName:       "篮球",
		LabelPicture:    "/basketball.jpg",
		LabelCategoryID: 1,
	}
	record3 := &models.LabelModel{
		LabelID:         3,
		LabelName:       "游泳",
		LabelPicture:    "/swimming.jpg",
		LabelCategoryID: 1,
	}
	record4 := &models.LabelModel{
		LabelID:         4,
		LabelName:       "王者荣耀",
		LabelPicture:    "/KingofGlory.jpg",
		LabelCategoryID: 2,
	}
	record5 := &models.LabelModel{
		LabelID:         5,
		LabelName:       "英雄联盟",
		LabelPicture:    "/lol.jpg",
		LabelCategoryID: 2,
	}
	err = models.GetLabelModel().InsertOne(record1)
	Convey("TestSubscription  GetLabelModel：InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})
	err = models.GetLabelModel().InsertOne(record2)
	Convey("TestSubscription  GetLabelModel：InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})
	err = models.GetLabelModel().InsertOne(record3)
	Convey("TestSubscription  GetLabelModel：InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})
	err = models.GetLabelModel().InsertOne(record4)
	Convey("TestSubscription  GetLabelModel：InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})
	err = models.GetLabelModel().InsertOne(record5)
	Convey("TestSubscription  GetLabelModel：InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})
	//(3)向兴趣表中插入数据
	interestrecord1 := &models.MyInterestModel{
		UserID:  111,
		LabelID: 1,
	}
	interestrecord2 := &models.MyInterestModel{
		UserID:  111,
		LabelID: 3,
	}
	interestrecord3 := &models.MyInterestModel{
		UserID:  111,
		LabelID: 5,
	}
	err = models.GetMyInterestModel().InsertOne(interestrecord1)
	Convey("TestSubscription  GetMyInterestModel：InsertOneInterest result", t, func() {
		So(err, ShouldEqual, nil)
	})
	err = models.GetMyInterestModel().InsertOne(interestrecord2)
	Convey("TestSubscription  GetMyInterestModel：InsertOneInterest result", t, func() {
		So(err, ShouldEqual, nil)
	})
	err = models.GetMyInterestModel().InsertOne(interestrecord3)
	Convey("TestSubscription  GetMyInterestModel：InsertOneInterest result", t, func() {
		So(err, ShouldEqual, nil)
	})
	//(4)向用户表中插入数据
	record := &models.UserModel{
		ID:     111,
		Name:   "ccc",
		Avatar: "Avatar",
		Gender: 0,
		Region: "Region",
	}
	err = models.GetUserModel().InsertOne(record)
	Convey("TestUserInsert  InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})

	//构建传入参数
	interest1 := map[string]interface{}{
		"label_id":    1,
		"is_interest": false,
	}
	interest2 := map[string]interface{}{
		"label_id":    2,
		"is_interest": true,
	}
	interest3 := map[string]interface{}{
		"label_id":    3,
		"is_interest": false,
	}
	interest4 := map[string]interface{}{
		"label_id":    4,
		"is_interest": true,
	}
	interest5 := map[string]interface{}{
		"label_id":    5,
		"is_interest": false,
	}

	param := map[string]interface{}{
		"user_id": 111,
		"subscription_set": []map[string]interface{}{
			interest1,
			interest2,
			interest3,
			interest4,
			interest5,
		},
	}

	postData, _ := json.Marshal(param)
	t.Logf("json\n%s", postData)

	r, _ := http.NewRequest("POST", "/v1/SubscriptionSetting", bytes.NewBuffer(postData))
	w := httptest.NewRecorder()
	beego.BeeApp.Handlers.ServeHTTP(w, r)

	t.Logf("Code[%d]\n%s", w.Code, w.Body.String())

	Convey("Subject: Test withrawzanct Endpoint\n", t, func() {
		//判断服务器返回状态
		Convey("Status Code Should Be 200", func() {
			So(w.Code, ShouldEqual, 200)
		})
		//判断返回结果
		Convey("TestSubscriptionSetting check Result", func() {
			//取出结果
			var rspBody = w.Body.Bytes()
			t.Log(string(rspBody))
			//反序列化
			var resp map[string]interface{}
			json.Unmarshal(rspBody, &resp)

			t.Log(resp)

			Convey("check status:", func() {
				So(resp["status"], ShouldEqual, "true")
			})

			//查询订阅设置
			myInterest, err := models.GetMyInterestModel().GetLabelIDsByUserID(111)
			Convey("TestSubscriptionSetting  GetLabelIDsByUserID result", func() {
				So(err, ShouldEqual, nil)
				//应该只有两个记录
				So(len(myInterest), ShouldEqual, 2)
				t.Log(myInterest)
				So(myInterest, ShouldContain, 2)
				So(myInterest, ShouldContain, 4)
			})
		})
	})
}
