package test

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/astaxie/beego"
	. "github.com/smartystreets/goconvey/convey"
)

func TestBeIn(t *testing.T) {
	//单纯的查询工作，不涉及任何更新表的操作
	//前端给的信息只有user_id
	param := map[string]interface{}{
		"user_id": 1563886110,
	}
	postData, _ := json.Marshal(param)
	t.Logf("json\n%s", postData)
	r, _ := http.NewRequest("POST", "/v1/isParticipateAcitivity", bytes.NewBuffer(postData))
	w := httptest.NewRecorder()
	beego.BeeApp.Handlers.ServeHTTP(w, r)

	t.Logf("Code[%d]\n%s", w.Code, w.Body.String())
	Convey("Subject: Test withrawzanct Endpoint\n", t, func() {
		Convey("Status Code Should Be 200", func() {
			So(w.Code, ShouldEqual, 200)
		})

		Convey("Bein check Result", func() {
			var rspBody = w.Body.Bytes()

			var resp map[string]interface{}
			json.Unmarshal(rspBody, &resp)
			Convey("check activity_id:", func() {
				fmt.Println(resp)
				So(resp["message"], ShouldNotEqual, "数据返回成功")
			})
		})
	})
}

func TestBeInInsert(t *testing.T) {
	param := map[string]interface{}{
		"user_id":     614,
		"activity_id": 5,
	}
	postData, _ := json.Marshal(param)
	t.Logf("json\n%s", postData)
	r, _ := http.NewRequest("POST", "/v1/SignUp", bytes.NewBuffer(postData))
	w := httptest.NewRecorder()
	beego.BeeApp.Handlers.ServeHTTP(w, r)

	t.Logf("Code[%d]\n%s", w.Code, w.Body.String())
	Convey("Subject: Test withrawzanct Endpoint\n", t, func() {
		Convey("Status Code Should Be 200", func() {
			So(w.Code, ShouldEqual, 200)
		})
		Convey("Bein check Result", func() {
			var rspBody = w.Body.Bytes()

			var resp map[string]interface{}
			json.Unmarshal(rspBody, &resp)
			Convey("check activity_id:", func() {
				fmt.Println(resp)
				So(resp["message"], ShouldEqual, "数据返回成功")
			})
		})
	})
}
