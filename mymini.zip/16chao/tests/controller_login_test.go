package test

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/astaxie/beego"
	. "github.com/smartystreets/goconvey/convey"
)

func TestLogin(t *testing.T) {
	param := map[string]interface{}{
		"code": "021Lbr701tYbAY1RcU50112D701Lbr7O",
	}
	postData, _ := json.Marshal(param)
	t.Logf("json\n%s", postData)
	r, _ := http.NewRequest("POST", "/v1/login", bytes.NewBuffer(postData))
	w := httptest.NewRecorder()
	beego.BeeApp.Handlers.ServeHTTP(w, r)

	t.Logf("Code[%d]\n%s", w.Code, w.Body.String())
	Convey("Subject: Test withrawzanct Endpoint\n", t, func() {
		Convey("Status Code Should Be 200", func() {
			So(w.Code, ShouldEqual, 200)
		})

		Convey("Login check Result", func() {
			var rspBody = w.Body.Bytes()
			var resp map[string]interface{}
			json.Unmarshal(rspBody, &resp)
			Convey("check activity_id:", func() {
				fmt.Println(resp)
				So(resp["UserID"], ShouldEqual, -1)
			})
		})
	})
}
