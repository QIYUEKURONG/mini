package test

import (
	"16chao/models"
	_ "bytes"
	_ "encoding/json"
	"fmt"
	_ "net/http"
	_ "net/http/httptest"
	"testing"
	_ "testing"

	. "github.com/smartystreets/goconvey/convey"
)

func TestGetActivityMemberListByActivityID(t *testing.T) {
	// ClearTable(models.GetActivityMemberListModel().TableName())
	// defer func() {
	// 	ClearTable(models.GetActivityMemberListModel().TableName())
	// }()
	//测试通过
	ret, err := models.GetActivityMemberListModel().GetActivityMemberListByActivityID(1109)
	for _, value := range ret {
		ump, _ := models.GetUserModel().GetUserInfo(value.UserID)
		fmt.Println(value.UserID)
		fmt.Println(value.IsCaptain)
		fmt.Println(ump.Avatar)
	}
	Convey("TestGetActivityMemberListByActivityID  Selectall result", t, func() {
		So(err, ShouldNotEqual, nil)
	})

}
func TestGetCaptainIDByActivityID(t *testing.T) {
	// ClearTable(models.GetActivityMemberListModel().TableName())
	// defer func() {
	// 	ClearTable(models.GetActivityMemberListModel().TableName())
	// }()
	//测试通过
	ret, err := models.GetActivityMemberListModel().GetCaptainIDByActivityID(1110)
	fmt.Println(ret)
	Convey("TestGetCaptainIDByActivityID", t, func() {
		Convey("err shoulde be nil", func() {
			So(err, ShouldEqual, nil)
		})
		Convey("ret should be 1563886110", func() {
			So(ret, ShouldEqual, 1563886110)
		})
	})

}
