package test

import (
	"16chao/models"
	"fmt"
	"testing"

	. "github.com/smartystreets/goconvey/convey"
)

func TestLabelInsert(t *testing.T) {
	//ClearTable(models.GetLabelModel().TableName())
	/*defer func() {
		ClearTable(models.GetLabelModel().TableName())
	}()*/

	record := &models.LabelModel{
		LabelID:      21,
		LabelName:    "慢跑",
		LabelPicture: "https://ossweb-img.qq.com/images/lol/web201310/skin/big81007.jpg",
	}
	err := models.GetLabelModel().InsertOne(record)
	Convey("TestLabelInsert  check result", t, func() {
		So(err, ShouldEqual, nil)
	})
}

func TestGetLabelIdByName(t *testing.T) {
	//ClearTable(models.GetUserModel().TableName())
	// defer func() {
	// 	ClearTable(models.GetUserModel().TableName())
	// }()
	labelID, err := models.GetLabelModel().GetLabelIDByName("狼人杀")
	fmt.Println(labelID)
	//如果断言成功，就什么不打印，所以这里如何想直观的看到结果，就要设定断言失败
	Convey("TestGetLabelIdByName  check result", t, func() {
		So(err, ShouldNotEqual, nil)
	})
}

func TestGetLabelByID(t *testing.T) {
	//ClearTable(models.GetUserModel().TableName())
	// defer func() {
	// 	ClearTable(models.GetUserModel().TableName())
	// }()

	LabelModel, err := models.GetLabelModel().GetLabelByID(122)
	fmt.Println(LabelModel.LabelName)
	//如果断言成功，就什么不打印，所以这里如何想直观的看到结果，就要设定断言失败
	Convey("TestGetLabelIdByName  check result", t, func() {
		So(err, ShouldNotEqual, nil)
	})
}

//测试根据label_id查询label_name:GetLabelNameByLabelID（ZHB）
func TestGetLabelNameByLabelID(t *testing.T) {
	ClearTable(models.GetLabelModel().TableName())
	defer func() {
		ClearTable(models.GetLabelModel().TableName())
	}()
	//创建一条记录用来测试
	labelID := 222
	labelName := "足球"
	record := &models.LabelModel{
		LabelID:         labelID,
		LabelName:       labelName,
		LabelPicture:    "/football.jpg",
		LabelCategoryID: 1,
	}
	//将记录插入活动类型表当中
	err := models.GetLabelModel().InsertOne(record)
	Convey("TestGetLabelNameByLabelID  InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})

	//通过label_id查询，判断查询结果与输入是否一致
	ret, err := models.GetLabelModel().GetLabelNameByLabelID(labelID)
	t.Log(ret)
	Convey("TestGetLabelNameByLabelID  check result", t, func() {
		So(err, ShouldEqual, nil)
		So(ret, ShouldEqual, labelName)
	})

}

//测试获取整个活动类型表：GetAllLabel
func TestGetAllLabel(t *testing.T) {
	ClearTable(models.GetLabelModel().TableName())
	defer func() {
		ClearTable(models.GetLabelModel().TableName())
	}()

	//创建记录用来测试
	record1 := &models.LabelModel{
		LabelID:         1,
		LabelName:       "足球",
		LabelPicture:    "/football.jpg",
		LabelCategoryID: 1,
	}
	record2 := &models.LabelModel{
		LabelID:         2,
		LabelName:       "篮球",
		LabelPicture:    "/basketball.jpg",
		LabelCategoryID: 1,
	}
	record3 := &models.LabelModel{
		LabelID:         3,
		LabelName:       "游泳",
		LabelPicture:    "/swimming.jpg",
		LabelCategoryID: 1,
	}
	err := models.GetLabelModel().InsertOne(record1)
	Convey("TestSubscription  InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})
	err = models.GetLabelModel().InsertOne(record2)
	Convey("TestSubscription  InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})
	err = models.GetLabelModel().InsertOne(record3)
	Convey("TestSubscription  InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})

	//获取整个类型表
	ret, err := models.GetLabelModel().GetAllLabel()
	t.Log(ret)
	Convey("TestGetAllLabel  check result", t, func() {
		So(err, ShouldEqual, nil)
	})
}

//测试获取活动类型数量 ：GetLabelNum
func TestGetLabelNum(t *testing.T) {
	ClearTable(models.GetLabelModel().TableName())
	defer func() {
		ClearTable(models.GetLabelModel().TableName())
	}()

	//创建记录用来测试
	record1 := &models.LabelModel{
		LabelID:         1,
		LabelName:       "足球",
		LabelPicture:    "/football.jpg",
		LabelCategoryID: 1,
	}
	record2 := &models.LabelModel{
		LabelID:         2,
		LabelName:       "篮球",
		LabelPicture:    "/basketball.jpg",
		LabelCategoryID: 1,
	}
	record3 := &models.LabelModel{
		LabelID:         3,
		LabelName:       "游泳",
		LabelPicture:    "/swimming.jpg",
		LabelCategoryID: 1,
	}
	err := models.GetLabelModel().InsertOne(record1)
	Convey("TestSubscription  InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})
	err = models.GetLabelModel().InsertOne(record2)
	Convey("TestSubscription  InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})
	err = models.GetLabelModel().InsertOne(record3)
	Convey("TestSubscription  InsertOne result", t, func() {
		So(err, ShouldEqual, nil)
	})

	//获取活动类型数量
	ret, err := models.GetLabelModel().GetLabelNum()
	t.Log(ret)
	Convey("TestGetAllLabel  check result", t, func() {
		So(err, ShouldEqual, nil)
		So(ret, ShouldEqual, 3)
	})
}
