package test

import (
	"16chao/models"
	"16chao/services"
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"time"

	// "16chao/services"
	// "16chao/models"
	"testing"

	"github.com/astaxie/beego"
	. "github.com/smartystreets/goconvey/convey"
)

// func changeContent(m *models.ActivityModel, id int, longitude, latitude float64) {
// 	m.ID = id
// 	m.LocationLongitude = longitude
// 	m.LocationLatitude = latitude
// }
func TestMaybeInterested(t *testing.T) {
	ClearTable(models.GetMyInterestModel().TableName())
	ClearTable(models.GetActivityModel().TableName())
	defer func() {
		ClearTable(models.GetMyInterestModel().TableName())
		ClearTable(models.GetActivityModel().TableName())
	}()

	user1 := 111
	label1 := 1111
	label2 := 1112
	longitude := float64(100.2)
	latitude := float64(200.3)

	// 插入用户感兴趣的标签
	record := &models.MyInterestModel{
		MyInterestID: 11,
		UserID:       user1,
		LabelID:      label1,
	}
	err := models.GetMyInterestModel().InsertOne(record)
	record.MyInterestID = 12
	record.LabelID = label2
	err = models.GetMyInterestModel().InsertOne(record)

	// 插入一些活动信息
	actInfo := &models.ActivityModel{
		ID:                1110,
		Name:              "明晚6点麻将",
		Description:       "求组队",
		Image:             "此处为头像",
		Status:            0,
		LocationLongitude: 45.12,
		LocationLatitude:  46.48,
		LocationName:      "软件园",
		MinMember:         4,
		MaxMember:         5,
		CurrentMember:     2,
		StartTime:         time.Now(),
		EndTime:           time.Now(),
		LabelID:           label1,
	}
	err = models.GetActivityModel().InsertOne(actInfo)
	changeContent(actInfo, 1111, 102.5, 98.25)
	actInfo.LabelID = label2
	err = models.GetActivityModel().InsertOne(actInfo)
	changeContent(actInfo, 1112, 32, 62.8)
	actInfo.LabelID = 1114
	err = models.GetActivityModel().InsertOne(actInfo)

	result, aEr := services.NewMaybeInterestedService().MaybeInterested(user1, longitude, latitude)
	t.Logf("result:\n%v", result)
	Convey("TestUserInsert  check result", t, func() {
		So(err, ShouldEqual, nil)
		So(aEr, ShouldEqual, nil)
		So(len(result), ShouldEqual, 1)
	})

	/*测试过程：
	case1: 用户感兴趣标签一个，该类型活动2个，查出2个活动   OK
	case2: 用户感兴趣标签一个，该类型活动2个，其他活动1个，  查出3个活动   OK
	case3: 用户感兴趣标签两个，符合兴趣活动2个，其他活动1个， 查出3个活动   OK
	case4: //  用户已参加其中一个
	*/
}

//ActivityResp 活动返回
type ActivityResp struct {
	ActivityID int    `json:"activity_ID"`
	Message    string `json:"message"`
	Status     string `json:"status"`
}

func TestMaybeInterestedHasBeInActivity(t *testing.T) {

	// resp2 := make(map[string]interface{})
	// resp2["ID"] = 123
	// var kk int
	// kk = resp2["ID"].(int)
	// fmt.Printf("%d", kk)
	ClearTable(models.GetMyInterestModel().TableName())
	ClearTable(models.GetActivityModel().TableName())
	ClearTable(models.GetLabelModel().TableName())
	ClearTable(models.GetActivityMemberListModel().TableName())
	defer func() {
		ClearTable(models.GetLabelModel().TableName())
		ClearTable(models.GetMyInterestModel().TableName())
		ClearTable(models.GetActivityModel().TableName())
		ClearTable(models.GetActivityMemberListModel().TableName())
	}()
	userID1 := 456
	userID2 := 567
	labelID1 := 121
	labelID2 := 122
	labelID3 := 123
	LabelCategoryID := 999
	var err error
	labelInfo := &models.LabelModel{
		LabelID:         labelID1,
		LabelName:       "麻将",
		LabelPicture:    "/src.jpg",
		LabelCategoryID: LabelCategoryID,
	}
	err = models.GetLabelModel().InsertOne(labelInfo)
	labelInfo = &models.LabelModel{
		LabelID:         labelID2,
		LabelName:       "狼人杀",
		LabelPicture:    "/src.jpg",
		LabelCategoryID: LabelCategoryID,
	}
	err = models.GetLabelModel().InsertOne(labelInfo)
	labelInfo = &models.LabelModel{
		LabelID:         labelID3,
		LabelName:       "篮球",
		LabelPicture:    "/src.jpg",
		LabelCategoryID: LabelCategoryID,
	}
	err = models.GetLabelModel().InsertOne(labelInfo)
	var activityIDs []int
	aparam := []map[string]interface{}{
		{
			"user_id":             userID1,
			"activity_name":       "狼人杀标准局9Q2",
			"label_name":          "狼人杀",
			"start_time":          "2019-07-22 18:00:00",
			"end_time":            "2019-07-22 22:00:00",
			"max_member":          11,
			"min_member":          11,
			"location_longtitude": 7.4,
			"location_latitude":   33.4,
			"location_name":       "小寨快乐桌游吧",
			"description":         "经常玩哦~欢迎萌新也欢迎狼队大佬！",
			"image":               "/src",
		},
		{
			"user_id":             userID1,
			"activity_name":       "麻将",
			"label_name":          "麻将",
			"start_time":          "2019-07-22 18:00:00",
			"end_time":            "2019-07-22 22:00:00",
			"max_member":          11,
			"min_member":          11,
			"location_longtitude": 55.12,
			"location_latitude":   56.48,
			"location_name":       "软件园",
			"description":         "求组队",
			"image":               "https://ossweb-img.qq.com/images/lol/web201310/skin/big81007.jpg",
		},
		{
			"user_id":             userID1,
			"activity_name":       "篮球",
			"label_name":          "篮球",
			"start_time":          "2019-07-22 18:00:00",
			"end_time":            "2019-07-22 22:00:00",
			"max_member":          11,
			"min_member":          11,
			"location_longtitude": 70.12,
			"location_latitude":   46.48,
			"location_name":       "软件园",
			"description":         "求组队",
			"image":               "https://ossweb-img.qq.com/images/lol/web201310/skin/big81007.jpg",
		},
		//在这里添加活动信息，添加后请手动移动注释位置，谢谢
	}
	for i := 0; i < len(aparam); i++ {
		postData, _ := json.Marshal(aparam[i])
		t.Logf("json\n%s", postData)
		r, _ := http.NewRequest("POST", "/v1/publish", bytes.NewBuffer(postData))
		w := httptest.NewRecorder()
		beego.BeeApp.Handlers.ServeHTTP(w, r)

		t.Logf("Code[%d]\n%s", w.Code, w.Body.String())
		Convey("Subject: Test withrawzanct Endpoint\n", t, func() {
			Convey("Status Code Should Be 200", func() {
				So(w.Code, ShouldEqual, 200)
			})
			Convey("TestActivityPublish check Result", func() {
				var rspBody = w.Body.Bytes()
				var resp ActivityResp
				json.Unmarshal(rspBody, &resp)
				fmt.Println(resp)
				Convey("check message:", func() {
					activityIDs = append(activityIDs, resp.ActivityID)
					So(resp.Message, ShouldEqual, "发出集结成功")
				})
			})
		})
	}

	// 插入参加活动信息
	actMember := &models.ActivityMemberListModel{
		ActivityMemberListID: 11,
		ActivityID:           activityIDs[1],
		UserID:               userID2,
		IsCaptain:            0,
	}
	err = models.GetActivityMemberListModel().InsertOne(actMember)

	// 插入用户感兴趣的标签
	interInfo := &models.MyInterestModel{
		MyInterestID: 11,
		UserID:       userID2,
		LabelID:      labelID1,
	}
	err = models.GetMyInterestModel().InsertOne(interInfo)
	interInfo = &models.MyInterestModel{
		MyInterestID: 12,
		UserID:       userID2,
		LabelID:      labelID2,
	}
	err = models.GetMyInterestModel().InsertOne(interInfo)

	longitude := float64(7.2)
	latitude := float64(6.3)

	result, aEr := services.NewMaybeInterestedService().MaybeInterested(userID2, longitude, latitude)
	t.Logf("result:\n%v", result)
	Convey("TestUserInsert  check result", t, func() {
		So(err, ShouldEqual, nil)
		So(aEr, ShouldEqual, nil)
		So(len(result), ShouldEqual, 1)
	})

	/*测试过程：
	  case1: 用户感兴趣标签两个，符合兴趣活动2个（已参加一个），其他活动1个， 查出2个活动   OK//  用户已参加其中一个
	*/
}
