package test

import (
	"16chao/models"
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/astaxie/beego"
	. "github.com/smartystreets/goconvey/convey"
)

func changeContent(m *models.ActivityModel, id int, longitude, latitude float64) {
	m.ID = id
	m.LocationLongitude = longitude
	m.LocationLatitude = latitude
}

// 用这个来辅助联调时构造mysql数据
func TestMysqlInsert(t *testing.T) {
	ClearTable(models.GetUserModel().TableName())
	ClearTable(models.GetActivityModel().TableName())
	ClearTable(models.GetActivityMemberListModel().TableName())
	ClearTable(models.GetMyInterestModel().TableName())
	// 插入用户
	var err error
	FMY := 1563886110
	record := &models.UserModel{
		ID:     555666,
		Name:   "熊猫酒仙",
		Avatar: "https://wx.qlogo.cn/mmopen/vi_32/EiaSUy9iaGNPpQIFFDNibaMnCmTkzSuWhkhVicmVMlgzkPjKw1AcTODFw2iawq8QRAde7J4wNm1KTkLk7JWACn5cGog/132",
		Gender: 1,
		Region: "山西",
	}
	err = models.GetUserModel().InsertOne(record)
	record = &models.UserModel{
		ID:     FMY,
		Name:   "范茗雨",
		Avatar: "https://wx.qlogo.cn/mmopen/vi_32/EiaSUy9iaGNPpQIFFDNibaMnCmTkzSuWhkhVicmVMlgzkPjKw1AcTODFw2iawq8QRAde7J4wNm1KTkLk7JWACn5cGog/132",
		Gender: 1,
		Region: "Xi'an",
	}
	err = models.GetUserModel().InsertOne(record)
	// 插入一些活动信息
	actInfo := &models.ActivityModel{
		ID:                101,
		Name:              "麻将",
		Description:       "求组队",
		Image:             "https://ossweb-img.qq.com/images/lol/web201310/skin/big81007.jpg",
		Status:            0,
		LocationLongitude: 45.12,
		LocationLatitude:  46.48,
		LocationName:      "软件园",
		MinMember:         4,
		MaxMember:         5,
		CurrentMember:     1,
		StartTime:         time.Now().AddDate(0, 0, -3),
		EndTime:           time.Now().AddDate(0, 0, -2),
		LabelID:           7,
	}
	err = models.GetActivityModel().InsertOne(actInfo)
	changeContent(actInfo, 102, 102.5, 8.25)
	err = models.GetActivityModel().InsertOne(actInfo)
	changeContent(actInfo, 103, 32, 62.8)
	actInfo.CurrentMember = 2
	err = models.GetActivityModel().InsertOne(actInfo)
	actInfo.StartTime = time.Now().AddDate(0, 0, 1)
	actInfo.EndTime = time.Now().AddDate(0, 0, 2)
	actInfo.Name = "足球"
	actInfo.LabelID = 2
	actInfo.ID = 104
	err = models.GetActivityModel().InsertOne(actInfo)

	// 插入活动成员
	record2 := &models.ActivityMemberListModel{
		ActivityMemberListID: 1,
		ActivityID:           103,
		UserID:               1563886110,
		IsCaptain:            1,
	}
	err = models.GetActivityMemberListModel().InsertOne(record2)
	record2 = &models.ActivityMemberListModel{
		ActivityMemberListID: 2,
		ActivityID:           103,
		UserID:               555666,
		IsCaptain:            0,
	}
	err = models.GetActivityMemberListModel().InsertOne(record2)
	record2 = &models.ActivityMemberListModel{
		ActivityMemberListID: 3,
		ActivityID:           104,
		UserID:               555666,
		IsCaptain:            1,
	}
	err = models.GetActivityMemberListModel().InsertOne(record2)
	record2 = &models.ActivityMemberListModel{
		ActivityMemberListID: 4,
		ActivityID:           104,
		UserID:               FMY,
		IsCaptain:            0,
	}
	err = models.GetActivityMemberListModel().InsertOne(record2)

	// 插入用户感兴趣的标签
	myInt := &models.MyInterestModel{
		MyInterestID: 1,
		UserID:       FMY,
		LabelID:      7,
	}
	err = models.GetMyInterestModel().InsertOne(myInt)

	Convey("TestUserInsert  check result", t, func() {
		So(err, ShouldNotEqual, nil)
	})
}

// 用这个来辅助联调时构造mysql数据(利用接口)
func TestMysqlInsert1ys(t *testing.T) {
	ClearTable(models.GetUserModel().TableName())
	ClearTable(models.GetActivityModel().TableName())
	ClearTable(models.GetActivityMemberListModel().TableName())
	ClearTable(models.GetMyInterestModel().TableName())
	FMY := 1563886110
	XMJX := 555666
	LYS := 614
	CXH := 926
	//用户构造部分
	records := []*models.UserModel{
		{
			ID:     XMJX,
			Name:   "熊猫酒仙",
			Avatar: "https://wx.qlogo.cn/mmopen/vi_32/EiaSUy9iaGNPpQIFFDNibaMnCmTkzSuWhkhVicmVMlgzkPjKw1AcTODFw2iawq8QRAde7J4wNm1KTkLk7JWACn5cGog/132",
			Gender: 1,
			Region: "山西",
		},
		{
			ID:     FMY,
			Name:   "范茗雨",
			Avatar: "https://wx.qlogo.cn/mmopen/vi_32/EiaSUy9iaGNPpQIFFDNibaMnCmTkzSuWhkhVicmVMlgzkPjKw1AcTODFw2iawq8QRAde7J4wNm1KTkLk7JWACn5cGog/132",
			Gender: 1,
			Region: "Xi'an",
		},
		{
			ID:     LYS,
			Name:   "斯斯",
			Avatar: "https://ossweb-img.qq.com/images/lol/web201310/skin/big81005.jpg",
			Gender: 1,
			Region: "内蒙古",
		},
		{
			ID:     CXH,
			Name:   "陈向煌",
			Avatar: "https://ossweb-img.qq.com/images/lol/web201310/skin/big81006.jpg",
			Gender: 1,
			Region: "福州",
		},
		//在这里添加想要添加的用户信息，即用户注册，添加完后请手动移动注释位置，谢谢
	}
	for i := 0; i < len(records); i++ {
		err := models.GetUserModel().InsertOne(records[i])
		Convey("TestUserInsert  check result", t, func() {
			So(err, ShouldEqual, nil)
		})
	}

	// 活动部分构造  (这里直接指定活动队长即user_id，活动状态默认为0(正在集结)，活动label id会根据label name自动获得，添加活动成员不在这里)
	aparam := []map[string]interface{}{
		{
			"user_id":             555666,
			"activity_name":       "狼人杀标准局9Q2",
			"label_name":          "狼人杀",
			"start_time":          "2019-08-01 16:45:00",
			"end_time":            "2019-08-01 16:46:00",
			"max_member":          11,
			"min_member":          11,
			"location_longtitude": 7.4,
			"location_latitude":   33.4,
			"location_name":       "小寨快乐桌游吧",
			"description":         "经常玩哦~欢迎萌新也欢迎狼队大佬！",
			// "image": "https://ossweb-img.qq.com/images/lol/web201310/skin/big81007.jpg	",
		},
		{
			"user_id":             FMY,
			"activity_name":       "麻将",
			"label_name":          "麻将",
			"start_time":          "2019-08-01 16:49:00",
			"end_time":            "2019-08-01 16:50:00",
			"max_member":          11,
			"min_member":          11,
			"location_longtitude": 45.12,
			"location_latitude":   46.48,
			"location_name":       "软件园",
			"description":         "求组队",
			// "image":               "https://ossweb-img.qq.com/images/lol/web201310/skin/big81007.jpg",
		},
		{
			"user_id":             LYS,
			"activity_name":       "晚上跑步，10公里不说话那种",
			"label_name":          "慢跑",
			"start_time":          "2019-08-01 16:46:00",
			"end_time":            "2019-08-01 16:48:00",
			"max_member":          11,
			"min_member":          11,
			"location_longtitude": 7.4,
			"location_latitude":   33.4,
			"location_name":       "云水公园",
			"description":         "周周跑",
			// "image": "https://ossweb-img.qq.com/images/lol/web201310/skin/big81007.jpg	",
		},
		{
			"user_id":             CXH,
			"activity_name":       "晚上广场跳舞，贼骚那种",
			"label_name":          "跳舞",
			"start_time":          "2019-07-25 18:00:00",
			"end_time":            "2019-07-25 22:00:00",
			"max_member":          11,
			"min_member":          11,
			"location_longtitude": 7.4,
			"location_latitude":   33.4,
			"location_name":       "云水公园",
			"description":         "天天跳",
			// "image": "https://ossweb-img.qq.com/images/lol/web201310/skin/big81007.jpg	",
		},
		{
			"user_id":             FMY,
			"activity_name":       "未来活动",
			"label_name":          "足球",
			"start_time":          "2019-08-22 18:00:00",
			"end_time":            "2019-08-22 22:00:00",
			"max_member":          11,
			"min_member":          11,
			"location_longtitude": 7.4,
			"location_latitude":   33.4,
			"location_name":       "园区足球场",
			"description":         "国足找组织！",
			// "image": "https://ossweb-img.qq.com/images/lol/web201310/skin/big81007.jpg	",
		},
		{
			"user_id":             614,
			"activity_name":       "周五回民街逛吃",
			"label_name":          "逛街",
			"start_time":          "2019-07-26 18:00:00",
			"end_time":            "2019-07-26 22:00:00",
			"max_member":          11,
			"min_member":          11,
			"location_longtitude": 7.4,
			"location_latitude":   33.4,
			"location_name":       "钟楼回民街",
			"description":         "小吃",
			// "image":               "https://wx.qlogo.cn/mmopen/vi_32/EiaSUy9iaGNPpQIFFDNibaMnCmTkzSuWhkhVicmVMlgzkPjKw1AcTODFw2iawq8QRAde7J4wNm1KTkLk7JWACn5cGog/132",
		},
		//在这里添加活动信息，添加后请手动移动注释位置，谢谢
	}
	for i := 0; i < len(aparam); i++ {
		postData, _ := json.Marshal(aparam[i])
		t.Logf("json\n%s", postData)
		r, _ := http.NewRequest("POST", "/v1/publish", bytes.NewBuffer(postData))
		w := httptest.NewRecorder()
		beego.BeeApp.Handlers.ServeHTTP(w, r)

		t.Logf("Code[%d]\n%s", w.Code, w.Body.String())
		Convey("Subject: Test withrawzanct Endpoint\n", t, func() {
			Convey("Status Code Should Be 200", func() {
				So(w.Code, ShouldEqual, 200)
			})
			Convey("TestActivityPublish check Result", func() {
				var rspBody = w.Body.Bytes()
				var resp map[string]interface{}
				json.Unmarshal(rspBody, &resp)
				//fmt.Println(resp)
				Convey("check message:", func() {
					So(resp["message"], ShouldEqual, "发出集结成功")
				})
			})
		})
	}
	//-----------活动成员构造部分  天翔还在完善代码 待补充----------------
	param := []map[string]interface{}{
		{
			"user_id":     1563886110,
			"activity_id": 1,
		},
		//在此处添加想要添加的活动成员
	}
	for i := 0; i < len(param); i++ {
		postData, _ := json.Marshal(param[i])
		t.Logf("json\n%s", postData)
		r, _ := http.NewRequest("POST", "/v1/SignUp", bytes.NewBuffer(postData))
		w := httptest.NewRecorder()
		beego.BeeApp.Handlers.ServeHTTP(w, r)

		t.Logf("Code[%d]\n%s", w.Code, w.Body.String())
		Convey("Subject: Test withrawzanct Endpoint\n", t, func() {
			Convey("Status Code Should Be 200", func() {
				So(w.Code, ShouldEqual, 200)
			})
			Convey("Bein check Result", func() {
				var rspBody = w.Body.Bytes()

				var resp map[string]interface{}
				json.Unmarshal(rspBody, &resp)
				Convey("check message:", func() {
					fmt.Println(resp)
					So(resp["message"], ShouldNotEqual, "报名成功")
				})
			})
		})
	}

	//---------------用户感兴趣的标签构造部分----------------------
	myInt := []*models.MyInterestModel{
		{
			MyInterestID: 1,
			UserID:       FMY,
			LabelID:      7,
		},
		{

			UserID:  FMY,
			LabelID: 20,
		},
		{

			UserID:  FMY,
			LabelID: 1,
		},
		{

			UserID:  FMY,
			LabelID: 18,
		},
		{

			UserID:  FMY,
			LabelID: 19,
		},
		//在这里添加用户感兴趣的标签，添加后请手动移动注释位置，谢谢
	}

	for i := 0; i < len(myInt); i++ {
		err := models.GetMyInterestModel().InsertOne(myInt[i])
		Convey("TestUserInsert  check result", t, func() {
			So(err, ShouldEqual, nil)
		})
	}
}
