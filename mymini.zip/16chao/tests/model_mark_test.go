package test

import (
	"16chao/def"
	"16chao/models"
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/astaxie/beego"
	. "github.com/smartystreets/goconvey/convey"
)

func TestMarkIsParamValid(t *testing.T) {
	ClearTable(models.GetMarkModel().TableName())
	defer func() {
		//	ClearTable(models.GetMarkModel().TableName())
	}()
	UserID := 666
	TargetUserID := 777
	ActivityID := 107
	record := &models.MarkModel{
		MarkID:       123,
		UserID:       UserID,
		TargetUserID: TargetUserID,
		Score:        3.7,
		ActivityID:   ActivityID,
	}
	err := models.GetMarkModel().InsertOne(record)
	Convey("TestMarkIsParamValid  insert", t, func() {
		So(err, ShouldEqual, nil)
	})

	flag, err := models.GetMarkModel().IsParamValid(UserID, TargetUserID, ActivityID)
	Convey("TestUserInsert  check result", t, func() {
		So(err, ShouldEqual, nil)
		So(flag, ShouldNotEqual, 1)
	})
}

func TestCreateMarkRelationship(t *testing.T) {
	ClearTable(models.GetUserModel().TableName())
	ClearTable(models.GetActivityModel().TableName())
	ClearTable(models.GetActivityMemberListModel().TableName())
	ClearTable(models.GetMyInterestModel().TableName())
	ClearTable(models.GetMarkModel().TableName())
	defer func() {
		// ClearTable(models.GetUserModel().TableName())
		// ClearTable(models.GetActivityModel().TableName())
		// ClearTable(models.GetActivityMemberListModel().TableName())
		// ClearTable(models.GetMyInterestModel().TableName())
		//	ClearTable(models.GetMarkModel().TableName())
	}()

	FMY := 1563886110
	XMJX := 555666
	LYS := 614
	CXH := 926
	//用户构造部分
	records := []*models.UserModel{
		{
			ID:     XMJX,
			Name:   "熊猫酒仙",
			Avatar: "k7JWACn5cGog/132",
			Gender: 1,
			Region: "山西",
		},
		{
			ID:     FMY,
			Name:   "范茗雨",
			Avatar: "TkLk7JWACn5cGog/132",
			Gender: 1,
			Region: "Xi'an",
		},
		{
			ID:     LYS,
			Name:   "斯斯",
			Avatar: "kin/big81005.jpg",
			Gender: 1,
			Region: "内蒙古",
		},
		{
			ID:     CXH,
			Name:   "陈向煌",
			Avatar: "g81006.jpg",
			Gender: 1,
			Region: "福州",
		},
	}
	for i := 0; i < len(records); i++ {
		err := models.GetUserModel().InsertOne(records[i])
		Convey("TestUserInsert  check result", t, func() {
			So(err, ShouldEqual, nil)
		})
	}

	// 活动部分构造  (这里直接指定活动队长即user_id，活动状态默认为0(正在集结)，活动label id会根据label name自动获得，添加活动成员不在这里)
	aparam := []map[string]interface{}{
		{
			"user_id":             FMY,
			"activity_name":       "麻将",
			"label_name":          "麻将",
			"start_time":          time.Now().AddDate(0, 0, 1).Format(def.TimeStampFmt),
			"end_time":            time.Now().AddDate(0, 0, 2).Format(def.TimeStampFmt),
			"max_member":          4,
			"min_member":          3,
			"location_longtitude": 45.12,
			"location_latitude":   46.48,
			"location_name":       "软件园",
			"description":         "求组队",
			// "image":               "https://ossweb-img.qq.com/images/lol/web201310/skin/big81007.jpg",
		},
		{
			"user_id":             LYS,
			"activity_name":       "晚上跑步，10公里不说话那种",
			"label_name":          "跑步",
			"start_time":          time.Now().AddDate(0, 0, 1).Format(def.TimeStampFmt),
			"end_time":            time.Now().AddDate(0, 0, 2).Format(def.TimeStampFmt),
			"max_member":          11,
			"min_member":          11,
			"location_longtitude": 7.4,
			"location_latitude":   33.4,
			"location_name":       "云水公园",
			"description":         "周周跑",
			// "image": "https://ossweb-img.qq.com/images/lol/web201310/skin/big81007.jpg	",
		},
	}
	var activityIDs []int
	for i := 0; i < len(aparam); i++ {
		postData, _ := json.Marshal(aparam[i])
		t.Logf("json\n%s", postData)
		r, _ := http.NewRequest("POST", "/v1/publish", bytes.NewBuffer(postData))
		w := httptest.NewRecorder()
		beego.BeeApp.Handlers.ServeHTTP(w, r)

		t.Logf("Code[%d]\n%s", w.Code, w.Body.String())
		Convey("Subject: Test withrawzanct Endpoint\n", t, func() {
			Convey("Status Code Should Be 200", func() {
				So(w.Code, ShouldEqual, 200)
			})
			Convey("TestActivityPublish check Result", func() {
				var rspBody = w.Body.Bytes()
				var resp ActivityResp
				json.Unmarshal(rspBody, &resp)
				//fmt.Println(resp)
				Convey("check message:", func() {
					activityIDs = append(activityIDs, resp.ActivityID)
					So(resp.Message, ShouldEqual, "发出集结成功")
				})
			})
		})
	}
	//-----------活动成员构造部分
	param := []map[string]interface{}{
		{
			"user_id":     LYS,
			"activity_id": activityIDs[0],
		},
		{
			"user_id":     CXH,
			"activity_id": activityIDs[0],
		},
		{
			"user_id":     XMJX,
			"activity_id": activityIDs[0],
		},
	}
	for i := 0; i < len(param); i++ {
		postData, _ := json.Marshal(param[i])
		t.Logf("json\n%s", postData)
		r, _ := http.NewRequest("POST", "/v1/SignUp", bytes.NewBuffer(postData))
		w := httptest.NewRecorder()
		beego.BeeApp.Handlers.ServeHTTP(w, r)

		t.Logf("Code[%d]\n%s", w.Code, w.Body.String())
		Convey("Subject: Test withrawzanct Endpoint\n", t, func() {
			Convey("Status Code Should Be 200", func() {
				So(w.Code, ShouldEqual, 200)
			})
			Convey("Bein check Result", func() {
				var rspBody = w.Body.Bytes()

				var resp map[string]interface{}
				json.Unmarshal(rspBody, &resp)
				Convey("check message:", func() {
					fmt.Println(resp)
					So(resp["message"], ShouldEqual, "报名成功")
				})
			})
		})
	}
	err := models.GetMarkModel().CreateMarkRelationship(activityIDs[0])
	Convey("CreateMarkRelationship  check result", t, func() {
		So(err, ShouldEqual, nil)
		// 检查打分关系是否都建立好了条目
	})

	// 测试： UpdateMarkScore 更新单对单的打分
	oneMark := &models.MarkModel{
		UserID:       FMY,
		TargetUserID: CXH,
		Score:        def.MarkLevel4,
		ActivityID:   activityIDs[0],
		DefaultFlag:  def.UserMark,
	}
	err = models.GetMarkModel().UpdateMarkScore(oneMark)
	Convey("UpdateMarkScore  check result", t, func() {
		So(err, ShouldEqual, nil)
		// 检查分数和flag是否都修改成功
	})

	// 测试： GetDefaultMarkInfoByActivityID   查询一个活动中未被用户主动打分的所有记录
	results, err := models.GetMarkModel().GetDefaultMarkInfoByActivityID(activityIDs[0])
	Convey("GetDefaultMarkInfoByActivityID  check result", t, func() {
		So(err, ShouldEqual, nil)
		So(len(results), ShouldEqual, 11) // 运行到这里，总共4个用户12个打分条目，只有一个主动评价，应该查出11条未主动打分记录
	})

	// 测试： CalculateUserScore 统计用户所有参加过的活动中的评分，计算出分数
	socreCXH, _, err := models.GetMarkModel().CalculateUserScore(CXH)
	fmt.Printf("socreCXH: %f ", socreCXH)
	Convey("CalculateUserScore CXH  check result", t, func() {
		So(err, ShouldEqual, nil)
	})
	socreFMY, _, err := models.GetMarkModel().CalculateUserScore(FMY)
	fmt.Printf("socreFMY: %f ", socreFMY)
	Convey("CalculateUserScore FMY check result", t, func() {
		So(err, ShouldEqual, nil)
	})

}
