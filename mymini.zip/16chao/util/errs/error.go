package errs

// AppError application error
type AppError struct {
	code int
	msg  string
	data interface{}
}

// NewErr -
func NewErr(msg string) *AppError {
	return &AppError{code: -1, msg: msg, data: nil}
}

// NewErrCode -
func NewErrCode(msg string, code int) *AppError {
	return &AppError{code: code, msg: msg, data: nil}
}

// NewErrData -
func NewErrData(msg string, code int, data interface{}) *AppError {
	return &AppError{code: code, msg: msg, data: data}
}

// Code get error code
func (e *AppError) Code() int {
	return e.code
}

// Msg get error message
func (e *AppError) Msg() string {
	return e.msg
}

// Data get error data
func (e *AppError) Data() interface{} {
	return e.data
}

// AppFail api error
type AppFail struct {
	status  string
	message string
}

// NewAppFail -
func NewAppFail(msg string) *AppFail {
	return &AppFail{status: "false", message: msg}
}

// Status get status
func (e *AppFail) Status() string {
	return e.status
}

// Message get error message
func (e *AppFail) Message() string {
	return e.message
}
