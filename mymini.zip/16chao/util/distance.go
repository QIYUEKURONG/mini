package util

import (
	"16chao/def"
	"16chao/util/errs"
	"errors" // 生成错误
	"fmt"
	"math"
	"strconv"
	"strings" // 使用互斥锁
	// 获取时间
)

const (
	longitudeMin float64 = -180
	longitudeMax float64 = 180
	latitudeMin  float64 = -90
	latitudeMax  float64 = 90
)

var radius = 6378.137 // 计算距离的定值
//Position 位置 包含经度纬度
type Position struct {
	lat float64
	lng float64
}

//GetFormatEarthDistance 获取格式化的距离
func GetFormatEarthDistance(lat1 float64, lng1 float64, lat2 float64, lng2 float64) (string, *errs.AppError) {
	p1, errP1 := NewPosition(lat1, lng1)
	p2, errP2 := NewPosition(lat2, lng2)
	if errP1 != nil {
		fmt.Printf("errP1 : %v", errP1)
		return "", errs.NewErrCode("Value out of range", def.EInternalErr)
	}
	if errP2 != nil {
		fmt.Printf("errP2 : %v", errP2)
		return "", errs.NewErrCode("Value out of range", def.EInternalErr)
	}
	distance := EarthDistance(p1, p2)
	fmt.Print("距离:")
	fmt.Println(distance)
	res := ConvertDistance(distance)
	return res, nil
}

//NewPosition 生成一个地点
func NewPosition(latN float64, lngN float64) (*Position, error) {
	// 如果超出节点的最大范围，产生一个 error
	if latN > latitudeMax || latN < latitudeMin {
		return nil, errors.New("latN number must be between -180 and 180")
	}
	if lngN > longitudeMax || lngN < longitudeMin {
		return nil, errors.New("Node number must be between -90 and 90")
	}
	// 生成并返回节点实例的指针
	pr := Position{
		lat: latN,
		lng: lngN,
	}
	return &pr, nil
}

//EarthDistance 根据经纬度计算距离
func EarthDistance(position1 *Position, position2 *Position) float64 {
	rad := math.Pi / 180.0
	position1.lat = position1.lat * rad
	position1.lng = position1.lng * rad
	position2.lat = position2.lat * rad
	position2.lng = position2.lng * rad
	theta := position2.lng - position1.lng
	dist := math.Acos(math.Sin(position1.lat)*math.Sin(position2.lat) + math.Cos(position1.lat)*math.Cos(position2.lat)*math.Cos(theta))
	return dist * radius
}

//Decimal 保留3位小数（四舍五入）
func Decimal(value float64) float64 {
	//distance := math.Trunc(value*1e1+0.5) * 1e-1
	pow10Tn := math.Pow10(3)
	distance := math.Trunc(value*pow10Tn+0.5) / pow10Tn
	if distance < 1 {
		distance *= 1000
		distance = float64(int(math.Floor(distance + 0/5)))
	} else {
		pow10Tn := math.Pow10(1)
		distance = math.Trunc(value*pow10Tn+0.5) / pow10Tn
	}
	return distance
}

//GetDecimalNumber 获取小数位数
func GetDecimalNumber(value float64) int {
	//distance := math.Trunc(value*1e1+0.5) * 1e-1
	arr := strings.Split(fmt.Sprintf("%v", value), ".")
	var decimalNumber int
	if len(arr) == 1 {
		decimalNumber = 0
	} else {
		decimalNumber = len(strings.Split(fmt.Sprintf("%v", value), ".")[1])
	}

	return decimalNumber
}

//ConvertDistance 转换距离
func ConvertDistance(d float64) string {
	var s string
	distanceTemp := Decimal(d)
	if GetDecimalNumber(distanceTemp) == 0 {
		disToString := strconv.FormatFloat(distanceTemp, 'g', -1, 64)
		s = disToString + "m"
	} else {
		disToString := strconv.FormatFloat(distanceTemp, 'g', -1, 64)
		s = disToString + "km"
	}
	return s
}
