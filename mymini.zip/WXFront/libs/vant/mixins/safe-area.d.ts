export declare const safeArea: ({ safeAreaInsetBottom, safeAreaInsetTop }?: {
    safeAreaInsetBottom?: boolean;
    safeAreaInsetTop?: boolean;
}) => void;
